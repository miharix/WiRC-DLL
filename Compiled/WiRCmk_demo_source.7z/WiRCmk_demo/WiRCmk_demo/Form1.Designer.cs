﻿namespace WiRCmk_demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.joystickStat = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Find_button = new System.Windows.Forms.Button();
            this.subnet = new System.Windows.Forms.TextBox();
            this.Connect_button = new System.Windows.Forms.Button();
            this.MoveAll_button = new System.Windows.Forms.Button();
            this.ServoPos_textBox = new System.Windows.Forms.TextBox();
            this.Disconect_button = new System.Windows.Forms.Button();
            this.JoyStart_button = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Status = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.statusTimer = new System.Windows.Forms.Timer(this.components);
            this.MoveServo_button = new System.Windows.Forms.Button();
            this.ServoNumber = new System.Windows.Forms.TextBox();
            this.ServoPos = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.MoveServoDegree_button = new System.Windows.Forms.Button();
            this.TagetDegree = new System.Windows.Forms.TextBox();
            this.MaxServo = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.AllAtOne_Button = new System.Windows.Forms.Button();
            this.ser1 = new System.Windows.Forms.TextBox();
            this.ser2 = new System.Windows.Forms.TextBox();
            this.ser3 = new System.Windows.Forms.TextBox();
            this.ser4 = new System.Windows.Forms.TextBox();
            this.ser5 = new System.Windows.Forms.TextBox();
            this.ser6 = new System.Windows.Forms.TextBox();
            this.ser7 = new System.Windows.Forms.TextBox();
            this.ser8 = new System.Windows.Forms.TextBox();
            this.out1 = new System.Windows.Forms.CheckBox();
            this.out2 = new System.Windows.Forms.CheckBox();
            this.out4 = new System.Windows.Forms.CheckBox();
            this.out3 = new System.Windows.Forms.CheckBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.Camera = new System.Windows.Forms.Button();
            this.InputBool = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label26 = new System.Windows.Forms.Label();
            this.OtherCheck_button = new System.Windows.Forms.Button();
            this.Transmitters_button = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.Config_Button = new System.Windows.Forms.Button();
            this.Firmware_button = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.SSID = new System.Windows.Forms.TextBox();
            this.WPA = new System.Windows.Forms.CheckBox();
            this.Is_Accespoint = new System.Windows.Forms.CheckBox();
            this.Password = new System.Windows.Forms.TextBox();
            this.ChanellNum = new System.Windows.Forms.NumericUpDown();
            this.Country = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.RecordMJPEG_button = new System.Windows.Forms.Button();
            this.RecordAVI = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.GetBackControl_button = new System.Windows.Forms.Button();
            this.RequestAcces_button = new System.Windows.Forms.Button();
            this.CheckIfHasControl_Timer = new System.Windows.Forms.Timer(this.components);
            this.label36 = new System.Windows.Forms.Label();
            this.numericUpDownCamID = new System.Windows.Forms.NumericUpDown();
            this.CoffV = new System.Windows.Forms.TextBox();
            this.WiRCoffV = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.VideoDrawTimer = new System.Windows.Forms.Timer(this.components);
            this.avi_record = new System.Windows.Forms.Timer(this.components);
            this.label33 = new System.Windows.Forms.Label();
            this.NewName = new System.Windows.Forms.TextBox();
            this.ChangeName = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChanellNum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCamID)).BeginInit();
            this.SuspendLayout();
            // 
            // joystickStat
            // 
            this.joystickStat.Interval = 20;
            this.joystickStat.Tick += new System.EventHandler(this.joystickStat_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(722, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(722, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "label2";
            // 
            // Find_button
            // 
            this.Find_button.Location = new System.Drawing.Point(316, 17);
            this.Find_button.Name = "Find_button";
            this.Find_button.Size = new System.Drawing.Size(90, 33);
            this.Find_button.TabIndex = 2;
            this.Find_button.Text = "Find WiRC";
            this.Find_button.UseVisualStyleBackColor = true;
            this.Find_button.Click += new System.EventHandler(this.Find_button_Click);
            // 
            // subnet
            // 
            this.subnet.Location = new System.Drawing.Point(412, 17);
            this.subnet.Name = "subnet";
            this.subnet.Size = new System.Drawing.Size(100, 20);
            this.subnet.TabIndex = 3;
            this.subnet.Text = "192.168.1.255";
            // 
            // Connect_button
            // 
            this.Connect_button.Location = new System.Drawing.Point(316, 60);
            this.Connect_button.Name = "Connect_button";
            this.Connect_button.Size = new System.Drawing.Size(90, 32);
            this.Connect_button.TabIndex = 4;
            this.Connect_button.Text = "Connect";
            this.Connect_button.UseVisualStyleBackColor = true;
            this.Connect_button.Click += new System.EventHandler(this.Connect_button_Click);
            // 
            // MoveAll_button
            // 
            this.MoveAll_button.Location = new System.Drawing.Point(276, 137);
            this.MoveAll_button.Name = "MoveAll_button";
            this.MoveAll_button.Size = new System.Drawing.Size(89, 28);
            this.MoveAll_button.TabIndex = 5;
            this.MoveAll_button.Text = "move all servos";
            this.MoveAll_button.UseVisualStyleBackColor = true;
            this.MoveAll_button.Click += new System.EventHandler(this.MoveAll_button_Click);
            // 
            // ServoPos_textBox
            // 
            this.ServoPos_textBox.Location = new System.Drawing.Point(378, 145);
            this.ServoPos_textBox.Name = "ServoPos_textBox";
            this.ServoPos_textBox.Size = new System.Drawing.Size(92, 20);
            this.ServoPos_textBox.TabIndex = 6;
            this.ServoPos_textBox.Text = "1500";
            // 
            // Disconect_button
            // 
            this.Disconect_button.Location = new System.Drawing.Point(535, 12);
            this.Disconect_button.Name = "Disconect_button";
            this.Disconect_button.Size = new System.Drawing.Size(89, 20);
            this.Disconect_button.TabIndex = 7;
            this.Disconect_button.Text = "disconect";
            this.Disconect_button.UseVisualStyleBackColor = true;
            this.Disconect_button.Click += new System.EventHandler(this.Disconect_button_Click);
            // 
            // JoyStart_button
            // 
            this.JoyStart_button.Location = new System.Drawing.Point(725, 45);
            this.JoyStart_button.Name = "JoyStart_button";
            this.JoyStart_button.Size = new System.Drawing.Size(89, 22);
            this.JoyStart_button.TabIndex = 8;
            this.JoyStart_button.Text = "Joystick start";
            this.JoyStart_button.UseVisualStyleBackColor = true;
            this.JoyStart_button.Click += new System.EventHandler(this.JoyStart_button_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(419, 48);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(92, 43);
            this.listBox1.TabIndex = 9;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(526, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "HW:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(526, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "SW:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(608, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "IP: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(608, 74);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Serial:";
            // 
            // Status
            // 
            this.Status.Location = new System.Drawing.Point(275, 175);
            this.Status.Name = "Status";
            this.Status.Size = new System.Drawing.Size(89, 31);
            this.Status.TabIndex = 14;
            this.Status.Text = "Status";
            this.Status.UseVisualStyleBackColor = true;
            this.Status.Click += new System.EventHandler(this.button1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(375, 172);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "label7";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(375, 193);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "label8";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(476, 169);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "label9";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(476, 193);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "label10";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(542, 170);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 13);
            this.label11.TabIndex = 19;
            this.label11.Text = "label11";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(547, 193);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 13);
            this.label12.TabIndex = 20;
            this.label12.Text = "label12";
            // 
            // statusTimer
            // 
            this.statusTimer.Tick += new System.EventHandler(this.statusTimer_Tick);
            // 
            // MoveServo_button
            // 
            this.MoveServo_button.Location = new System.Drawing.Point(24, 15);
            this.MoveServo_button.Name = "MoveServo_button";
            this.MoveServo_button.Size = new System.Drawing.Size(75, 23);
            this.MoveServo_button.TabIndex = 21;
            this.MoveServo_button.Text = "Move servo";
            this.MoveServo_button.UseVisualStyleBackColor = true;
            this.MoveServo_button.Click += new System.EventHandler(this.MoveServo_button_Click);
            // 
            // ServoNumber
            // 
            this.ServoNumber.Location = new System.Drawing.Point(10, 53);
            this.ServoNumber.Name = "ServoNumber";
            this.ServoNumber.Size = new System.Drawing.Size(20, 20);
            this.ServoNumber.TabIndex = 22;
            this.ServoNumber.Text = "0";
            // 
            // ServoPos
            // 
            this.ServoPos.Location = new System.Drawing.Point(10, 88);
            this.ServoPos.Name = "ServoPos";
            this.ServoPos.Size = new System.Drawing.Size(34, 20);
            this.ServoPos.TabIndex = 23;
            this.ServoPos.Text = "2200";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(50, 91);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(96, 13);
            this.label13.TabIndex = 24;
            this.label13.Text = "Range: 800 - 2200";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(36, 43);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(58, 13);
            this.label14.TabIndex = 25;
            this.label14.Text = "Servos 0-7";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(36, 60);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(95, 13);
            this.label15.TabIndex = 26;
            this.label15.Text = "Digital Output 8-11";
            // 
            // MoveServoDegree_button
            // 
            this.MoveServoDegree_button.Location = new System.Drawing.Point(119, 15);
            this.MoveServoDegree_button.Name = "MoveServoDegree_button";
            this.MoveServoDegree_button.Size = new System.Drawing.Size(121, 23);
            this.MoveServoDegree_button.TabIndex = 27;
            this.MoveServoDegree_button.Text = "Move servo in degree";
            this.MoveServoDegree_button.UseVisualStyleBackColor = true;
            this.MoveServoDegree_button.Click += new System.EventHandler(this.MoveServoDegree_button_Click);
            // 
            // TagetDegree
            // 
            this.TagetDegree.Location = new System.Drawing.Point(152, 84);
            this.TagetDegree.Name = "TagetDegree";
            this.TagetDegree.Size = new System.Drawing.Size(24, 20);
            this.TagetDegree.TabIndex = 28;
            this.TagetDegree.Text = "15";
            // 
            // MaxServo
            // 
            this.MaxServo.Location = new System.Drawing.Point(137, 50);
            this.MaxServo.Name = "MaxServo";
            this.MaxServo.Size = new System.Drawing.Size(26, 20);
            this.MaxServo.TabIndex = 29;
            this.MaxServo.Text = "60";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(169, 53);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(85, 13);
            this.label16.TabIndex = 30;
            this.label16.Text = "Max servo travel";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(182, 88);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(74, 13);
            this.label17.TabIndex = 31;
            this.label17.Text = "Target degree";
            // 
            // AllAtOne_Button
            // 
            this.AllAtOne_Button.Location = new System.Drawing.Point(10, 128);
            this.AllAtOne_Button.Name = "AllAtOne_Button";
            this.AllAtOne_Button.Size = new System.Drawing.Size(191, 23);
            this.AllAtOne_Button.TabIndex = 32;
            this.AllAtOne_Button.Text = "All Servos && outputs at once";
            this.AllAtOne_Button.UseVisualStyleBackColor = true;
            this.AllAtOne_Button.Click += new System.EventHandler(this.AllAtOne_Button_Click);
            // 
            // ser1
            // 
            this.ser1.Location = new System.Drawing.Point(6, 156);
            this.ser1.Name = "ser1";
            this.ser1.Size = new System.Drawing.Size(31, 20);
            this.ser1.TabIndex = 33;
            this.ser1.Text = "800";
            // 
            // ser2
            // 
            this.ser2.Location = new System.Drawing.Point(6, 178);
            this.ser2.Name = "ser2";
            this.ser2.Size = new System.Drawing.Size(31, 20);
            this.ser2.TabIndex = 34;
            this.ser2.Text = "800";
            // 
            // ser3
            // 
            this.ser3.Location = new System.Drawing.Point(6, 225);
            this.ser3.Name = "ser3";
            this.ser3.Size = new System.Drawing.Size(31, 20);
            this.ser3.TabIndex = 36;
            this.ser3.Text = "800";
            // 
            // ser4
            // 
            this.ser4.Location = new System.Drawing.Point(6, 201);
            this.ser4.Name = "ser4";
            this.ser4.Size = new System.Drawing.Size(31, 20);
            this.ser4.TabIndex = 35;
            this.ser4.Text = "800";
            // 
            // ser5
            // 
            this.ser5.Location = new System.Drawing.Point(100, 225);
            this.ser5.Name = "ser5";
            this.ser5.Size = new System.Drawing.Size(31, 20);
            this.ser5.TabIndex = 40;
            this.ser5.Text = "800";
            // 
            // ser6
            // 
            this.ser6.Location = new System.Drawing.Point(100, 201);
            this.ser6.Name = "ser6";
            this.ser6.Size = new System.Drawing.Size(31, 20);
            this.ser6.TabIndex = 39;
            this.ser6.Text = "800";
            // 
            // ser7
            // 
            this.ser7.Location = new System.Drawing.Point(100, 178);
            this.ser7.Name = "ser7";
            this.ser7.Size = new System.Drawing.Size(31, 20);
            this.ser7.TabIndex = 38;
            this.ser7.Text = "800";
            // 
            // ser8
            // 
            this.ser8.Location = new System.Drawing.Point(100, 156);
            this.ser8.Name = "ser8";
            this.ser8.Size = new System.Drawing.Size(31, 20);
            this.ser8.TabIndex = 37;
            this.ser8.Text = "800";
            // 
            // out1
            // 
            this.out1.AutoSize = true;
            this.out1.Location = new System.Drawing.Point(199, 160);
            this.out1.Name = "out1";
            this.out1.Size = new System.Drawing.Size(67, 17);
            this.out1.TabIndex = 41;
            this.out1.Text = "Output 1";
            this.out1.UseVisualStyleBackColor = true;
            // 
            // out2
            // 
            this.out2.AutoSize = true;
            this.out2.Location = new System.Drawing.Point(199, 181);
            this.out2.Name = "out2";
            this.out2.Size = new System.Drawing.Size(67, 17);
            this.out2.TabIndex = 42;
            this.out2.Text = "Output 2";
            this.out2.UseVisualStyleBackColor = true;
            // 
            // out4
            // 
            this.out4.AutoSize = true;
            this.out4.Location = new System.Drawing.Point(199, 222);
            this.out4.Name = "out4";
            this.out4.Size = new System.Drawing.Size(67, 17);
            this.out4.TabIndex = 44;
            this.out4.Text = "Output 4";
            this.out4.UseVisualStyleBackColor = true;
            // 
            // out3
            // 
            this.out3.AutoSize = true;
            this.out3.Location = new System.Drawing.Point(199, 201);
            this.out3.Name = "out3";
            this.out3.Size = new System.Drawing.Size(67, 17);
            this.out3.TabIndex = 43;
            this.out3.Text = "Output 3";
            this.out3.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(43, 160);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(44, 13);
            this.label18.TabIndex = 45;
            this.label18.Text = "Servo 1";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(43, 182);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(44, 13);
            this.label19.TabIndex = 46;
            this.label19.Text = "Servo 2";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(44, 205);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(44, 13);
            this.label20.TabIndex = 47;
            this.label20.Text = "Servo 3";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(43, 229);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(44, 13);
            this.label21.TabIndex = 48;
            this.label21.Text = "Servo 4";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(137, 229);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(44, 13);
            this.label22.TabIndex = 52;
            this.label22.Text = "Servo 8";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(139, 205);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(44, 13);
            this.label23.TabIndex = 51;
            this.label23.Text = "Servo 7";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(137, 182);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(44, 13);
            this.label24.TabIndex = 50;
            this.label24.Text = "Servo 6";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(137, 160);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(44, 13);
            this.label25.TabIndex = 49;
            this.label25.Text = "Servo 5";
            // 
            // Camera
            // 
            this.Camera.Location = new System.Drawing.Point(611, 141);
            this.Camera.Name = "Camera";
            this.Camera.Size = new System.Drawing.Size(75, 23);
            this.Camera.TabIndex = 53;
            this.Camera.Text = "Camera ON";
            this.Camera.UseVisualStyleBackColor = true;
            this.Camera.Click += new System.EventHandler(this.Camera_Click);
            // 
            // InputBool
            // 
            this.InputBool.Location = new System.Drawing.Point(6, 251);
            this.InputBool.Name = "InputBool";
            this.InputBool.Size = new System.Drawing.Size(75, 23);
            this.InputBool.TabIndex = 54;
            this.InputBool.Text = "Check Input";
            this.InputBool.UseVisualStyleBackColor = true;
            this.InputBool.Click += new System.EventHandler(this.InputBool_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(87, 254);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(31, 20);
            this.numericUpDown1.TabIndex = 55;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(124, 256);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(63, 13);
            this.label26.TabIndex = 56;
            this.label26.Text = "Input state: ";
            // 
            // OtherCheck_button
            // 
            this.OtherCheck_button.Location = new System.Drawing.Point(282, 213);
            this.OtherCheck_button.Name = "OtherCheck_button";
            this.OtherCheck_button.Size = new System.Drawing.Size(75, 23);
            this.OtherCheck_button.TabIndex = 57;
            this.OtherCheck_button.Text = "Other check";
            this.OtherCheck_button.UseVisualStyleBackColor = true;
            this.OtherCheck_button.Click += new System.EventHandler(this.OtherCheck_button_Click);
            // 
            // Transmitters_button
            // 
            this.Transmitters_button.Location = new System.Drawing.Point(9, 280);
            this.Transmitters_button.Name = "Transmitters_button";
            this.Transmitters_button.Size = new System.Drawing.Size(131, 23);
            this.Transmitters_button.TabIndex = 58;
            this.Transmitters_button.Text = "Connected transmitters";
            this.Transmitters_button.UseVisualStyleBackColor = true;
            this.Transmitters_button.Click += new System.EventHandler(this.Transmitters_button_Click);
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(10, 309);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(171, 43);
            this.listBox2.TabIndex = 59;
            this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // Config_Button
            // 
            this.Config_Button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Config_Button.Location = new System.Drawing.Point(10, 380);
            this.Config_Button.Name = "Config_Button";
            this.Config_Button.Size = new System.Drawing.Size(131, 23);
            this.Config_Button.TabIndex = 60;
            this.Config_Button.Text = "Change Configuration";
            this.Config_Button.UseVisualStyleBackColor = true;
            this.Config_Button.Click += new System.EventHandler(this.Config_Button_Click);
            // 
            // Firmware_button
            // 
            this.Firmware_button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Firmware_button.Location = new System.Drawing.Point(203, 367);
            this.Firmware_button.Name = "Firmware_button";
            this.Firmware_button.Size = new System.Drawing.Size(111, 23);
            this.Firmware_button.TabIndex = 61;
            this.Firmware_button.Text = "Update Firmware";
            this.Firmware_button.UseVisualStyleBackColor = true;
            this.Firmware_button.Click += new System.EventHandler(this.Firmware_button_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(363, 213);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(70, 13);
            this.label27.TabIndex = 62;
            this.label27.Text = "Is Recording:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(363, 230);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(72, 13);
            this.label28.TabIndex = 63;
            this.label28.Text = "Is Camera on:";
            // 
            // SSID
            // 
            this.SSID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.SSID.Location = new System.Drawing.Point(126, 410);
            this.SSID.Name = "SSID";
            this.SSID.Size = new System.Drawing.Size(100, 20);
            this.SSID.TabIndex = 64;
            this.SSID.Text = "Dension WiRC";
            // 
            // WPA
            // 
            this.WPA.AutoSize = true;
            this.WPA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.WPA.Location = new System.Drawing.Point(9, 412);
            this.WPA.Name = "WPA";
            this.WPA.Size = new System.Drawing.Size(113, 17);
            this.WPA.TabIndex = 66;
            this.WPA.Text = "Is WPA else Open";
            this.WPA.UseVisualStyleBackColor = true;
            // 
            // Is_Accespoint
            // 
            this.Is_Accespoint.AutoSize = true;
            this.Is_Accespoint.Checked = true;
            this.Is_Accespoint.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Is_Accespoint.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Is_Accespoint.Location = new System.Drawing.Point(6, 438);
            this.Is_Accespoint.Name = "Is_Accespoint";
            this.Is_Accespoint.Size = new System.Drawing.Size(90, 17);
            this.Is_Accespoint.TabIndex = 67;
            this.Is_Accespoint.Text = "Is Accespoint";
            this.Is_Accespoint.UseVisualStyleBackColor = true;
            // 
            // Password
            // 
            this.Password.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Password.Location = new System.Drawing.Point(187, 435);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(100, 20);
            this.Password.TabIndex = 70;
            this.Password.Text = "1234";
            // 
            // ChanellNum
            // 
            this.ChanellNum.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ChanellNum.Location = new System.Drawing.Point(97, 435);
            this.ChanellNum.Maximum = new decimal(new int[] {
            13,
            0,
            0,
            0});
            this.ChanellNum.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ChanellNum.Name = "ChanellNum";
            this.ChanellNum.Size = new System.Drawing.Size(31, 20);
            this.ChanellNum.TabIndex = 71;
            this.ChanellNum.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            // 
            // Country
            // 
            this.Country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Country.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Country.FormattingEnabled = true;
            this.Country.Items.AddRange(new object[] {
            "AD   Andorra",
            "AE   United Arab Emirates",
            "AF   Afghanistan",
            "AG   Antigua and Barbuda",
            "AI   Anguilla",
            "AL   Albania",
            "AM   Armenia",
            "AN   Netherlands Antilles",
            "AO   Angola",
            "AQ   Antarctica",
            "AR   Argentina",
            "AS   American Samoa",
            "AT   Austria",
            "AU   Australia",
            "AW   Aruba",
            "AX   Aland Islands",
            "AZ   Azerbaijan",
            "BA   Bosnia and Herzegovina",
            "BB   Barbados",
            "BD   Bangladesh",
            "BE   Belgium",
            "BF   Burkina Faso",
            "BG   Bulgaria",
            "BH   Bahrain",
            "BI   Burundi",
            "BJ   Benin",
            "BM   Bermuda",
            "BN   Brunei Darussalam",
            "BO   Bolivia",
            "BR   Brazil",
            "BS   Bahamas",
            "BT   Bhutan",
            "BV   Bouvet Island",
            "BW   Botswana",
            "BY   Belarus",
            "BZ   Belize",
            "CA   Canada",
            "CC   Cocos (Keeling) Islands",
            "CD   Democratic Republic of the Congo",
            "CF   Central African Republic",
            "CG   Congo",
            "CH   Switzerland",
            "CI   Cote D\'Ivoire (Ivory Coast)",
            "CK   Cook Islands",
            "CL   Chile",
            "CM   Cameroon",
            "CN   China",
            "CO   Colombia",
            "CR   Costa Rica",
            "CS   Serbia and Montenegro",
            "CU   Cuba",
            "CV   Cape Verde",
            "CX   Christmas Island",
            "CY   Cyprus",
            "CZ   Czech Republic",
            "DE   Germany",
            "DJ   Djibouti",
            "DK   Denmark",
            "DM   Dominica",
            "DO   Dominican Republic",
            "DZ   Algeria",
            "EC   Ecuador",
            "EE   Estonia",
            "EG   Egypt",
            "EH   Western Sahara",
            "ER   Eritrea",
            "ES   Spain",
            "ET   Ethiopia",
            "FI   Finland",
            "FJ   Fiji",
            "FK   Falkland Islands (Malvinas)",
            "FM   Federated States of Micronesia",
            "FO   Faroe Islands",
            "FR   France",
            "FX   France, Metropolitan",
            "GA   Gabon",
            "GB   Great Britain (UK)",
            "GD   Grenada",
            "GE   Georgia",
            "GF   French Guiana",
            "GH   Ghana",
            "GI   Gibraltar",
            "GL   Greenland",
            "GM   Gambia",
            "GN   Guinea",
            "GP   Guadeloupe",
            "GQ   Equatorial Guinea",
            "GR   Greece",
            "GS   S. Georgia and S. Sandwich Islands",
            "GT   Guatemala",
            "GU   Guam",
            "GW   Guinea-Bissau",
            "GY   Guyana",
            "HK   Hong Kong",
            "HM   Heard Island and McDonald Islands",
            "HN   Honduras",
            "HR   Croatia (Hrvatska)",
            "HT   Haiti",
            "HU   Hungary",
            "ID   Indonesia",
            "IE   Ireland",
            "IL   Israel",
            "IN   India",
            "IO   British Indian Ocean Territory",
            "IQ   Iraq",
            "IR   Iran",
            "IS   Iceland",
            "IT   Italy",
            "JM   Jamaica",
            "JO   Jordan",
            "JP   Japan",
            "KE   Kenya",
            "KG   Kyrgyzstan",
            "KH   Cambodia",
            "KI   Kiribati",
            "KM   Comoros",
            "KN   Saint Kitts and Nevis",
            "KP   Korea (North)",
            "KR   Korea (South)",
            "KW   Kuwait",
            "KY   Cayman Islands",
            "KZ   Kazakhstan",
            "LA   Laos",
            "LB   Lebanon",
            "LC   Saint Lucia",
            "LI   Liechtenstein",
            "LK   Sri Lanka",
            "LR   Liberia",
            "LS   Lesotho",
            "LT   Lithuania",
            "LU   Luxembourg",
            "LV   Latvia",
            "LY   Libya",
            "MA   Morocco",
            "MC   Monaco",
            "MD   Moldova",
            "MG   Madagascar",
            "MH   Marshall Islands",
            "MK   Macedonia",
            "ML   Mali",
            "MM   Myanmar",
            "MN   Mongolia",
            "MO   Macao",
            "MP   Northern Mariana Islands",
            "MQ   Martinique",
            "MR   Mauritania",
            "MS   Montserrat",
            "MT   Malta",
            "MU   Mauritius",
            "MV   Maldives",
            "MW   Malawi",
            "MX   Mexico",
            "MY   Malaysia",
            "MZ   Mozambique",
            "NA   Namibia",
            "NC   New Caledonia",
            "NE   Niger",
            "NF   Norfolk Island",
            "NG   Nigeria",
            "NI   Nicaragua",
            "NL   Netherlands",
            "NO   Norway",
            "NP   Nepal",
            "NR   Nauru",
            "NU   Niue",
            "NZ   New Zealand (Aotearoa)",
            "OM   Oman",
            "PA   Panama",
            "PE   Peru",
            "PF   French Polynesia",
            "PG   Papua New Guinea",
            "PH   Philippines",
            "PK   Pakistan",
            "PL   Poland",
            "PM   Saint Pierre and Miquelon",
            "PN   Pitcairn",
            "PR   Puerto Rico",
            "PS   Palestinian Territory",
            "PT   Portugal",
            "PW   Palau",
            "PY   Paraguay",
            "QA   Qatar",
            "RE   Reunion",
            "RO   Romania",
            "RU   Russian Federation",
            "RW   Rwanda",
            "SA   Saudi Arabia",
            "SB   Solomon Islands",
            "SC   Seychelles",
            "SD   Sudan",
            "SE   Sweden",
            "SG   Singapore",
            "SH   Saint Helena",
            "SI   Slovenia",
            "SJ   Svalbard and Jan Mayen",
            "SK   Slovakia",
            "SL   Sierra Leone",
            "SM   San Marino",
            "SN   Senegal",
            "SO   Somalia",
            "SR   Suriname",
            "ST   Sao Tome and Principe",
            "SU   USSR (former)",
            "SV   El Salvador",
            "SY   Syria",
            "SZ   Swaziland",
            "TC   Turks and Caicos Islands",
            "TD   Chad",
            "TF   French Southern Territories",
            "TG   Togo",
            "TH   Thailand",
            "TJ   Tajikistan",
            "TK   Tokelau",
            "TL   Timor-Leste",
            "TM   Turkmenistan",
            "TN   Tunisia",
            "TO   Tonga",
            "TP   East Timor",
            "TR   Turkey",
            "TT   Trinidad and Tobago",
            "TV   Tuvalu",
            "TW   Taiwan",
            "TZ   Tanzania",
            "UA   Ukraine",
            "UG   Uganda",
            "UK   United Kingdom",
            "UM   United States Minor Outlying Islands",
            "US   United States",
            "UY   Uruguay",
            "UZ   Uzbekistan",
            "VA   Vatican City State (Holy See)",
            "VC   Saint Vincent and the Grenadines",
            "VE   Venezuela",
            "VG   Virgin Islands (British)",
            "VI   Virgin Islands (U.S.)",
            "VN   Viet Nam",
            "VU   Vanuatu",
            "WF   Wallis and Futuna",
            "WS   Samoa",
            "YE   Yemen",
            "YT   Mayotte",
            "YU   Yugoslavia (former)",
            "ZA   South Africa",
            "ZM   Zambia",
            "ZR   Zaire (former)",
            "ZW   Zimbabwe"});
            this.Country.Location = new System.Drawing.Point(6, 460);
            this.Country.Name = "Country";
            this.Country.Size = new System.Drawing.Size(117, 21);
            this.Country.TabIndex = 72;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label29.Location = new System.Drawing.Point(232, 413);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(32, 13);
            this.label29.TabIndex = 73;
            this.label29.Text = "SSID";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label30.Location = new System.Drawing.Point(293, 439);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(53, 13);
            this.label30.TabIndex = 74;
            this.label30.Text = "Password";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label31.Location = new System.Drawing.Point(129, 438);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(40, 13);
            this.label31.TabIndex = 75;
            this.label31.Text = "Chanel";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label32.Location = new System.Drawing.Point(124, 463);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(70, 13);
            this.label32.TabIndex = 76;
            this.label32.Text = "Country code";
            // 
            // RecordMJPEG_button
            // 
            this.RecordMJPEG_button.Location = new System.Drawing.Point(603, 175);
            this.RecordMJPEG_button.Name = "RecordMJPEG_button";
            this.RecordMJPEG_button.Size = new System.Drawing.Size(104, 23);
            this.RecordMJPEG_button.TabIndex = 78;
            this.RecordMJPEG_button.Text = "Record to MJPEG";
            this.RecordMJPEG_button.UseVisualStyleBackColor = true;
            this.RecordMJPEG_button.Click += new System.EventHandler(this.RecordMJPEG_button_Click);
            // 
            // RecordAVI
            // 
            this.RecordAVI.Location = new System.Drawing.Point(719, 175);
            this.RecordAVI.Name = "RecordAVI";
            this.RecordAVI.Size = new System.Drawing.Size(92, 23);
            this.RecordAVI.TabIndex = 79;
            this.RecordAVI.Text = "Record to AVI";
            this.RecordAVI.UseVisualStyleBackColor = true;
            this.RecordAVI.Click += new System.EventHandler(this.RecordAVI_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(352, 251);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(461, 242);
            this.pictureBox1.TabIndex = 80;
            this.pictureBox1.TabStop = false;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(105, 355);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(41, 13);
            this.label34.TabIndex = 81;
            this.label34.Text = "label34";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(7, 355);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(41, 13);
            this.label35.TabIndex = 82;
            this.label35.Text = "label35";
            // 
            // GetBackControl_button
            // 
            this.GetBackControl_button.Location = new System.Drawing.Point(185, 309);
            this.GetBackControl_button.Name = "GetBackControl_button";
            this.GetBackControl_button.Size = new System.Drawing.Size(81, 36);
            this.GetBackControl_button.TabIndex = 83;
            this.GetBackControl_button.Text = "Try to Get back control";
            this.GetBackControl_button.UseVisualStyleBackColor = true;
            this.GetBackControl_button.Click += new System.EventHandler(this.GetBackControl_button_Click);
            // 
            // RequestAcces_button
            // 
            this.RequestAcces_button.Location = new System.Drawing.Point(152, 280);
            this.RequestAcces_button.Name = "RequestAcces_button";
            this.RequestAcces_button.Size = new System.Drawing.Size(106, 23);
            this.RequestAcces_button.TabIndex = 84;
            this.RequestAcces_button.Text = "Request acces for";
            this.RequestAcces_button.UseVisualStyleBackColor = true;
            this.RequestAcces_button.Click += new System.EventHandler(this.RequestAcces_button_Click);
            // 
            // CheckIfHasControl_Timer
            // 
            this.CheckIfHasControl_Timer.Tick += new System.EventHandler(this.CheckIfHasControl_Timer_Tick);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(476, 223);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(77, 13);
            this.label36.TabIndex = 85;
            this.label36.Text = "Camera Count:";
            // 
            // numericUpDownCamID
            // 
            this.numericUpDownCamID.Location = new System.Drawing.Point(692, 144);
            this.numericUpDownCamID.Maximum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numericUpDownCamID.Name = "numericUpDownCamID";
            this.numericUpDownCamID.Size = new System.Drawing.Size(41, 20);
            this.numericUpDownCamID.TabIndex = 86;
            // 
            // CoffV
            // 
            this.CoffV.Location = new System.Drawing.Point(378, 93);
            this.CoffV.Name = "CoffV";
            this.CoffV.Size = new System.Drawing.Size(59, 20);
            this.CoffV.TabIndex = 89;
            this.CoffV.Text = "7000";
            // 
            // WiRCoffV
            // 
            this.WiRCoffV.Location = new System.Drawing.Point(378, 119);
            this.WiRCoffV.Name = "WiRCoffV";
            this.WiRCoffV.Size = new System.Drawing.Size(59, 20);
            this.WiRCoffV.TabIndex = 90;
            this.WiRCoffV.Text = "6000";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(443, 100);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(87, 13);
            this.label37.TabIndex = 91;
            this.label37.Text = "Camera off in mV";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(443, 122);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(79, 13);
            this.label38.TabIndex = 92;
            this.label38.Text = "WiRC off in mV";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(666, 204);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(41, 13);
            this.label39.TabIndex = 93;
            this.label39.Text = "label39";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(643, 223);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(41, 13);
            this.label40.TabIndex = 94;
            this.label40.Text = "label40";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(737, 204);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(41, 13);
            this.label41.TabIndex = 95;
            this.label41.Text = "label41";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(751, 223);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(41, 13);
            this.label42.TabIndex = 96;
            this.label42.Text = "label42";
            // 
            // VideoDrawTimer
            // 
            this.VideoDrawTimer.Interval = 13;
            this.VideoDrawTimer.Tick += new System.EventHandler(this.VideoDrawTimer_Tick);
            // 
            // avi_record
            // 
            this.avi_record.Interval = 15;
            this.avi_record.Tick += new System.EventHandler(this.avi_record_Tick);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(652, 100);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(95, 13);
            this.label33.TabIndex = 97;
            this.label33.Text = "WiRC-s new name";
            // 
            // NewName
            // 
            this.NewName.Location = new System.Drawing.Point(536, 97);
            this.NewName.Name = "NewName";
            this.NewName.Size = new System.Drawing.Size(100, 20);
            this.NewName.TabIndex = 98;
            this.NewName.Text = "WiRC_PC_demo";
            // 
            // ChangeName
            // 
            this.ChangeName.AutoSize = true;
            this.ChangeName.Location = new System.Drawing.Point(532, 119);
            this.ChangeName.Name = "ChangeName";
            this.ChangeName.Size = new System.Drawing.Size(144, 17);
            this.ChangeName.TabIndex = 99;
            this.ChangeName.Text = "Change(rename) on login";
            this.ChangeName.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(817, 496);
            this.Controls.Add(this.ChangeName);
            this.Controls.Add(this.NewName);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.WiRCoffV);
            this.Controls.Add(this.CoffV);
            this.Controls.Add(this.numericUpDownCamID);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.RequestAcces_button);
            this.Controls.Add(this.GetBackControl_button);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.RecordAVI);
            this.Controls.Add(this.RecordMJPEG_button);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.Country);
            this.Controls.Add(this.ChanellNum);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.Is_Accespoint);
            this.Controls.Add(this.WPA);
            this.Controls.Add(this.SSID);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.Firmware_button);
            this.Controls.Add(this.Config_Button);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.Transmitters_button);
            this.Controls.Add(this.OtherCheck_button);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.InputBool);
            this.Controls.Add(this.Camera);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.out4);
            this.Controls.Add(this.out3);
            this.Controls.Add(this.out2);
            this.Controls.Add(this.out1);
            this.Controls.Add(this.ser5);
            this.Controls.Add(this.ser6);
            this.Controls.Add(this.ser7);
            this.Controls.Add(this.ser8);
            this.Controls.Add(this.ser3);
            this.Controls.Add(this.ser4);
            this.Controls.Add(this.ser2);
            this.Controls.Add(this.ser1);
            this.Controls.Add(this.AllAtOne_Button);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.MaxServo);
            this.Controls.Add(this.TagetDegree);
            this.Controls.Add(this.MoveServoDegree_button);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.ServoPos);
            this.Controls.Add(this.ServoNumber);
            this.Controls.Add(this.MoveServo_button);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Status);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.JoyStart_button);
            this.Controls.Add(this.Disconect_button);
            this.Controls.Add(this.ServoPos_textBox);
            this.Controls.Add(this.MoveAll_button);
            this.Controls.Add(this.Connect_button);
            this.Controls.Add(this.subnet);
            this.Controls.Add(this.Find_button);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Dirty display of all dll functions an usage";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChanellNum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCamID)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer joystickStat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Find_button;
        private System.Windows.Forms.TextBox subnet;
        private System.Windows.Forms.Button Connect_button;
        private System.Windows.Forms.Button MoveAll_button;
        private System.Windows.Forms.TextBox ServoPos_textBox;
        private System.Windows.Forms.Button Disconect_button;
        private System.Windows.Forms.Button JoyStart_button;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Status;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Timer statusTimer;
        private System.Windows.Forms.Button MoveServo_button;
        private System.Windows.Forms.TextBox ServoNumber;
        private System.Windows.Forms.TextBox ServoPos;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button MoveServoDegree_button;
        private System.Windows.Forms.TextBox TagetDegree;
        private System.Windows.Forms.TextBox MaxServo;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button AllAtOne_Button;
        private System.Windows.Forms.TextBox ser1;
        private System.Windows.Forms.TextBox ser2;
        private System.Windows.Forms.TextBox ser3;
        private System.Windows.Forms.TextBox ser4;
        private System.Windows.Forms.TextBox ser5;
        private System.Windows.Forms.TextBox ser6;
        private System.Windows.Forms.TextBox ser7;
        private System.Windows.Forms.TextBox ser8;
        private System.Windows.Forms.CheckBox out1;
        private System.Windows.Forms.CheckBox out2;
        private System.Windows.Forms.CheckBox out4;
        private System.Windows.Forms.CheckBox out3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button Camera;
        private System.Windows.Forms.Button InputBool;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button OtherCheck_button;
        private System.Windows.Forms.Button Transmitters_button;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button Config_Button;
        private System.Windows.Forms.Button Firmware_button;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox SSID;
        private System.Windows.Forms.CheckBox WPA;
        private System.Windows.Forms.CheckBox Is_Accespoint;
        private System.Windows.Forms.TextBox Password;
        private System.Windows.Forms.NumericUpDown ChanellNum;
        private System.Windows.Forms.ComboBox Country;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button RecordMJPEG_button;
        private System.Windows.Forms.Button RecordAVI;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button GetBackControl_button;
        private System.Windows.Forms.Button RequestAcces_button;
        private System.Windows.Forms.Timer CheckIfHasControl_Timer;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.NumericUpDown numericUpDownCamID;
        private System.Windows.Forms.TextBox CoffV;
        private System.Windows.Forms.TextBox WiRCoffV;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Timer VideoDrawTimer;
        private System.Windows.Forms.Timer avi_record;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox NewName;
        private System.Windows.Forms.CheckBox ChangeName;
    }
}

