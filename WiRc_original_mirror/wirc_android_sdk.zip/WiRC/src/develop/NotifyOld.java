package develop;

import wirc.dension.com.WiRC;
import android.R;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.util.Log;


public class NotifyOld {
	
	private static Boolean enabled = false;
	
	private final static int NOTIFICATION_ID = 1;
    
    private Context mContext;
    private NotificationManager mNotificationManager;
    private PendingIntent pendingIntent;
    private Notification n;
    private static long timeStart = 0;
    
    public NotifyOld(Context context) {
        mContext = context;
        mNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
    }

    public void updateNotification(String title, String tickerText) {
    	if ( enabled ) {
    		try {
    			disableNotification();
    			
		    	Intent notificationIntent = new Intent(mContext, WiRC.class);
		    	notificationIntent.putExtra("title", title);
		    	notificationIntent.putExtra("tickerText", tickerText);
		        pendingIntent = PendingIntent.getActivity(mContext, 0, notificationIntent, 0);
		        
		    	n = new Notification(R.drawable.arrow_down_float, tickerText, 0);
		        n.setLatestEventInfo(mContext, title, tickerText, pendingIntent);
		        n.flags |= Notification.FLAG_ONGOING_EVENT | Notification.FLAG_NO_CLEAR;
		        mNotificationManager.notify(NOTIFICATION_ID, n);
    		}
    		catch (Throwable e) {
    		}
    	}
    }
    
    public void disableNotification() {
    	if ( enabled ) {
    		try {
    			mNotificationManager.cancel(NOTIFICATION_ID);
    		}
    		catch (Throwable e) {
    		}
    	}
    }
    
    public static void d(Object object, String message) {
    	if ( enabled ) {
    		try {
    			Log.d(object.toString(), message);
    		}
    		catch (Throwable e) {
    			Log.e("***", "***");
    		}
    	}
    }
    
    public static void e(Object object, String message) {
    	if ( enabled ) {
    		try {
    			Log.e(object.toString(), message);
    		}
    		catch (Throwable e) {
    		}
    	}
    }
    
    public static void timerStart() {
    	timeStart = SystemClock.elapsedRealtime();
    }
    
    public static long timerGet() {
    	return SystemClock.elapsedRealtime() - timeStart;
    }
}
