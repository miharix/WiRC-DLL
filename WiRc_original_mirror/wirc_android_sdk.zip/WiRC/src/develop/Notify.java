package develop;

import android.content.Context;
import android.util.Log;


public class Notify {
	
	private static Boolean enabled = true;
	
    public Notify(Context context) {
    }
    
    public static void d(Object object, Object... messages) {
    	if ( enabled ) {
    		try {
    			String message = "";
    			for (int i=0; i < messages.length; i++) {
    				if ( messages[i] != null ) {
   						message = message + messages[i].toString() + " ";
    				}
    				else {
    					message = message + "null ";
    				}
    			}
    			Log.d(object.toString(), message);
    		}
    		catch (Throwable e) {
    		}
    	}
    }
    
    public static void e(Object object, Object... messages) {
    	if ( enabled ) {
    		try {
    			String message = "";
    			for (int i=0; i < messages.length; i++) {
    				if ( messages[i] != null ) {
   						message = message + messages[i].toString() + " ";
    				}
    				else {
    					message = message + "null ";
    				}
    			}
    			Log.e(object.toString(), message);
    		}
    		catch (Throwable e) {
    		}
    	}
    }
}
