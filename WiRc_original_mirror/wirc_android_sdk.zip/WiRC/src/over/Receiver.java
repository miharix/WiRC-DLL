package over;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class Receiver extends BroadcastReceiver {
	
	private TimerService service;

	public Receiver(TimerService timerService) {
		this.service = timerService;
	}

	@Override
	public void onReceive(Context context, Intent intent) {
		String action = intent.getAction();
		
		if ( action.equals(TimerService.ACTION_STOP_SERVICE) ) {
			service.stopService();
		}
		if ( action.equals(TimerService.ACTION_CONNECT) ) {
			service.connect();
		}
		if ( action.equals(TimerService.ACTION_DISCONNECT) ) {
			service.disconnect();
		}
		/*
		if ( action.equals(TimerService.ACTION_RECORD_START) ) {
			service.startRecord();
		}
		if ( action.equals(TimerService.ACTION_RECORD_STOP) ) {
			service.stopRecord();
		}
		*/
		if ( action.equals(TimerService.ACTION_PLAY_START) ) {
			service.startPlay();
		}
		if ( action.equals(TimerService.ACTION_PLAY_STOP) ) {
			service.startPlay();
		}
		if ( action.equals(TimerService.ACTION_CAMERA_START) ) {
			service.startCamera();
		}
		if ( action.equals(TimerService.ACTION_CAMERA_STOP) ) {
			service.stopCamera();
		}
	}
}
