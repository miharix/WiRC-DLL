package over;

public class Status {
	
	public Boolean connected = false;

	public Status() {
		// TODO Auto-generated constructor stub
	}

}
