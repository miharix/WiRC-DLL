package over;

import java.util.ArrayList;

import joy.JoyArea;
import sensors.OrientationListener;
import settings.ChannelConfig;
import settings.ControlSettings;
import wirc.dension.com.R;
import wra.com.DriveActivity;
import wrc.WRCDevice;
import wrc.WRCList;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import buttonad.Buttons;
import camera.CameraStream;
import camera.MjpegDisplay;
import camera.Player;
import camera.Recorder;
import channel.ChannelCalculator;
import channel.ChannelInfo;
import channel.Hold;

import com.dension.messages.ChannelConfigurationMessage;
import com.dension.messages.EndStreamMessage;
import com.dension.messages.FailsafeConfigurationMessage;
import com.dension.messages.Message;
import com.dension.messages.PeriodicalStatusDataMessage;
import com.dension.messages.StartStreamMessage;
import com.dension.messages.TransmitterLoginMessage;
import com.dension.sqliteaccess.ChannelDTO;
import com.dension.sqliteaccess.ControlsTable;
import com.dension.sqliteaccess.WircDbAdapter;
import com.dension.wra.ChannelSettingsActivity;
import com.dension.wra.SettingsActivity;

import control.Control;
import control.PeriodicChannelData;
import control.PeriodicStatusData;
import develop.Notify;
import file.storage.ExternalStorage;

public class TimerService extends Service {

	public static final int majorHWVersion = 1;
	public static final int minorHWVersion = 4;
	public static final int majorFirmwareVersion = 1;
	public static final int minorFirmwareVersion = 4;
	public static final String firmware_md5 = "0ba4ed1c59ad02f332ae63f252b16379";
	// public static final String firmware_md5 = "3f6497669cb0fac8a1438b7f23eb64db";

	public static final String CLASS = "com.dension";
	public static final String ACTION_STOP_SERVICE = CLASS + ".ACTION_STOP_SERVICE";
	public static final String ACTION_CONNECT = CLASS + ".ACTION_CONNECT";
	public static final String ACTION_DISCONNECT = CLASS + ".ACTION_DISCONNECT";
	public static final String ACTION_DRIVE_START = CLASS + ".ACTION_DRIVE_START";
	public static final String ACTION_DRIVE_STOP = CLASS + ".ACTION_DRIVE_STOP";
	public static final String ACTION_RECORD_START = CLASS + ".ACTION_RECORD_START";
	public static final String ACTION_RECORD_STOP = CLASS + ".ACTION_RECORD_STOP";
	public static final String ACTION_PLAY_START = CLASS + ".ACTION_PLAY_START";
	public static final String ACTION_PLAY_STOP = CLASS + ".ACTION_PLAY_STOP";
	public static final String ACTION_CAMERA_START = CLASS + ".ACTION_CAMERA_START";
	public static final String ACTION_CAMERA_STOP = CLASS + ".ACTION_CAMERA_STOP";

	public static final int MSG_CONNECTED = 1;
	public static final int MSG_DISCONNECTED = 2;
	public static final int MSG_CONNECTION_ERROR = 3;
	public static final int MSG_CHANNEL_INITIALIZED = 4;
	public static final int MSG_ACCESS_GRANTED = 5;
	public static final int MSG_ACCESS_NOT_GRANTED = 6;
	public static final int MSG_BATTERY = 7;

	private BroadcastReceiver receiver = null;
	private static Handler serviceHandler;

	public static WRCList wrcList;

	public static DisplayMetrics displayMetrics;
	public ExternalStorage externalStorage;
	public static Status status;
	public static WircDbAdapter dbHelper;
	public static Control control;
	public static PeriodicStatusData periodicStatusData;
	public static PeriodicChannelData periodicChannelData;

	public PeriodicChannelData _periodicChannelData() {
		return periodicChannelData;
	}

	public static ChannelCalculator channelCalculator;
	public static ControlSettings controlSettings;
	public static CameraStream cameraStream;
	public static Thread cameraThread;
	public static MjpegDisplay mjpegDisplay;
	public static JoyArea joyArea_L;
	public static JoyArea joyArea_R;
	public static SensorEventListener orientationListener;
	public static DriveActivity driveActivity;
	public static SensorManager sensorManager;
	public static Buttons buttons;
	public static Recorder recorder;
	public Player player;
	public static Hold hold;

	public static int selectedWRCDevice = -1;
	public static int modeNum = ChannelInfo.DEFAULT_MODE;
	public static int modeCount = 4;
	public static Boolean serviceStarted = false;
	public static Boolean access = false;
	public static Boolean onDrive = false;
	public static Boolean useSensitivity = false;
	public static Boolean record = false;

	public boolean _record() {
		return record;
	}

	public static Boolean capture = false;

	public boolean _capture() {
		return capture;
	}

	public static String rootPath = "WRA/";
	public static float logicalDensity;
	public int cameraQuality = 1;
	public static int screenW = 0;
	public static int screenH = 0;

	public static SharedPreferences sharedPreferences;

	public static boolean developMode = false;

	public TimerService() {
		Notify.d(this, "");
	}

	@Override
	public IBinder onBind(Intent arg0) {
		Notify.d(this, "onBind");

		return null;
	}

	@Override
	public void onCreate() {
		super.onCreate();

		Notify.d(this, "onCreate");

		serviceStarted = false;
		status = new Status();

		dbHelper = new WircDbAdapter(this);
		dbHelper.open();

		wrcList = new WRCList(this, 1000);
		channelCalculator = ChannelCalculator.getChannelCalc(this);
		controlSettings = new ControlSettings(this);
		sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
		orientationListener = new OrientationListener();
		buttons = new Buttons(this);
		sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getBaseContext());

		registerServiceReceivers();
	}

	@Override
	public void onDestroy() {
		Notify.d(this, "onDestroy");

		serviceStarted = false;
		dbHelper.close();
		unregisterServiceReceivers();

		super.onDestroy();
	}

	@Override
	public void onStart(Intent intent, int startid) {
		super.onStart(intent, startid);
		try {
			Notify.d(this, "onStart");

			if (!dbHelper.isOpen()) {
				dbHelper.open();
			}

			if (!serviceStarted) {
				Notify.d(this, "start");

				serviceStarted = true;
				externalStorage = new ExternalStorage();
				serviceHandler.sendEmptyMessage(0);
				recorder = new Recorder(this, rootPath);
				hold = new Hold();

				Boolean firstRun = TimerService.sharedPreferences.getBoolean(getString(R.string.prefFirstRun), true);
				SharedPreferences.Editor editor = sharedPreferences.edit();
				editor.putBoolean(getString(R.string.prefFirstRun), false);
				editor.commit();
				if (firstRun)
					saveDefaultSettings(TimerService.getActiveProfileId());
			}
		} catch (Throwable e) {
			Notify.e(this, "onStart " + e.toString());
		}
	}

	public static void saveDefaultSettings(long profileID) {
		Notify.d(TimerService.class, "saveDefaultSettings()");

		ArrayList<ChannelConfig> channelConfigs;
		int modeNum = 0;
		ControlsTable controlsTable;

		modeNum = 1;
		channelConfigs = new ArrayList<ChannelConfig>();
		channelConfigs.add(new ChannelConfig("name1", 1));
		channelConfigs.add(new ChannelConfig("name1", 2));
		controlsTable = dbHelper.getControlsTable();
		for (int i = 0; i < channelConfigs.size(); ++i) {
			controlsTable.updateControl(i + 1, modeNum, channelConfigs.get(i).getValue(), profileID, 0);
		}

		modeNum = 2;
		channelConfigs = new ArrayList<ChannelConfig>();
		channelConfigs.add(new ChannelConfig("name1", 1));
		channelConfigs.add(new ChannelConfig("name1", 4));
		controlsTable = dbHelper.getControlsTable();
		for (int i = 0; i < channelConfigs.size(); ++i) {
			controlsTable.updateControl(i + 1, modeNum, channelConfigs.get(i).getValue(), profileID, 0);
		}

		ChannelDTO channelDTO;

		channelDTO = dbHelper.getChannelsTable().getChannelDTO(1, dbHelper.getProfilesTable().getActiveProfileId());
		channelDTO.name = "Steering";
		channelDTO.isReverse = 1;
		channelDTO.minValue = 1150;
		channelDTO.maxValue = 1850;
		channelDTO.trimValue = 1500;
		dbHelper.getChannelsTable().updateChannel(channelDTO);

		channelDTO = dbHelper.getChannelsTable().getChannelDTO(2, dbHelper.getProfilesTable().getActiveProfileId());
		channelDTO.name = "Speed";
		channelDTO.isReverse = 0;
		channelDTO.minValue = 1325;
		channelDTO.maxValue = 1700;
		channelDTO.trimValue = 1500;
		dbHelper.getChannelsTable().updateChannel(channelDTO);
	}

	// Service
	public void registerServiceReceivers() {
		if (receiver == null) {
			receiver = new Receiver(this);
			registerReceiver(receiver, new IntentFilter(ACTION_STOP_SERVICE));
			registerReceiver(receiver, new IntentFilter(ACTION_CONNECT));
			registerReceiver(receiver, new IntentFilter(ACTION_DISCONNECT));
			registerReceiver(receiver, new IntentFilter(ACTION_DRIVE_START));
			registerReceiver(receiver, new IntentFilter(ACTION_DRIVE_STOP));
			registerReceiver(receiver, new IntentFilter(ACTION_RECORD_START));
			registerReceiver(receiver, new IntentFilter(ACTION_RECORD_STOP));
			registerReceiver(receiver, new IntentFilter(ACTION_PLAY_START));
			registerReceiver(receiver, new IntentFilter(ACTION_PLAY_STOP));
			registerReceiver(receiver, new IntentFilter(ACTION_CAMERA_START));
			registerReceiver(receiver, new IntentFilter(ACTION_CAMERA_STOP));
		}
	}

	public void unregisterServiceReceivers() {
		if (receiver != null) {
			unregisterReceiver(receiver);
			receiver = null;
		}
	}

	public static void setServiceHandler(Handler handler) {
		serviceHandler = handler;
	}

	public void stopService() {
		this.stopSelf();

		Notify.d(this, "stopService");
	}

	// WRCList
	public static void discoverON(Handler handler) {
		if (serviceStarted)
			wrcList.discoverON(handler);
	}

	public static void discoverOFF() {
		if (serviceStarted)
			wrcList.discoverOFF();
	}

	public WRCDevice getSelectedWRCDevice() {
		return wrcList.deviceList.get(selectedWRCDevice);
	}

	public void connect() {
		if (status.connected)
			disconnect();

		cameraQuality = 1;
		String key = getString(R.string.settingCameraQuality);
		try {
			cameraQuality = Integer.parseInt(sharedPreferences.getString(key, Integer.toString(cameraQuality)));
		} catch (Throwable e) {
			Notify.e(this, e.toString());
		}

		try {
			access = false;
			useSensitivity = true;
			record = false;
			channelCalculator.init();
			driveActivity.connected_handler.sendEmptyMessage(MSG_CHANNEL_INITIALIZED);
			control = new Control(this, control_Listener);
			if (control.connect() || developMode) {
				periodicStatusData = new PeriodicStatusData(periodicStatusData_listener);
				periodicStatusData.start();
				sendTransmitterLoginMessage();
				sendChannelConfigurationMessageAndFailsafeConfigurationMessage();
			} else {
				driveActivity.connected_handler.sendEmptyMessage(MSG_CONNECTION_ERROR);
			}

			if (developMode) {
				Message msg = new Message(Message.MSG_CMD_WRCD_STARTUP, (byte) 0);
				control_Listener.OnMessage(msg);
				access = true;
				msg = new Message(Message.MSG_CMD_ACCESS_GRANTED, (byte) 0);
				control_Listener.OnMessage(msg);
				android.os.Message message = new android.os.Message();
				message.what = MSG_BATTERY;
				message.arg1 = 8000;
				driveActivity.connected_handler.sendMessage(message);
			}
		} catch (Throwable e) {
			Notify.d(this, "connect " + e.toString());
		}
	}

	private Control.Listener control_Listener = new Control.Listener() {
		@Override
		public void OnMessage(Message msg) {
			Notify.d(this, String.format("Message %x received", msg.getCmd()));

			if (Message.MSG_CMD_WRCD_STARTUP == msg.getCmd()) {
				Notify.d(this, "connected");

				status.connected = true;
				periodicChannelData = new PeriodicChannelData(getSelectedWRCDevice(), (short) 1500);
				startCamera();
				driveActivity.connected_handler.sendEmptyMessage(MSG_CONNECTED);
			}
			if (Message.MSG_CMD_ACCESS_GRANTED == msg.getCmd()) {
				if (access) {
					driveActivity.connected_handler.sendEmptyMessage(MSG_ACCESS_GRANTED);
				} else {
					driveActivity.connected_handler.sendEmptyMessage(MSG_ACCESS_NOT_GRANTED);
				}
			}
		}

		@Override
		public void OnDisconnect() {
			driveActivity.connected_handler.sendEmptyMessage(MSG_DISCONNECTED);
		}
	};

	private PeriodicStatusData.Listener periodicStatusData_listener = new PeriodicStatusData.Listener() {
		@Override
		public void OnMessage(PeriodicalStatusDataMessage msg) {
			android.os.Message message = new android.os.Message();
			message.what = MSG_BATTERY;
			message.arg1 = msg.getBattery(0);
			driveActivity.connected_handler.sendMessage(message);
		}
	};

	private void sendTransmitterLoginMessage() {
		SharedPreferences prefs = getSharedPreferences("TransmitterSettings", 0);
		String trName = prefs.getString(SettingsActivity.KEY_TR_NAME, SettingsActivity.DEFAULT_TRANSMITTER_NAME);
		int trPriority = prefs.getInt(SettingsActivity.KEY_TR_PRIO, 0);
		TransmitterLoginMessage tl = new TransmitterLoginMessage((byte) 2, (byte) 0, (byte) 1, (byte) trPriority, trName, periodicStatusData.getPSDPort());
		control.sendMsg(tl);
	}

	public static long getActiveProfileId() {
		long profileId = dbHelper.getProfilesTable().getActiveProfileId();

		return profileId;
	}

	private void sendChannelConfigurationMessageAndFailsafeConfigurationMessage() {
		long profileId = dbHelper.getProfilesTable().getActiveProfileId();
		Cursor cursor = dbHelper.getChannelsTable().fechChannelsByProfile(profileId);

		ChannelConfigurationMessage channelConfigurationMessage = new ChannelConfigurationMessage();
		FailsafeConfigurationMessage failsafeConfigurationMessage = new FailsafeConfigurationMessage();
		for (int i = 0; i < cursor.getCount(); i++) {
			channelConfigurationMessage.putValue((short) i, (short) cursor.getInt(cursor.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_REPEAT_FQ)));
			int failsafeMode = cursor.getInt(cursor.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_FAILSAFE_MODE));
			if (failsafeMode == ChannelSettingsActivity.FAILSAFE_DISABLE) {
				failsafeConfigurationMessage.putValue((short) i, (short) 0x0000);
			} else if (failsafeMode == ChannelSettingsActivity.FAILSAFE_LAST_GOOD) {
				failsafeConfigurationMessage.putValue((short) i, (short) 0xFFFF);
			} else {
				failsafeConfigurationMessage.putValue((short) i, (short) cursor.getInt(cursor.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_FAILSAFE_PRESET)));
			}
			cursor.moveToNext();
		}
		cursor.close();

		channelConfigurationMessage.assemble();
		control.sendMsg(channelConfigurationMessage);
		failsafeConfigurationMessage.assemble();
		control.sendMsg(failsafeConfigurationMessage);
	}

	public void startCamera() {
		try {
			if (status.connected) {
				if (control.getWrcdStartupMessage().getCameraNum() > 0) {
					Notify.d(this, "startCamera");

					if (mjpegDisplay != null) {
						mjpegDisplay.useOriginalRatio = false;
						cameraStream = new CameraStream(this, mjpegDisplay);
					}
					cameraThread = new Thread(cameraStream);
					cameraThread.start();
					StartStreamMessage stst = new StartStreamMessage((byte) 0, cameraStream.getPort());
					control.sendMsg(stst);
				}
			}
		} catch (Throwable e) {
			Notify.e(this, "startCamera() " + e.toString());
		}
	}

	public void stopCamera() {
		if (cameraStream != null) {
			EndStreamMessage est = new EndStreamMessage((byte) 0);
			control.sendMsg(est);
			stopRecord();
			cameraStream.exit();
			cameraStream = null;
		}
		if (cameraThread != null) {
			cameraThread.interrupt();
			cameraThread = null;
		}
	}

	public static boolean startRecord(boolean capture) {
		if (cameraStream != null) {
			if (!record) {
				record = true;
				record = recorder.start(capture);
			}
		}

		return record;
	}

	public static void stopRecord() {
		if (record) {
			record = false;
			recorder.stop();
		}
	}

	public void startPlay() {
		/*
		if ( cameraThread != null )
			cameraThread.interrupt();
		player = new Player(this, mjpegDisplay, "WRA/");
		player.start("record.mpeg");
		*/

	}

	public void stopPlay() {
		if (player != null)
			player.stop();
	}

	public void disconnect() {
		Notify.d(this, "disconnect");

		status.connected = false;
		channelCalculator.clear();
		stopCamera();
		stopRecord();
		/*
		if ( cameraStream != null ) {
			stopRecord();
			cameraStream.exit();
			cameraStream = null;
		}
		if ( cameraThread != null ) {
			cameraThread.interrupt();
		}
		*/
		if (periodicChannelData != null)
			periodicChannelData.stop();
		if (periodicStatusData != null)
			periodicStatusData.stop();
		control.disconnect();
	}

}
