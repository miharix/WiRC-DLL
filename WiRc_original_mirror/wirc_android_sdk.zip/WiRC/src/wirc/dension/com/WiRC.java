package wirc.dension.com;

import java.util.ArrayList;

import over.TimerService;
import wra.com.DriveActivity;
import wrc.WRCArrayAdapter;
import wrc.WRCDevice;
import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.ImageButton;
import android.widget.ListView;

import camera.MjpegDisplay;

import com.dension.wra.SettingsActivity;

import develop.Notify;

public class WiRC extends ListActivity {
    
	private Context context;
	private PowerManager.WakeLock wakeLock;
	
	private ArrayList<WRCDevice> deviceList;
	private WRCArrayAdapter wrcArrayAdapter;
	
	public static ListView wrcListView;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        TimerService.displayMetrics = displayMetrics;
        
        context = getApplicationContext();
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
		wakeLock = powerManager.newWakeLock(PowerManager.FULL_WAKE_LOCK, "DoNotDimScreen");
        
        TimerService.setServiceHandler(timerService_handler);
        
        Intent serviceIntent = new Intent(context, TimerService.class);
        startService(serviceIntent);
        
        deviceList = new ArrayList<WRCDevice>();
        wrcArrayAdapter = new WRCArrayAdapter(context, 0, deviceList);
        wrcListView = this.getListView();
        
        ((ImageButton) findViewById(R.main.button_settings)).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent(context, SettingsActivity.class);
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				context.startActivity(intent);
			}
        });
        
        ((ImageButton) findViewById(R.main.button_connect)).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				startDrive(1);
				
			}
        });
        
        ((ImageButton) findViewById(R.main.button_learn)).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.wirc.dension.com/"));
				startActivity(browserIntent);
			}
        });
        
        ((ImageButton) findViewById(R.main.button_demo)).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				startDrive(0);
			}
        });
    }

    
    @Override
    public void onResume() {
    	super.onResume();
    	
    	TimerService.discoverON(handler);
    	wakeLock.acquire();
    }
    
    @Override
    public void onPause() {
    	TimerService.discoverOFF();
    	super.onPause();
    	wakeLock.release();
    }
    
    @Override
    public void onDestroy() {
    	// sendBroadcastIntent(TimerService.ACTION_STOP_SERVICE);
    	
    	Intent serviceIntent = new Intent(context, TimerService.class);
        stopService(serviceIntent);
        
    	super.onDestroy();
    }
    
    private Handler timerService_handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			wrcListView.setAdapter(wrcArrayAdapter);
			TimerService.discoverON(handler);
		}
    };
    
    private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			deviceList.clear();
			for (int i=0; i < TimerService.wrcList.deviceList.size(); i++) {
				deviceList.add(TimerService.wrcList.deviceList.get(i));
			}
			wrcListView.setAdapter(wrcArrayAdapter);
		}
    };
    
    public void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		
		startDrive(position);
    }
    
    private void startDrive(int position) {
    	if ( wrcArrayAdapter.getCount() > position ) {
			TimerService.selectedWRCDevice = position;
			
			Intent intent = new Intent(context, DriveActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(intent);
		}
    }
    
    public void onConfigurationChanged(Configuration newConfig) {
    	super.onConfigurationChanged(newConfig);
    	/*
    	ImageView imageView_back = (ImageView) findViewById(R.main.imageView_back);
    	switch ( newConfig.orientation ) {
    	case Configuration.ORIENTATION_LANDSCAPE:
    		imageView_back.setImageResource(R.drawable.back_start_land);
    		break;
    	case Configuration.ORIENTATION_PORTRAIT:
    		imageView_back.setImageResource(R.drawable.back_start_port);
    		break;
    	}
    	*/
    }
    
    public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ( keyCode == KeyEvent.KEYCODE_BACK ) {
			finish();
			
			return true;
		}
		
		return super.onKeyDown(keyCode, event);
    }
    
    public void sendBroadcastIntent(String action) {
		Intent intent = new Intent();
		intent.setAction(action);
		sendBroadcast(intent);
	};
    
}