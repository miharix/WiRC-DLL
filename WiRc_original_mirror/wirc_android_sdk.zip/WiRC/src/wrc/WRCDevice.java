package wrc;

public class WRCDevice {
	private String name;
	private byte majorHardwareVersion;
	private byte minorHardwareVersion;
	private byte majorSoftwareVersion;
	private byte minorSoftwareVersion;
	private String serial = "";
	private String ip = "";
	
	public Boolean found = false;
	
	/* constructor */
	WRCDevice(
		String name, String ip, String serial, 
		byte majorHardwareVersion, byte minorHardwareVersion,
		byte majorSoftwareVersion, byte minorSoftwareVersion
	) {
		this.name = name;
		this.ip = ip;
		this.serial = serial;
		this.majorHardwareVersion = majorHardwareVersion;
		this.minorHardwareVersion = minorHardwareVersion;
		this.majorSoftwareVersion = majorSoftwareVersion;
		this.minorSoftwareVersion = minorSoftwareVersion;
		this.found = true;
	}
	
	/* shorter constructor */
	WRCDevice(String name, String ip) {
		this(name, ip, "", (byte) 0,(byte) 0, (byte) 0, (byte) 0);
	}
	
	public String getName() {
		return name;
	}
	
	public String getIp() {
		return ip;
	}
	
	public String getSerial() {
		return serial;
	}

	public byte getMajorHardwareVersion() {
		return majorHardwareVersion;
	}
	
	public byte getMinorHardwareVersion() {
		return minorHardwareVersion;
	}
	
	public byte getMajorSoftwareVersion() {
		return majorSoftwareVersion;
	}
	
	public byte getMinorSoftwareVersion() {
		return minorSoftwareVersion;
	}
}
