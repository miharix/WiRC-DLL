package wrc;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;

import wra.com.Global;
import android.content.Context;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Handler;

import com.dension.messages.BroadcastServiceAdvertisementMessage;
import com.dension.messages.BroadcastServiceDiscoveryMessage;
import com.dension.messages.Message;

import develop.Notify;

public class WRCList {

	private Context context;
	private Handler handler;
	private int timeout = 5000;
	private Boolean onDiscoverTask = false;
	private InetAddress inetAddress = null;

	public ArrayList<WRCDevice> deviceList;
	public int selected = -1;

	public WRCList(Context context, int timeout) {
		this.context = context;
		this.timeout = timeout;
		deviceList = new ArrayList<WRCDevice>();
		deviceList.add(new WRCDevice("Offline test", ""));
	}

	public void discoverON(Handler handler) {
		this.handler = handler;

		if (!onDiscoverTask) {
			Notify.d(this, "discoverON");

			handler.sendEmptyMessage(0);
			inetAddress = getBroadcastAddress();
			onDiscoverTask = true;
			new DiscoverTask().execute();
		}
	}

	public void discoverOFF() {
		Notify.d(this, "discoverOFF");
		onDiscoverTask = false;
	}

	private class DiscoverTask extends AsyncTask<Void, Void, Void> {
		DatagramSocket socket = null;
		DatagramPacket packet = null;

		@Override
		protected Void doInBackground(Void... arg0) {
			try {
				if (inetAddress == null) {
					handler.sendEmptyMessage(0);
				} else {
					while (onDiscoverTask) {
						for (int i = 1; i < deviceList.size(); i++)
							deviceList.get(i).found = false;

						try {
							socket = new DatagramSocket();
							socket.setBroadcast(true);
							socket.setSoTimeout(timeout);

							byte[] rawPacket = (new BroadcastServiceDiscoveryMessage((byte) 0x00, (byte) 0, (byte) 1)).getRaw();

							packet = new DatagramPacket(rawPacket, rawPacket.length, inetAddress, Global.BROADCAST_SERVICE_UDP_PORT);

							socket.send(packet);
							rawPacket = new byte[Message.MSG_MAX_RAW_LEN];
							packet = new DatagramPacket(rawPacket, rawPacket.length);

							socket.receive(packet);
							BroadcastServiceAdvertisementMessage bcsa = new BroadcastServiceAdvertisementMessage(packet.getData(), packet.getLength());
							if (bcsa.isValid) {
								WRCDevice wrcDevice = findDeviceBySerial(bcsa.getSerial());
								if (wrcDevice == null) {
									deviceList.add(new WRCDevice(bcsa.getWRCName(), addrToString(packet.getAddress()), bcsa.getSerial(), bcsa.getHwMajor(), bcsa.getHwMinor(), bcsa.getSwMajor(), bcsa.getSwMinor()));
								} else {
									wrcDevice.found = true;
								}
							} else {
								Notify.d(this, "error");
							}
						} catch (Throwable e) {
							Notify.e(this, e.toString());
							// deviceList.clear();
						} finally {
							socket.close();
						}

						int i = 0;
						while (i < deviceList.size()) {
							if (deviceList.get(i).found)
								i++;
							else
								deviceList.remove(i);
						}

						handler.sendEmptyMessage(0);

						Thread.sleep(1000);
					}
				}
			} catch (Throwable e) {
				Notify.e(this, "DiscoverTask " + e.toString());
			}

			return null;
		}

	}

	public WRCDevice findDeviceBySerial(String serial) {
		WRCDevice wrcDevice = null;

		int i = 0;
		while ((wrcDevice == null) && (i < deviceList.size())) {
			if (deviceList.get(i).getSerial() == serial)
				wrcDevice = deviceList.get(i);
			i++;
		}

		return wrcDevice;
	}

	public static String addrToString(InetAddress address) {
		byte[] bytes = address.getAddress();
		return String.format("%d.%d.%d.%d", (bytes[0] & 0xFF), (bytes[1] & 0xFF), (bytes[2] & 0xFF), (bytes[3] & 0xFF));
	}

	private InetAddress getBroadcastAddress() {
		InetAddress inetAddress = null;

		try {
			WifiManager wifi = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
			if (wifi.isWifiEnabled()) {
				DhcpInfo dhcp = wifi.getDhcpInfo();
				int broadcast = (dhcp.ipAddress & dhcp.netmask) | ~dhcp.netmask;
				byte[] quads = new byte[4];
				for (int k = 0; k < 4; k++)
					quads[k] = (byte) ((broadcast >> k * 8) & 0xFF);
				inetAddress = InetAddress.getByAddress(quads);
			}
		} catch (Throwable e) {
			Notify.e(this, e.toString());
		}

		return inetAddress;
	}

}
