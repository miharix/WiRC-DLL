package wrc;

import java.util.List;

import wirc.dension.com.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class WRCArrayAdapter extends ArrayAdapter<WRCDevice> {
	
	private Context context;
	private List<WRCDevice> items;
	
	public WRCArrayAdapter(Context context, int textViewResourceId, List<WRCDevice> items) {
		super(context, textViewResourceId, items);
		
		this.context = context;
		this.items = items;
	}
	
	public View getView(int position, View convertView, ViewGroup parent) {
		View view = convertView;
		
		/*
		if (view == null) {
			LayoutInflater layoutInflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			view = layoutInflater.inflate(R.layout.wrc_list_item, null);
		}
		*/
		
		LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		view = layoutInflater.inflate(R.layout.wrc_list_item, null);
		
		WRCDevice wrcDevice = null;
		
		if ( items != null )
			if ( items.size() > position )
				wrcDevice = items.get(position);
		
		if ( wrcDevice != null ) {
			TextView textView_name = (TextView) view.findViewById(R.wrc_list_item.textView_name);
			textView_name.setText(wrcDevice.getName());
			TextView textView_serial = (TextView) view.findViewById(R.wrc_list_item.textView_serial);
			textView_serial.setText(wrcDevice.getSerial());
		}
		
		if ( position == 0 )
			view.setVisibility(View.GONE);
		else
			view.setVisibility(View.VISIBLE);
		
		view.invalidate();
		
		return view;
	}

}
