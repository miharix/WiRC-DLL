package menu;

import java.util.ArrayList;

import wirc.dension.com.R;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;

public class Menu {
	
	private Context context;
	private ViewGroup viewGroup;
	private MenuListener menuListener;

	public Menu(Context context, ViewGroup viewGroup, MenuListener menuListener) {
		this.context = context;
		this.viewGroup = viewGroup;
		this.menuListener = menuListener;
	}
	
	public void init(ArrayList<String> list, int selected) {
		viewGroup.removeAllViews();
		Button button;
    	for (int i = 0; i < list.size(); i++) {
    		button = new Button(context);
    		button.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
    		button.setText(list.get(i));
    		button.setTag(i);
    		button.setOnClickListener(onClickListener_button);
    		viewGroup.addView(button);
    	}
    	button = (Button) viewGroup.getChildAt(selected);
    	button.setTextColor(context.getResources().getColor(R.color.c_selected));
    	
    	viewGroup.invalidate();
	}
	
	public void clear() {
		viewGroup.removeAllViews();
		viewGroup.invalidate();
	}
	
	public OnClickListener onClickListener_button = new OnClickListener() {
		public void onClick(View v) {
			if ( v != null ) {
				Button button;
				for (int i=0; i < viewGroup.getChildCount(); i++) {
					button = (Button) viewGroup.getChildAt(i);
					button.setTextColor(context.getResources().getColor(R.color.c_normal));
				}
				button = (Button) v;
				button.setTextColor(context.getResources().getColor(R.color.c_selected));
				if ( menuListener != null ) {
					int index = (Integer) v.getTag();
					menuListener.onItemClick(index);
				}
			}
		}
    };
    
	public interface MenuListener {
		public abstract void onItemClick(int index);
	}

}
