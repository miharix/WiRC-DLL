package dialog;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

public class Dialog {
	
	private AlertDialog alertDialog;
	
	private DialogInterface.OnClickListener listener;
	
	public Dialog (Context context, DialogInterface.OnClickListener listener) {
		this.listener = listener;
		alertDialog = new AlertDialog.Builder(context).create();
	}
	
	public void message(String title, String text, String button) {
		alertDialog.setTitle(title);
		alertDialog.setMessage(text);
		alertDialog.setButton(button, listener);
		alertDialog.show();
	}
	
	public void message(String title, String text, String button, String button2) {
		alertDialog.setTitle(title);
		alertDialog.setMessage(text);
		alertDialog.setButton(button, listener);
		alertDialog.setButton2(button2, listener);
		alertDialog.show();
	}

}
