package file.storage;

import java.io.File;

import develop.Notify;

import android.os.Environment;

public class ExternalStorage {
	
	public File externalStorage;

	public ExternalStorage() {
		externalStorage = Environment.getExternalStorageDirectory();
	}
	
	public Boolean isReady() {
		Boolean ready = false;
		
		String state = android.os.Environment.getExternalStorageState();
		ready = state.equals(android.os.Environment.MEDIA_MOUNTED); 
		
		return ready;
	}
	
	public String getAbsolutePath() {
		String path = "";
		
		try {
			path = externalStorage.getAbsolutePath();
		}
		catch (Throwable e) {
		}
		
		return path;
	}
	
	public Boolean fileExists(String path) {
		File file = new File(path);
		
		return file.exists();
	}
	
	public Boolean mkdirs(String path) {
		Boolean sucess = false;
		
		File file = new File(path);
		try {
			if ( file.exists() )
				sucess = true;
			else
				sucess = file.mkdirs();
		}
		catch (Throwable e) {
		}
		
		return sucess;
	}
	
	public Boolean mkdirsFromFileName(String fileName) {
		Boolean sucess = false;
		
		try {
			if ( isReady() ) {
				String path = new File(fileName).getParentFile().getAbsolutePath();
				sucess = mkdirs(path);
			}
		}
		catch (Throwable e) {
		}
		
		return sucess;
	}
	
	public void createFile(String fileName) {
		File file = new File(fileName);
		try {
			file.createNewFile();
		} 
		catch (Throwable e) {
		}
	}
	
	public boolean deleteFile(String fileName) {
		boolean success = false;
		
		File file = new File(fileName);
		try {
			success = file.delete();
		} 
		catch (Throwable e) {
			Notify.e(this, "deleteFile() " + e.toString());
		}
		
		return success;
	}
	
	/*
	public String generateRandomString(int count) {
		String randomString = "";
		
		try {
			for (int i = 0; i < count; i++) {
				double d = Math.random();
				int r = (int) (d * 10);
				randomString = randomString + Integer.toString(r);
			}
		} 
		catch (Throwable e) {
		}
		
		return randomString;
	}
	
	public String mkdrirsRandom(String root, int count) {
		String randomString = "";
		Boolean success = false;
		
		try {
			while ( ! success ) {
				randomString = generateRandomString(count);
				if ( ! fileExists(root + randomString) ) {
					mkdirs(root + randomString);
					success = fileExists(root + randomString);
				}
			}
		} 
		catch (Throwable e) {
		}
		
		return randomString;
	}
	*/

}
