package settings;

public class ChannelConfig {

	private String name;
	private int value;

	public ChannelConfig() {
		name = null;
		value = 0;
	}

	public ChannelConfig(String name, int value) {
		this.name = name;
		this.value = value;
	}

	public String getChannelName() {
		return name;
	}

	public void setChannelName(String name) {
		this.name = name;
	}

	public int getValue() {
		return value;
	}

	public String getValueName() {
		if ((value >= 0) && (value < ControlSettings.configValues.length))
			return ControlSettings.configValues[value];
		else
			return null;
	}

	public void setValue(int value) {
		this.value = value;
	}

}
