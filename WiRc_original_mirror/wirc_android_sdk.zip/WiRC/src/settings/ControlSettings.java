package settings;

import java.util.ArrayList;

import over.TimerService;
import wirc.dension.com.R;
import android.content.Context;
import android.database.Cursor;
import channel.ChannelInfo;

import com.dension.sqliteaccess.ControlsTable;

public class ControlSettings {
	
	/*
	public static final String[] configValues = new String[] { 
		"None",
		"Right Joystick X", "Right Joystick Y", "Left Joystick X",
		"Left Joystick Y", "Gyro X", "Gyro Z", "Button A", "Button B",
		"Button C", "Button D", };
	*/
	private Context context;
	public ChannelConfig[] channelCfg;
	private long profileId;

	public ArrayList<ChannelConfig> channelConfigs;
	public static String[] configValues;
	public String[] _configValues() {
		return configValues;
	}
	public int selectedChannel = -1;

	public ControlSettings(Context context) {
		this.context = context;
		configValues = context.getResources().getStringArray(R.array.a_Controls);
	}
	
	public ArrayList<String> getModes() {
		ArrayList<String> list = new ArrayList<String>();
		
		String a_Mode[] = context.getResources().getStringArray(R.array.a_Mode);
		for (int i=0; i < a_Mode.length; i++) {
			list.add(a_Mode[i]);
		}
		
		return list;
	}
	
	public void init(int modeNum) {
		profileId = TimerService.dbHelper.getProfilesTable().getActiveProfileId();
		channelCfg = new ChannelConfig[12];
		channelConfigs = new ArrayList<ChannelConfig>();
		int[] cfgs = new int[channelCfg.length];
		for (int i = 0; i < ChannelInfo.CHANNELS; ++i) {
			Cursor control = TimerService.dbHelper.getControlsTable().fetchControl(i + 1, profileId, modeNum, false);
			cfgs[i] = control.getInt(control.getColumnIndexOrThrow(ControlsTable.KEY_SOURCE_NUM));
			channelConfigs.add(new ChannelConfig(control.getString(control.getColumnIndexOrThrow(ControlsTable.KEY_NAME)), cfgs[i]));
		}
		for (int i = 0; i < ChannelInfo.DIGITAL_CHANNELS; ++i) {
			Cursor control = TimerService.dbHelper.getControlsTable().fetchControl(i + 1,
					profileId, modeNum, true);
			cfgs[ChannelInfo.CHANNELS + i] = control
					.getInt(control
							.getColumnIndexOrThrow(ControlsTable.KEY_SOURCE_NUM));
			channelConfigs
					.add(new ChannelConfig(
							control.getString(control
									.getColumnIndexOrThrow(ControlsTable.KEY_NAME)),
							cfgs[ChannelInfo.CHANNELS + i]));
		}

		channelConfigs.add(new ChannelConfig("Hold Position", -1));
		channelConfigs.add(new ChannelConfig("Button A", -1));
		channelConfigs.add(new ChannelConfig("Button B", -1));
		channelConfigs.add(new ChannelConfig("Button C", -1));
		channelConfigs.add(new ChannelConfig("Button D", -1));
	}
	
	public ArrayList<String> getChannels() {
		ArrayList<String> list = new ArrayList<String>();
		
		for (int i=0; i < channelConfigs.size(); i++) {
			list.add(channelConfigs.get(i).getChannelName());
		}
		
		return list;
	}
	
	public void saveSettings() {
		for (int i = 0; i < ChannelInfo.CHANNELS; ++i) {
			TimerService.dbHelper.getControlsTable().updateControl(i + 1, TimerService.modeNum,
					channelConfigs.get(i).getValue(), profileId, 0);
		}
		for (int i = ChannelInfo.CHANNELS; i < ChannelInfo.CHANNELS
				+ ChannelInfo.DIGITAL_CHANNELS; ++i) {
			TimerService.dbHelper.getControlsTable().updateControl(
					i + 1 - ChannelInfo.CHANNELS, TimerService.modeNum,
					channelConfigs.get(i).getValue(), profileId, 1);
		}
	}

}
