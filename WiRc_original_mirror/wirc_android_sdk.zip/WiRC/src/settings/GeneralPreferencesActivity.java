package settings;

import wirc.dension.com.R;
import android.os.Bundle;
import android.preference.PreferenceActivity;

public class GeneralPreferencesActivity extends PreferenceActivity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    
	    addPreferencesFromResource(R.xml.preferences);
	}

}
