package list;

import java.util.List;

import wirc.dension.com.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class ListSelectorAdapter extends ArrayAdapter<ListSelectorItem> {
	
	private Context context;
	private List<ListSelectorItem> items;

	public ListSelectorAdapter(Context context, int textViewResourceId,	List<ListSelectorItem> items) {
		super(context, textViewResourceId, items);
		
		this.context = context;
		this.items = items;
	}
	
	public View getView(int position, View convertView, ViewGroup parent) {
		View view = convertView;
		ListSelectorItem listSelectorItem;
		
		if (view == null) {
			LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			view = layoutInflater.inflate(R.layout.listselector_item, null);
		}
			
		listSelectorItem = items.get(position);
		if ( listSelectorItem != null ) {
			((TextView) view.findViewById(R.layout.listselector_item)).setText(listSelectorItem.name);
		}
		
		view.invalidate();
		
		return view;
	}
	
	@Override
	public int getCount() {
		int count = 0;
		
		if ( items != null )
			count = items.size(); 
			
		return count;
	}

}
