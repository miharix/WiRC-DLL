package list;

import android.app.ListActivity;
import android.os.Bundle;

public class ListSelectorActivity extends ListActivity  {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

}
