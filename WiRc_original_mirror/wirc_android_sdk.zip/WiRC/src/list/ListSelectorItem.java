package list;

public class ListSelectorItem {
	
	public String name = "";

	public ListSelectorItem(String name) {
		this.name = name;
	}

}
