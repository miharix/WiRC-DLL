package ftp;

import java.io.BufferedInputStream;
import java.io.InputStream;

import org.apache.commons.net.ftp.FTPClient;

import android.os.AsyncTask;
import android.os.Handler;
import develop.Notify;

public class FTP {
	
	public final static int SUCCESS = 1;
	public final static int ERROR = 2;
	
	private FTPClient ftpClient;
	private Handler handler;
	private UploadStreamTask uploadStreamTask;
	
	public FTP(Handler handler) {
		this.handler = handler;
		
		try {
			ftpClient = new FTPClient();
		}
		catch (Throwable e) {
			Notify.e(this, "FTP " + e.toString());
		}
	}
	
	public void connect(String host) {
		try {
			disconnect();
			ftpClient.connect(host);
		} 
		catch (Throwable e) {
			Notify.e(this, "connect() " + e.toString());
		}
	}
	
	public void disconnect() {
		try {
			if ( ftpClient.isConnected() ) {
				ftpClient.disconnect();
			}
		} 
		catch (Throwable e) {
			Notify.e(this, "disconnect() " + e.toString());
		}
		
	}
	
	public void uploadStream(String remoteName, InputStream inputStream) {
		Boolean success = false;
		try {
			if ( ftpClient.isConnected() ) {
				uploadStreamTask = new UploadStreamTask();
				uploadStreamTask.remoteName = remoteName;
				uploadStreamTask.inputStream = inputStream;
				uploadStreamTask.execute();
				success = true;
			}
		} 
		catch (Throwable e) {
			Notify.e(this, "uploadStream() " + e.toString());
		}
		
		if ( ! success )
			sendError();
		
	}	
	
	private class UploadStreamTask extends AsyncTask<Void, Void, Void> {
		public String remoteName = "";
		public InputStream inputStream;
		public int fileType = org.apache.commons.net.ftp.FTP.BINARY_FILE_TYPE;

		@Override
		protected Void doInBackground(Void... arg0) {
			Boolean success = false;
			try {
				Boolean deleted = ftpClient.deleteFile(remoteName);
				Notify.d(this, remoteName + " deleted " + deleted);
			}
			catch (Throwable e) {
				Notify.e(this, "UploadStreamTask deleteFile" + e.toString());
			}
			
			try {
				ftpClient.setFileType(fileType);
				BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
				success = ftpClient.storeFile(remoteName, bufferedInputStream);
				bufferedInputStream.close();
				inputStream.close();
			}
			catch (Throwable e) {
				Notify.e(this, "UploadStreamTask storeFile" + e.toString());
			}
			
			if ( success )
				sendSuccess();
			else
				sendError();
			
			return null;
		}
		
	};
	
	private void sendSuccess() {
		android.os.Message message = new android.os.Message();
		message.arg1 = SUCCESS;
		handler.sendMessage(message);
	}
	
	private void sendError() {
		android.os.Message message = new android.os.Message();
		message.arg1 = ERROR;
		handler.sendMessage(message);
	}
}
