package control;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;

import over.TimerService;
import wrc.WRCDevice;
import android.os.AsyncTask;

import com.dension.messages.AccessGrantedMessage;
import com.dension.messages.Message;
import com.dension.messages.WRCDStartupMessage;

import develop.Notify;

public class Control {
	
	public static final short CONTROL_PORT = 1984;
	
	private TimerService service;
	private WRCDevice wrcDevice = null;
	private Socket socket;
	private WRCDStartupMessage wrcdStartupMessage;
	private Listener listener;
	
	private Boolean onTask = false;
	
	public Boolean connectd = false; 

	public Control(TimerService timerService, Listener listener) {
		this.service = timerService;
		this.listener = listener;
	}
	
	public Boolean connect() {
		Boolean success = false;
		
		try {
			wrcDevice = service.getSelectedWRCDevice();
			if ( ! wrcDevice.getIp().equals("") ) {
				InetAddress address = InetAddress.getByName(wrcDevice.getIp());
				socket = new Socket(address, CONTROL_PORT);
				success = true;
				onTask = true;
				new ControlTask().execute();
				Notify.d(this, "connected " + wrcDevice.getIp());
			}
		}
		catch (Throwable e) {
			Notify.e(this, "connect " + e.toString());
		}
		
		connectd = success;
		
		return success;
	}
	
	public void disconnect() {
		try {
			onTask = false;
			connectd = false;
			if ( socket != null ) {
				socket.close();
				socket = null;
				Notify.d(this, "disconnected");
			}
		}
		catch (Throwable e) {
			Notify.e(this, "disconnect " + e.toString());
		}
	}
	
	public void sendMsg(Message message) {
		try {
			OutputStream outputStream = socket.getOutputStream();
			outputStream.write(message.getRaw());
			// outputStream.close();
		}
		catch (Throwable e) {
			Notify.e(this, "sendMsg " + e.toString());
		}
	}
	
	public WRCDStartupMessage getWrcdStartupMessage() {
		return wrcdStartupMessage;
	}
	
	private class ControlTask extends AsyncTask<Void, Void, Void> {

		@Override
		protected Void doInBackground(Void... arg0) {
			try {
				Message msg;
				InputStream in = socket.getInputStream();
				
				while ( onTask ) {
					msg = Message.receive(in);
					if ( null != msg ) {
						if ( Message.MSG_CMD_WRCD_STARTUP == msg.getCmd() ) {
							wrcdStartupMessage = (WRCDStartupMessage) msg;
						} 
						else { 
							if ( Message.MSG_CMD_ACCESS_GRANTED == msg.getCmd() ) {
								AccessGrantedMessage msg_agr = (AccessGrantedMessage) msg;
								switch ( msg_agr.getNotif() ) {
									case Message.MSG_NOTIF_GRANTED:
										service._periodicChannelData().start();
										service._periodicChannelData().setHasDeviceControl(true);
										service.access = true;
										break;
									case Message.MSG_NOTIF_LOST:
										service._periodicChannelData().stop();
										service._periodicChannelData().setHasDeviceControl(false);
										service.access = false;
										break;
								}
							}
						}
						
						listener.OnMessage(msg);
					}
				}
			}
			catch (Throwable e) {
				Notify.e(this, "ControlTask " + e.toString());
				listener.OnDisconnect();
			}
			
			return null;
		}
	}
	
	public interface Listener {
		public abstract void OnMessage(Message msg);
		public abstract void OnDisconnect();
	}

}
