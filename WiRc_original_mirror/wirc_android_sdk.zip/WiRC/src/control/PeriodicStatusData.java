package control;

import java.net.DatagramPacket;
import java.net.DatagramSocket;

import android.os.AsyncTask;

import com.dension.messages.Message;
import com.dension.messages.PeriodicalStatusDataMessage;

import control.Control.Listener;

import develop.Notify;

public class PeriodicStatusData {
	
	private static final int NOTIFICATION_STATUS = 1;
	
	private DatagramSocket datagramSocket;
	private PeriodicalStatusDataMessage periodicalStatusDataMessage;
	private Listener listener;
	
	private Boolean onTask = false;

	public PeriodicStatusData(Listener listener) {
		this.listener = listener;
	}
	
	public void start() {
		try {
			onTask = true;
			datagramSocket = new DatagramSocket();
			new Task().execute();
			Notify.d(this, "start");
		}
		catch (Throwable e) {
			Notify.e(this, e.toString());
		}
	}
	
	public void stop() {
		onTask = false;
		datagramSocket.close();
		Notify.d(this, "stopped");
	}
	
	private class Task extends AsyncTask<Void, Void, Void> {

		@Override
		protected Void doInBackground(Void... arg0) {
			try {
				byte rawPacket[] = new byte[Message.MSG_MAX_RAW_LEN];
				DatagramPacket packet = new DatagramPacket(rawPacket, rawPacket.length);
				
				while ( onTask ) {
					datagramSocket.receive(packet);
					periodicalStatusDataMessage = new PeriodicalStatusDataMessage(packet.getData(), packet.getLength());
					if ( periodicalStatusDataMessage.isValid ) {
					}
					listener.OnMessage(periodicalStatusDataMessage);
				}
			}
			catch (Throwable e) {
				Notify.e(this, e.toString());
			}
			
			return null;
		}
	}
	
	public short getPSDPort() {
		return (short) (datagramSocket.getLocalPort());
	}
	
	public interface Listener {
		public abstract void OnMessage(PeriodicalStatusDataMessage msg);
	}

}
