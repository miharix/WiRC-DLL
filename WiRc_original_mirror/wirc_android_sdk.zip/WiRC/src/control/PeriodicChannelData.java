package control;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import over.TimerService;
import wrc.WRCDevice;
import android.os.AsyncTask;

import com.dension.messages.Message;
import com.dension.messages.PeriodicalChannelDataMessage;
import com.dension.messages.WRCDStartupMessage;

import develop.Notify;

public class PeriodicChannelData {

	public static final int UPDATE_INTERVAL = 50;

	private DatagramSocket datagramSocket;

	public WRCDevice wrcDevice = null;
	private Boolean onTask = false;
	private volatile short data[];

	public boolean hasDeviceControl;

	public PeriodicChannelData(WRCDevice wrcDevice, short defaultValue) {
		this.wrcDevice = wrcDevice;

		this.data = new short[Message.MSG_NUM_CH];
		for (int i = 0; i < data.length; ++i) {
			data[i] = defaultValue;
		}
	}

	public Boolean start() {
		Boolean success = false;

		try {
			onTask = true;
			datagramSocket = new DatagramSocket();
			new Task().execute();
			Notify.d(this, "started");
		} catch (Throwable e) {
			Notify.e(this, e.toString());
		}

		return success;
	}

	public void stop() {
		onTask = false;
		Notify.d(this, "stopped");
	}

	public void setChannel(int index, int value) {
		/*
		if ((index < 1) || (index > Message.MSG_NUM_CH)) {
			return;
		}
		*/
		data[index - 1] = (short) value;
	}

	private class Task extends AsyncTask<Void, Void, Void> {

		@Override
		protected Void doInBackground(Void... arg0) {
			if (TimerService.developMode) {
				try {
					while (onTask) {
						Notify.d(this, String.format("%d | %d | %d", data[8], data[9], data[10]));
						Thread.sleep(UPDATE_INTERVAL);
					}
				} catch (Throwable e) {
					Notify.e(this, e.toString());
				}

			} else {
				WRCDStartupMessage wrcdStartupMessage = TimerService.control.getWrcdStartupMessage();
				int PCDPort = wrcdStartupMessage.getPCDPort();

				try {
					PeriodicalChannelDataMessage pcd = new PeriodicalChannelDataMessage(data);
					DatagramPacket packet = new DatagramPacket(pcd.getRaw(), pcd.getRawLength());
					packet.setAddress(InetAddress.getByName(wrcDevice.getIp()));
					packet.setPort(PCDPort);

					while (onTask) {
						pcd.setValues(data);
						if (hasDeviceControl) {
							packet.setData(pcd.getRaw());
							datagramSocket.send(packet);
						} else {
						}
						Thread.sleep(UPDATE_INTERVAL);
					}

					datagramSocket.close();
				} catch (Throwable e) {
					Notify.e(this, e.toString());
				}
			}

			return null;
		}
	}

	public short getPSDPort() {
		return (short) (datagramSocket.getLocalPort());
	}

	public void setHasDeviceControl(boolean hasDeviceControl) {
		this.hasDeviceControl = hasDeviceControl;
	}

}
