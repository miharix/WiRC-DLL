package joy;

import develop.Notify;
import wirc.dension.com.R;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.LinearLayout;

public class Slider extends LinearLayout {
	
	private JoyArea joyArea;
	private Bitmap bitmap;
	private Bitmap bitmapX;
	private Bitmap bitmapY;
	private Paint paintBackground;
	private Paint paintBackgroundFilled;
	private int width = 0; 
	private int height = 0;
	private int widthTouch = 0; 
	private int heightTouch = 0;
	private float x = 0;
	private float y = 0;
	private int colorBackground;
	private int colorBackgroundFilled;
	// private int sizeDP = 30;
	//private int size = sizeDP;
	private int backgroundBorder = 2;
	private int backgroudSize = 10;
	private int backgroudWidth = 1;
	private int backgroudHeight = 1;
	private int backgroudX = 0;
	private int backgroudY = 0;
	private int startPos = 0;
	private int endPos = 0;
	private Boolean landscape = false;
	private int location[] = new int[2];
	
	public int max = 100;
	public int min = 0;
	public int pos = 50;

	public Slider(Context context) {
		super(context);
		
		init();
	}

	public Slider(Context context, AttributeSet attrs) {
		super(context, attrs);
		
		init();
		
		/*
		if ( TimerService.displayMetrics != null ) {
			float denisty = TimerService.displayMetrics.density;
			size = (int) (sizeDP * denisty + 0.5);
		}
		*/
		
		bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.sm);
		
		colorBackground = Color.WHITE;
		paintBackground = new Paint();
		paintBackground.setColor(colorBackground);
		
		colorBackgroundFilled = Color.rgb(0, 204, 255);
		paintBackgroundFilled = new Paint();
		paintBackgroundFilled.setColor(colorBackgroundFilled);
		
		if ( drawable!= null )
			setBackgroundDrawable(drawable);
	}
	
	public void onTouch(float touchX, float touchY) {
		x = touchX - location[0];
		y = touchY - location[1];
		
		if ( x > endPos )
			x = endPos;
		if ( x < startPos )
			x = startPos;
		
		if ( y > endPos )
			y = endPos;
		if ( y < startPos )
			y = startPos;
		
		setBackgroundDrawable(drawable);
		invalidate();
		
		float percent = 1;
		if ( landscape ) {
			percent = (float) (x - startPos) / (float) widthTouch;
		}
		else {
			percent = (float) (y - startPos) / (float) heightTouch;
			percent = 1 - percent; 
		}
		pos = min + (int) ((max - min) * percent);
		
		joyArea.setSliderPos(Slider.this);
	}
	
	private void init() {
		this.getViewTreeObserver().addOnGlobalLayoutListener(onGlobalLayoutListener);

		if ( getTag() != null ) {
			if ( getTag().toString().contains("X") )
				landscape = true;
			else
				landscape = false;
			/*
			if ( getTag().toString().contains("L") )
				control = JoyArea.L_CONTROL;
			if ( getTag().toString().contains("R") )
				control = JoyArea.R_CONTROL;
			*/
		}
	}
	
	private OnGlobalLayoutListener onGlobalLayoutListener = new OnGlobalLayoutListener() {
		@Override
		public void onGlobalLayout() {
			getLocationInWindow(location);
			getLocationOnScreen(location);
		}
	};

	
	public void setJoyArea(JoyArea joyArea) {
		this.joyArea = joyArea;
	}
	
	@Override
	public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		
		float scaleWidth = 0;
		float scaleHeight = 0;
		width = MeasureSpec.getSize(widthMeasureSpec);
		height = MeasureSpec.getSize(heightMeasureSpec);
		
		if ( landscape ) {
			backgroudHeight = backgroudSize;
			backgroudWidth = width;
			backgroudX = 0;
			backgroudY = height / 2 - backgroudHeight / 2;
		}
		else {
			backgroudWidth = backgroudSize;
			backgroudHeight = height;
			backgroudX = width / 2 - backgroudWidth / 2;
			backgroudY = 0;
		}
		
		setMeasuredDimension(width, height); 

		if ( (width > 0) && (height > 0) ) {
			Matrix matrix = new Matrix();
			if ( landscape ) {
				scaleHeight = ((float) height) / bitmap.getHeight();
				scaleWidth = scaleHeight;
				matrix.postScale(scaleWidth, scaleHeight);
				bitmapX = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, false);
				startPos = (int) (bitmapX.getWidth() / 2);
				endPos = width - startPos;
				widthTouch = width - startPos - startPos; 
			}
			else {
				scaleWidth = ((float) width) / bitmap.getWidth();
				scaleHeight = scaleWidth;
				matrix.postScale(scaleWidth, scaleHeight);
				bitmapY = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, false);
				startPos = (int) (bitmapY.getHeight() / 2);
				endPos = height - startPos;
				heightTouch = height - startPos - startPos;
			}
		}
		
		setPos(pos);
	}
	
	@Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
	}
	
	private Drawable drawable = new Drawable() {
		@Override
		public void draw(Canvas canvas) {
			if ( (bitmapX != null) && (bitmapY != null) ) {
				canvas.drawRect(backgroudX, backgroudY, backgroudX + backgroudWidth, backgroudY + backgroudHeight, paintBackgroundFilled);
				if ( landscape ) {
					canvas.drawRect(x, backgroudY + backgroundBorder, backgroudX + backgroudWidth, backgroudY + backgroudHeight - backgroundBorder, paintBackground);
					canvas.drawBitmap(bitmapX, x - (bitmapX.getWidth() / 2), (height / 2) - (bitmapX.getHeight() / 2), null);
				}
				else {
					canvas.drawRect(backgroudX + backgroundBorder, backgroudY + backgroundBorder, backgroudX + backgroudWidth - backgroundBorder, y, paintBackground);
					canvas.drawBitmap(bitmapY, (width / 2) - (bitmapY.getWidth() / 2), y - (bitmapY.getHeight() / 2), null);
				}
			}
		}

		@Override
		public int getOpacity() {
			return 0;
		}

		@Override
		public void setAlpha(int arg0) {
		}

		@Override
		public void setColorFilter(ColorFilter arg0) {
		}
	};
	
	public void setPos(int pos) {
		this.pos = pos;
		float percent = ((float) pos - (float) min) / ((float) max - (float) min);
		
		if ( landscape )
			x = (int) (widthTouch * percent) + startPos;
		else
			y = heightTouch - (int) (heightTouch * percent) + startPos;
		
		setBackgroundDrawable(drawable);
	}

}
