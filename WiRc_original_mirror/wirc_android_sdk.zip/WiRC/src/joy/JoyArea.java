package joy;

import java.util.Date;

import over.TimerService;
import wirc.dension.com.R;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import channel.ChannelSource;

import com.dension.wra.ChannelSettingsActivity;

import develop.Notify;

public class JoyArea extends FrameLayout {
	
	public static final int N_CONTROL = -1;
	public static final int L_CONTROL = 0; 
	public static final int R_CONTROL = 1;
	
	private Rect rect;
	private Bitmap bitmap;
	private int width = 0;
	private int height = 0;
	private float slopeX;
	private float slopeY;
	private float coordXlast = 0;
	private float coordYlast = 0;
	private int x = 0;
	private int y = 0;
	private long touchLast = 0;
	private long touchTime = 50;
	private Boolean useX = false;
	private Boolean useY = false;
	private Boolean holdX = false;
	private Boolean holdY = false;
	/*
	private Boolean ACTION_POINTER_1_DOWN = false;
	private Boolean ACTION_POINTER_2_DOWN = false;
	private int touchX = 0;
	private int touchY = 0;
	private int touchW = 0;
	private int touchH = 0;
	private int touchIndex = -1;
	*/
	
	private JoyArea secondJoyArea;
	
	public int control = N_CONTROL; 
	public int location[] = new int[2];
	public int locationDifference[] = new int[2];
	public int touchSizeXY = 50;
	public int touchSizeXYhalf = 25;
	public int touchAreaStart = 0;
	public int touchAreaEndX = 0;
	public int touchAreaEndY = 0;
	public float touchXtrim = 0;
	public float touchYtrim = 0;
	
	public ChannelSource xChannelSource;
	public ChannelSource yChannelSource;
	
	public int min = 0;
	public int max = 100;
	public int pos = 100;
	
	public Slider slider_Y;
	public Slider slider_X;
	public TextView textView_Y;
	public TextView textView_X;
	
	public JoyArea(Context context) {
		super(context);
		
		this.setOnFocusChangeListener(l);
	}
	
	public JoyArea(Context context, AttributeSet attrs) {
		super(context, attrs);
		
		this.setOnFocusChangeListener(l);
	}
	
	private OnFocusChangeListener l = new OnFocusChangeListener() {

		@Override
		public void onFocusChange(View v, boolean hasFocus) {
			Notify.d(this, "focus");
			
		}
		
	};
	
	public void initJoyArea(int control) {
		
		this.control = control;
		touchLast = new Date().getTime();
		
		bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.joy);
		touchSizeXY = bitmap.getHeight();
		touchSizeXYhalf = touchSizeXY / 2;
		
		// this.setOnTouchListener(onTouchListener);
	}
	
	public void setSliders() {
		slider_Y = (Slider) this.findViewById(R.slider.slider_Y);
		slider_X = (Slider) this.findViewById(R.slider.slider_X);
		slider_Y.setJoyArea(this);
		slider_X.setJoyArea(this);
		textView_Y = (TextView) this.findViewById(R.slider.textView_Y);
		textView_X = (TextView) this.findViewById(R.slider.textView_X);
		setSlider(xChannelSource, slider_X, textView_X);
		setSlider(yChannelSource, slider_Y, textView_Y);
		
	};
	
	public void initControls() {
		xChannelSource = new ChannelSource();
		yChannelSource = new ChannelSource();
		xChannelSource.setType(ChannelSource.NO_SOURCE);
		yChannelSource.setType(ChannelSource.NO_SOURCE);
		
		holdX = false;
		holdY = false;
		useX = true;
		useY = true;
		float touchX = getCenterX() + location[0];
		float touchY = getCenterY() + location[1];
		doTouch(touchX, touchY);
		useX = false;
		useY = false;
		
		/*
		x = (int) (getCenterX() + location[0]);
		y = (int) (getCenterY() + location[1]);
		touchXtrim = 0;
		touchYtrim = 0;
		*/
		
		switch ( this.control ) {
		case L_CONTROL:
			if ( TimerService.channelCalculator.isUsingLeftJoyX() ) {
				xChannelSource.setType(ChannelSource.JOY_LEFT_X);
			}
			if ( TimerService.channelCalculator.isUsingLeftJoyY() ) {
				yChannelSource.setType(ChannelSource.JOY_LEFT_Y);
			}
			break;
		case R_CONTROL:
			if ( TimerService.channelCalculator.isUsingRightJoyX() ) {
				xChannelSource.setType(ChannelSource.JOY_RIGHT_X);
			}
			if ( TimerService.channelCalculator.isUsingRightJoyY() ) {
				yChannelSource.setType(ChannelSource.JOY_RIGHT_Y);
			}
			break;
		}
		
		xChannelSource.setChannel();
		yChannelSource.setChannel();
		
		if ( xChannelSource.getType() != ChannelSource.NO_SOURCE ) {
			useX = true;
			holdX = 
				((control == L_CONTROL) && TimerService.hold.lX) ||
				((control == R_CONTROL) && TimerService.hold.rX);
		}
		
		if ( yChannelSource.getType() != ChannelSource.NO_SOURCE ) {
			useY = true;
			holdY = 
				((control == L_CONTROL) && TimerService.hold.lY) ||
				((control == R_CONTROL) && TimerService.hold.rY);
		}
		
		setSliders();
		
		if ( useX || useY) {
			this.setVisibility(View.VISIBLE);
		}
		else {
			this.setVisibility(View.GONE);
		}
	}
	
	private void setSlider(ChannelSource channelSource, Slider slider, TextView textView) {
		if ( channelSource != null ) {
			setSliderVisibility(slider, textView, View.INVISIBLE);
			if ( (channelSource.channel != null) && (channelSource.getType() != ChannelSource.NO_SOURCE) ) {
				setSliderVisibility(slider, textView, View.VISIBLE);
				if ( TimerService.useSensitivity ) {
					min = 0; // ChannelSettingsActivity.FACTOR_SLIDER_MIN;
					max = ChannelSettingsActivity.FACTOR_SLIDER_MAX;
					pos = (int) channelSource.channel.getSensitivityFactor();
				}
				else {
					min = ChannelSettingsActivity.CHANNEL_MIN_US;
					max = ChannelSettingsActivity.CHANNEL_MAX_US;
					pos = channelSource.channel.getTrimSettings().getTrimValue();
				}
				slider.min = min;
				slider.max = max;
				slider.setPos(pos);
				setSliderPos(slider);
			}
		}
	}
	
	private void setSliderVisibility(Slider slider, TextView textView, int visibility) {
		slider.setVisibility(visibility);
		textView.setVisibility(visibility);
		slider.setFocusable(visibility == View.VISIBLE);
		textView.setFocusable(visibility == View.VISIBLE);
	}
	
	public void setSliderPos(Slider slider) {
		String title = "";
		
		if ( TimerService.useSensitivity ) {
			setSensitivityFactor(slider);
			title = Integer.toString(slider.pos) + "%";
		}
		else {
			setTrimValue(slider);
			title = Integer.toString(slider.pos) + "uS";
		}
		
		if ( slider == slider_X ) {
			textView_X.setText(title);
		}
		if ( slider == slider_Y ) {
			textView_Y.setText(title);
		}
	}
	
	public void setSensitivityFactor(Slider slider) {
		if ( slider == slider_X ) {
			xChannelSource.channel.setSensitivityFactor(slider.pos);
		}
		if ( slider == slider_Y ) {
			yChannelSource.channel.setSensitivityFactor(slider.pos);
		}
	}
	
	public void setTrimValue(Slider slider) {
		try {
			if ( TimerService.status.connected ) {
				if ( slider == slider_X ) {
					xChannelSource.channel.getTrimSettings().setTrimValue(slider.pos);
					TimerService.periodicChannelData.setChannel(xChannelSource.channel.getIndex(), slider.pos);
				}
				if ( slider == slider_Y ) {
					yChannelSource.channel.getTrimSettings().setTrimValue(slider.pos);
					TimerService.periodicChannelData.setChannel(yChannelSource.channel.getIndex(), slider.pos);
				}
			}
		}
		catch (Throwable e) {
			Notify.e(this, "setTrimValue() " + e.toString());
		}
	}
	
	public void setTrimValue(ChannelSource channelSource) {
		try {
			TimerService.periodicChannelData.setChannel(channelSource.channel.getIndex(), channelSource.channel.getTrimSettings().getTrimValue());
		}
		catch (Throwable e) {
			Notify.e(this, "setTrimValue() " + e.toString());
		}
	}
	
	public void prepareControls() {
		if ( TimerService.onDrive ) {
			if ( useX ) {
				setTrimValue(xChannelSource);
			}
			if ( useY ) {
				setTrimValue(yChannelSource);
			}
		}
	}
	
	public void startControls() {
		/*
		ACTION_POINTER_1_DOWN = false;
		ACTION_POINTER_2_DOWN = false;
		*/
		coordXlast = 0;
		coordYlast = 0;
		
		switch (this.control ) {
		case L_CONTROL:
			if ( TimerService.channelCalculator.isUsingLeftJoyX() )
				xChannelSource.addObserver(TimerService.channelCalculator);
			if ( TimerService.channelCalculator.isUsingLeftJoyY() )
				yChannelSource.addObserver(TimerService.channelCalculator);
			break;
		case R_CONTROL:
			if ( TimerService.channelCalculator.isUsingRightJoyX() )
				xChannelSource.addObserver(TimerService.channelCalculator);
			if ( TimerService.channelCalculator.isUsingRightJoyY() )
				yChannelSource.addObserver(TimerService.channelCalculator);
			break;
		}
	}
	
	/*
	@Override
	protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
	}
	*/
	
	@Override
	protected void onDraw(Canvas canvas) {
		if ( bitmap != null ) {
			canvas.drawBitmap(bitmap, rect.left, rect.top, null);
		}
	}
	
	@Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		
		width = getMeasuredWidth();
		height = getMeasuredHeight();
		/*
		if ( width > height ) {
			width = height;
		}
		*/
		setMeasuredDimension(width, height);
		touchAreaStart = touchSizeXYhalf;
		touchAreaEndX = width - touchSizeXYhalf;
		touchAreaEndY = height - touchSizeXYhalf;
		
		slopeX = 200f / (width);
		slopeY = 200f / (height);
		
		setFocusable(true);
		rect = new Rect();
		touchXtrim = 0;
		touchYtrim = 0;
		x = (int) getCenterX() - touchSizeXYhalf;
		y = (int) getCenterY() - touchSizeXYhalf; 
		rect.set(x, y, touchSizeXY, touchSizeXY);

		getLocationInWindow(location);
		getLocationOnScreen(location);

		if ( secondJoyArea != null ) {
			locationDifference[0] = location[0] - secondJoyArea.location[0];
			locationDifference[1] = location[1] - secondJoyArea.location[1];
		}
    }

	
	private float getCenterX() {
		return width / 2;
	}
	
	private float getCenterY() {
		return height / 2;
	}
	
	public void setSecondJoyArea(JoyArea secondJoyArea) {
		this.secondJoyArea = secondJoyArea;
	}
	
	public void onTouch(int action, float touchX, float touchY) {
		try {
			if ( action == MotionEvent.ACTION_UP ) {
				moveToCenterPos(touchX, touchY);
			}
			else {
				if ( action == MotionEvent.ACTION_DOWN ) {
					setTouchTrim(touchX, touchY);
				}
				doTouch(touchX, touchY);
			}
		}
		catch (Throwable e) {
			Notify.e(this, "onTouch()", e.toString());
		}
	}
	
	public void doTouch(float touchX, float touchY) {
		try {
			float coordX = 0;
			float coordY = 0;
			long touchNow = new Date().getTime();
			if ( (touchLast + touchTime) < touchNow ) {
				
				touchX = touchX - location[0];
				touchY = touchY - location[1];
				
				if ( useX ) {
					if ( (touchX  > touchAreaStart) && (touchX  < touchAreaEndX) ) { 
						coordX = touchToPosX(touchX + touchXtrim) / 100f;
						/*
						if ( coordXlast < 0 ) {
							if ( coordX > 0 ) {
								xChannelSource.setData(0);
							}
						}
						*/
						xChannelSource.setData(coordX);
						x = (int) touchX - touchSizeXYhalf;
						coordXlast = coordX;
						// Notify.d(this, "x " + coordX);
					}
				}
				if ( useY ) {
					if ( (touchY > touchAreaStart) && (touchY  < touchAreaEndY) ) {
						coordY = touchToPosY(touchY + touchYtrim) / 100f;
						/*
						if ( coordYlast < 0 ) {
							if ( coordY > 0 ) {
								yChannelSource.setData(0);
							}
						}
						*/
						if ( coordY != 0 )
							yChannelSource.setData(coordY);
						y = (int) touchY - touchSizeXYhalf;
						coordYlast = coordY;
						// Notify.d(this, "y " + coordY);
					}
				}
				rect.set(x, y, touchSizeXY, touchSizeXY);
				invalidate();
				
				touchLast = touchNow;
			}
		}
		catch (Throwable e) {
			Notify.e(this, "doTouch()", e.toString());
		}
	};
	
	private float touchToPosX(float pos) {
		float result = - (slopeX * pos - 100f);
		
		// Notify.d(this, String.format("%f | %f", pos, result));
		
		return result;
	}
	
	private float touchToPosY(float pos) {
		float result = - (slopeY * pos - 100f);
		
		// Notify.d(this, String.format("%f | %f", pos, result));
		
		return result;
	}
	
	public void setTouchTrim(float touchX, float touchY) {
		if ( ! holdX )
			touchXtrim = getCenterX() - (touchX - location[0]);
		if ( ! holdY )
			touchYtrim = getCenterY() - (touchY - location[1]);
	}
	
	public void moveToCenterPos(float touchX, float touchY) {
		// setTouchTrim(getCenterX(), getCenterY());
		if ( ! holdX )
			touchXtrim = 0;
		if ( ! holdY )
			touchYtrim = 0;
		touchLast = 0;
		if ( ! holdX )
			touchX = getCenterX() + location[0];
		if ( ! holdY )
			touchY = getCenterY() + location[1];
		doTouch(touchX, touchY);
		sendCenterMessage();
	}
	
	public void sendCenterMessage() {
		if ( useX & ! holdX )
			xChannelSource.setData(0);
		if ( useY & ! holdY )
			yChannelSource.setData(0);
	}
	
}
