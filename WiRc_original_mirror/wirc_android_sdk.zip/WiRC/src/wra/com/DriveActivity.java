package wra.com;

import gui.Gui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import joy.JoyArea;
import joy.Slider;
import over.TimerService;
import sensors.OrientationListener;
import wirc.dension.com.R;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import buttonad.ButtonData;
import camera.MjpegDisplay;
import channel.ChannelInfo;

import com.dension.sqliteaccess.WircDbAdapter;
import com.dension.wra.SettingsActivity;

import develop.Notify;

public class DriveActivity extends Activity {
	
	private Context context;
	private PowerManager.WakeLock wakeLock;
	private Animation animation;
	private SharedPreferences sharedPreferences;
	private HashMap<Integer, HashMap<Integer, Integer>> maneuverSettings;
	private BatteryAverageTask batteryAverageTask;
	
	// private LinearLayout layout_joys;
	private FrameLayout drive_layout;;
	private LinearLayout layout_L;
	private LinearLayout layout_R;
	private LinearLayout layout_bottom;
	/*
	private LinearLayout layout_joyL;
	private LinearLayout layout_joyR;
	*/
	private ImageButton button_start;
	private ImageButton button_camera;
	private ImageButton button_record;
	private ImageButton button_mod;
	private ImageButton button_trim;
	private TextView textView_time;
	private TextView textView_mod;
	private ImageButton button_ba;
	private ImageButton button_bb;
	private ImageButton button_bc;
	private ImageButton button_bd;
	private ImageButton button_man1;
	private ImageButton button_man2;
	private TextView textView_battery;
	private ImageView imageView_battery;
	private ImageView imageView_photo;
	
	private Boolean onTimer = false;
	private boolean button_record_longClicked = false;
	private Boolean onBatteryAverageTask = false;
	private Boolean home_touch = true;
	private long startTime = 0;
	private int camVolt = 0;
	private int devVolt = 0;
	private View touch1 = null;
	private View touch2 = null;
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        */
        setContentView(R.layout.drive);
        
        context = getApplicationContext();
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
		wakeLock = powerManager.newWakeLock(PowerManager.FULL_WAKE_LOCK, "DoNotDimScreen");
		sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        
        Intent serviceIntent = new Intent(context, TimerService.class);
        startService(serviceIntent);
        TimerService.driveActivity = this;
        
        layout_bottom = (LinearLayout) findViewById(R.drive.layout_bottom);
        layout_L = (LinearLayout) findViewById(R.drive.layout_L);
        layout_R = (LinearLayout) findViewById(R.drive.layout_R);
        TimerService.mjpegDisplay = (MjpegDisplay) this.findViewById(R.drive.mjpegDisplay);
        TimerService.joyArea_L = (JoyArea) findViewById(R.drive.joyArea_L);
        TimerService.joyArea_L.initJoyArea(JoyArea.L_CONTROL);
        TimerService.joyArea_R = (JoyArea) findViewById(R.drive.joyArea_R);
        TimerService.joyArea_R.initJoyArea(JoyArea.R_CONTROL);
        TimerService.joyArea_L.setSecondJoyArea(TimerService.joyArea_R);
        TimerService.joyArea_R.setSecondJoyArea(TimerService.joyArea_L);
        
        button_start = (ImageButton) findViewById(R.drive.button_start);
        button_start.setOnClickListener(button_start_OnClickListener);
        button_camera = (ImageButton) findViewById(R.drive.button_camera);
        button_camera.setOnClickListener(button_camera_OnClickListener);
        // setButtonOff(button_camera, R.drawable.camera);
        button_record = (ImageButton) findViewById(R.drive.button_record);
        button_record.setOnClickListener(button_record_OnClickListener);
        button_record.setOnLongClickListener(button_record_OnLongClickListener);
        
        ((ImageButton) findViewById(R.drive.button_settings)).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				home_touch = false;
				Intent intent = new Intent(context, SettingsActivity.class);
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				context.startActivity(intent);
			}
        });
        
        button_trim = (ImageButton) findViewById(R.drive.button_trim);
        button_trim.setOnClickListener(button_trim_OnClickListener);
        button_mod =  (ImageButton) findViewById(R.drive.button_mod);
        button_mod.setOnClickListener(button_mod_OnClickListener);
        textView_mod = (TextView) findViewById(R.drive.textView_mod);
        textView_mod.setText(Integer.toString(TimerService.modeNum));
        
        button_ba = (ImageButton) findViewById(R.drive.button_ba);
        button_bb = (ImageButton) findViewById(R.drive.button_bb);
        button_bc = (ImageButton) findViewById(R.drive.button_bc);
        button_bd = (ImageButton) findViewById(R.drive.button_bd);
        button_man1 = (ImageButton) findViewById(R.drive.button_man1);
        button_man2 = (ImageButton) findViewById(R.drive.button_man2);
        
        button_ba.setOnTouchListener(buttonAD_onTouchListener);
        button_bb.setOnTouchListener(buttonAD_onTouchListener);
        button_bc.setOnTouchListener(buttonAD_onTouchListener);
        button_bd.setOnTouchListener(buttonAD_onTouchListener);
        button_man1.setOnTouchListener(buttonMan_onTouchListener);
        button_man2.setOnTouchListener(buttonMan_onTouchListener);
        
        textView_time = (TextView) findViewById(R.drive.textView_time);
        textView_battery = (TextView) findViewById(R.drive.textView_battery);
        imageView_battery = (ImageView) findViewById(R.drive.imageView_battery);
        imageView_photo = (ImageView) findViewById(R.drive.imageView_photo);
        drive_layout = (FrameLayout) findViewById(R.drive.drive_layout);
        
        batteryAverageTask = new BatteryAverageTask();
        batteryAverageTask.execute();
	}
	
	@Override
    public void onDestroy() {
		disconnect();
		onBatteryAverageTask = false;
		
		super.onDestroy();
	}
	
	@Override
    public void onResume() {
		super.onResume();
		camVolt = TimerService.sharedPreferences.getInt(getString(R.string.prefCamVolt), 7000);
		devVolt = TimerService.sharedPreferences.getInt(getString(R.string.prefDevVolt), 7000);
		imageView_battery.setVisibility(View.GONE);
		reInitControls();
		connect();
		wakeLock.acquire();
		home_touch = true;
	}
	
	@Override
    public void onPause() {
		recordStop();
		drive_stop();
		sendBroadcastIntent(TimerService.ACTION_CAMERA_STOP);
		if ( home_touch )
			disconnect();
		super.onPause();
		wakeLock.release();
	}
	
	private void sendBroadcastIntent(String action) {
		Intent intent = new Intent();
		intent.setAction(action);
		sendBroadcast(intent);
	}
	
	private void connect() {
		try {
			Gui.setButtonEnable(button_start, false);
			Gui.setButtonEnable(button_record, false);
			// sendBroadcastIntent(TimerService.ACTION_CONNECT);
			if ( ! TimerService.status.connected ) {
				sendBroadcastIntent(TimerService.ACTION_CONNECT);
			}
			else {
				sendBroadcastIntent(TimerService.ACTION_CAMERA_START);
				Gui.setButtonEnable(button_start, TimerService.access);
				Gui.setButtonEnable(button_record, true);
			}
		}
		catch (Throwable e) {
			Notify.e(this, "connect() " + e.toString());
		}
	}
	
	private void disconnect() {
		try {
			sendBroadcastIntent(TimerService.ACTION_DISCONNECT);
		}
		catch (Throwable e) {
			Notify.e(this, "disconnect() " + e.toString());
		}
	}
	
	public Handler connected_handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			// layout_joys.setVisibility(View.VISIBLE);
			if ( msg.what == TimerService.MSG_CONNECTED ) {
				Notify.d(DriveActivity.this, "MSG_CONNECTED");
				if ( (TimerService.cameraStream != null) || TimerService.developMode ) {
					Gui.setButtonOn(button_camera, R.drawable.camera_on);
					Gui.setButtonEnable(button_record, true);
				}
			}
			if ( msg.what == TimerService.MSG_ACCESS_GRANTED ) {
				Notify.d(DriveActivity.this, "MSG_ACCESS_GRANTED " + TimerService.access);
				Toast toast = Toast.makeText(context, getString(R.string.sAccessGrant), Toast.LENGTH_SHORT);
				toast.show();
				Gui.setButtonEnable(button_start, true);
			}
			if ( msg.what == TimerService.MSG_ACCESS_NOT_GRANTED ) {
				Notify.d(DriveActivity.this, "MSG_ACCESS_NOT_GRANTED " + TimerService.access);
				Toast toast = Toast.makeText(context, getString(R.string.sAccessNotGrant), Toast.LENGTH_SHORT);
				toast.show();
			}
			if ( msg.what == TimerService.MSG_CONNECTION_ERROR ) {
				Notify.d(DriveActivity.this, "MSG_CONNECTION_ERROR");
				Toast toast = Toast.makeText(context, getString(R.string.sConnectionError), Toast.LENGTH_SHORT);
				toast.show();
			}
			if ( msg.what == TimerService.MSG_CHANNEL_INITIALIZED ) {
				Notify.d(DriveActivity.this, "MSG_CHANNEL_INITIALIZED");
				initControls();
			}
			if ( msg.what == TimerService.MSG_DISCONNECTED ) {
				Notify.d(DriveActivity.this, "MSG_DISCONNECTED");
				Toast toast = Toast.makeText(context, getString(R.string.sDisconnected), Toast.LENGTH_SHORT);
				toast.show();
				finish();
			}
			if ( msg.what == TimerService.MSG_BATTERY ) {
				textView_battery.setText(String.format("%.1fV", msg.arg1 / 1e3));
				batteryAverageTask.add(msg.arg1);
				
				if ( TimerService.access ) {
					if ( batteryAverageTask.average < devVolt ) {
						if ( imageView_battery.getVisibility() == View.GONE ) {
							Toast.makeText(context, getString(R.string.sDevVoltWarning) + " (" + String.format("%.1fV", devVolt / 1e3) + ")", Toast.LENGTH_SHORT).show();
							imageView_battery.setVisibility(View.VISIBLE);
						}
					}
					else {
						if ( imageView_battery.getVisibility() == View.VISIBLE ) {
							imageView_battery.setVisibility(View.GONE);
						}
					}
					if ( batteryAverageTask.average < camVolt ) {
						if ( TimerService.cameraThread != null ) {
							sendBroadcastIntent(TimerService.ACTION_CAMERA_STOP);
							Toast toast = Toast.makeText(context, getString(R.string.sCamVoltWarning), Toast.LENGTH_SHORT);
							toast.show();
						}
					}
				}
				
			}
		}
	};
	
	private class BatteryAverageTask extends AsyncTask<Void, Void, Void> {
		public ArrayList<Integer> values;
		public int sum = 0;
		public int average = 0;
		public int max = 10;
		
		public void add(int voltage) {
			if ( values.size() == max ) {
				values.remove(0);
			}
			else {
				average = voltage;
			}
			values.add(voltage);
			
			// Notify.d(this, "" + voltage + " " + values.size());
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			onBatteryAverageTask = true;
			
			values = new ArrayList<Integer>();
			values.add(0);
			
			while ( onBatteryAverageTask ) {
				try {
					Thread.sleep(5000);
					
					sum = 0;
					for (int i=0; i < values.size(); i++) {
						sum = sum + values.get(i);
					}
					average = sum / values.size();
					
					// Notify.d(this, " " + average + " " + values.size());
				} 
				catch (Throwable e) {
					Notify.e(this, e.toString());
				}
				
			}
			
			return null;
		}
	};
	
	public void prepareControls() {
		TimerService.joyArea_L.prepareControls();
		TimerService.joyArea_R.prepareControls();
	}
	
	private void initControls() {
		TimerService.hold.getHoldSettings();
		TimerService.joyArea_L.initControls();
		TimerService.joyArea_R.initControls();
		((OrientationListener) TimerService.orientationListener).initControls();
		TimerService.buttons.init();
		initManeuverSettings();
		setButtonAD(TimerService.buttons.hashMap_button_datas.get("ba"), button_ba);
		setButtonAD(TimerService.buttons.hashMap_button_datas.get("bb"), button_bb);
		setButtonAD(TimerService.buttons.hashMap_button_datas.get("bc"), button_bc);
		setButtonAD(TimerService.buttons.hashMap_button_datas.get("bd"), button_bd);
		setButtonMan(button_man1, 1);
		setButtonMan(button_man2, 2);
		TimerService.buttons.reset();
		
		if ( TimerService.channelCalculator.isUsingLeftJoyX() || TimerService.channelCalculator.isUsingLeftJoyY() ) {
			layout_L.setVisibility(View.VISIBLE);
        }
        else {
        	layout_L.setVisibility(View.INVISIBLE);
        }
        if ( TimerService.channelCalculator.isUsingRightJoyX() || TimerService.channelCalculator.isUsingRightJoyY() ) {
        	layout_R.setVisibility(View.VISIBLE);
        }
        else {
        	layout_R.setVisibility(View.INVISIBLE);
        }
        touch1 = null;
        touch2 = null;
	}
	
	private void initManeuverSettings() {
		maneuverSettings = new HashMap<Integer, HashMap<Integer, Integer>>();
        for (int i = 1; i <= 2; i++) {
			maneuverSettings.put(i, new HashMap<Integer, Integer>());
			Cursor settings = TimerService.dbHelper.getManeuversTable().fetchManeuvers(i, TimerService.getActiveProfileId());
			for (int j = 1; j <= 8; j++) {
				if ( settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ManeuversTable.KEY_IS_OVERRIDING)) == 1 ) {
					maneuverSettings.get(i).put(j, settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ManeuversTable.KEY_VALUE)));
				}
				settings.moveToNext();
			}
		}
	}
	
	private void reInitControls() {
		TimerService.channelCalculator.init();
		TimerService.controlSettings.init(TimerService.modeNum);
		initControls();
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		int action = event.getAction();
		
		if ( (event.getAction() == MotionEvent.ACTION_DOWN) || (event.getAction() == MotionEvent.ACTION_POINTER_1_DOWN)) {
			action = MotionEvent.ACTION_DOWN;
			if ( touch1 != null ) {
				touch2 = touch1;
			}
			touch1 = Gui.findTouch(drive_layout, (int) event.getX(), (int) event.getY());
		}
		if ( event.getAction() == MotionEvent.ACTION_POINTER_2_DOWN ) {
			action = MotionEvent.ACTION_DOWN;
			touch2 = Gui.findTouch(drive_layout, (int) event.getX(1), (int) event.getY(1));
			// Notify.e(this, "2 DOWN");
		}
		if ( (event.getAction() == MotionEvent.ACTION_UP) || (event.getAction() == MotionEvent.ACTION_POINTER_1_UP)) {
			action = -1;
			doTouch(touch1, event.getX(), event.getY(), MotionEvent.ACTION_UP);
			touch1 = null;
			if ( touch2 != null ) {
				touch1 = touch2;
				touch2 = null;
			}
			
			TimerService.buttons.press(button_ba.getTag().toString(), 0, true);
		}
		if ( event.getAction() == MotionEvent.ACTION_POINTER_2_UP ) {
			action = -1;
			doTouch(touch2, event.getX(1), event.getY(1), MotionEvent.ACTION_UP);
			touch2 = null;
		}
		
		if ( action > -1 ) {
			if ( (touch1 != null) && (event.getAction() != MotionEvent.ACTION_POINTER_2_DOWN) ) {
				// Notify.d(this, "1");
				doTouch(touch1, event.getX(), event.getY(), action);
			}
			if ( touch2 != null ) {
				// Notify.d(this, "2");
				doTouch(touch2, event.getX(1), event.getY(1), action);
			}
			
			// Notify.d(this, event.getY() + " " + event.getY(1));
		}
		
		return true;
	};
	
	private void doTouch(View view, float x, float y, int action) {
		if ( view.getClass().getName().equals(JoyArea.class.getName()) ) {
			JoyArea joyArea = (JoyArea) view;
			joyArea.onTouch(action, x, y);
		}
		else {
			if ( view.getClass().getName().equals(ImageButton.class.getName()) ) {
				if ( view.getTag().equals("man") ) {
					buttonMan_touch(view, Gui.getMotionEventAction(action));
				}
				else {
					buttonAD_touch(view, Gui.getMotionEventAction(action));
				}
			}
			else {
				if ( view.getClass().getName().equals(Slider.class.getName()) ) {
					Slider slider = (Slider) view;
					slider.onTouch(x, y);
				}
			}
		}
	}
	
	private OnClickListener button_start_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View view) {
			if ( TimerService.access ) {
				if ( TimerService.onDrive ) {
					drive_stop();
				}
				else {
					drive_start();
				}
			}
		}
	};
	
	private OnClickListener button_mod_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View view) {
			if ( TimerService.modeNum < TimerService.modeCount )
				TimerService.modeNum++;
			else
				TimerService.modeNum = ChannelInfo.DEFAULT_MODE;
			textView_mod.setText(Integer.toString(TimerService.modeNum));
			
			drive_stop();
			reInitControls();
		}
	};
	
	private OnClickListener button_trim_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View view) {
			if ( TimerService.useSensitivity ) {
				TimerService.useSensitivity = false;
				button_trim.setImageResource(R.drawable.trim);
			}
			else {
				TimerService.useSensitivity = true;
				button_trim.setImageResource(R.drawable.trimoff);
			}
			reInitControls();
		}
	};
	
	private OnClickListener button_camera_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View view) {
			if ( Gui.setButtonOnOff(button_camera, R.drawable.camera_on, R.drawable.camera_off) )
				sendBroadcastIntent(TimerService.ACTION_CAMERA_START);
			else
				sendBroadcastIntent(TimerService.ACTION_CAMERA_STOP);
		}
	};
	
	private OnClickListener button_record_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View view) {
			try {
				if ( button_record_longClicked ) {
					button_record_longClicked = false;
				}
				else {
					if ( Gui.setButtonOnOff(button_record, R.drawable.record, R.drawable.record) ) {
						Gui.setButtonOff(button_record, R.drawable.record);
						recordStart(true);
						MediaPlayer player = MediaPlayer.create(DriveActivity.this, Uri.parse("file:///system/media/audio/ui/camera_click.ogg"));
						player.start();
					}
					else {
						recordStop();
					}
				}
			}
			catch (Throwable e) {
				Notify.e(this, "button_record_OnClickListener() " + e.toString());
			}
		}
	};
	
	private OnLongClickListener button_record_OnLongClickListener = new OnLongClickListener() {

		@Override
		public boolean onLongClick(View v) {
			try {
				button_record_longClicked = true;
				if ( Gui.setButtonOnOff(button_record, R.drawable.record, R.drawable.record) ) {
					recordStart(false);
					MediaPlayer player = MediaPlayer.create(DriveActivity.this, Uri.parse("file:///system/media/audio/ui/VideoRecord.ogg"));
					player.start();
				}
			}
			catch (Throwable e) {
				Notify.e(this, "button_record_OnLongClickListener() " + e.toString());
			}
			
			return false;
		}
		
	};
	
	private void recordStart(boolean capture) {
		if ( TimerService.startRecord(capture) ||  TimerService.developMode ) {
			if ( ! capture ) {
				onTimer = true;
				startTime = SystemClock.elapsedRealtime();
				new TimerTask().execute();
				animation = new AlphaAnimation(1, 0);
				animation.setDuration(500);
			    animation.setInterpolator(new LinearInterpolator());
			    animation.setRepeatCount(Animation.INFINITE);
			    animation.setRepeatMode(Animation.REVERSE); 
			    button_record.startAnimation(animation);
			    textView_time.setVisibility(View.VISIBLE);
			}
			else {
				animation = new AlphaAnimation(1, 0);
				animation.setDuration(1000);
			    animation.setRepeatCount(0);
			    imageView_photo.startAnimation(animation);
			    animation.setAnimationListener(new AnimationListener() {
					@Override
					public void onAnimationEnd(Animation animation) {
						imageView_photo.setVisibility(View.GONE);
					}

					@Override
					public void onAnimationRepeat(Animation animation) {
					}

					@Override
					public void onAnimationStart(Animation animation) {
					}
				});
			    imageView_photo.setVisibility(View.VISIBLE);
			}
		}
	}
	
	private void recordStop() {
		onTimer = false;
		button_record.clearAnimation();
		textView_time.setText("00:00");
		textView_time.setVisibility(View.INVISIBLE);
		TimerService.stopRecord();
	}
	
	private View.OnTouchListener buttonAD_onTouchListener = new View.OnTouchListener() {
		@Override
		public boolean onTouch(View view, MotionEvent event) {
			try {
				int action = Gui.getMotionEventAction(event.getAction());
				buttonAD_touch(view, action);
			}
			catch (Throwable e) {
				Notify.e(this, "onTouch() " + e.toString());
			}
			
			return false;
		}
	};
	
	private void buttonAD_touch(View view, int action) {
		try {
			if ( TimerService.onDrive ) {
				ImageButton button = (ImageButton) view;
				TimerService.buttons.press(button.getTag().toString(), action, false);
			}
		}
		catch (Throwable e) {
			Notify.e(this, "buttonAD_touch() " + e.toString());
		}
	}
	
	private void setButtonAD(ButtonData buttonData, ImageButton button) {
		try {
			if ( buttonData != null ) {
				buttonData.button = button;
				buttonData.bitmap = ((BitmapDrawable) button.getDrawable()).getBitmap();
				buttonData.bitmapOn = BitmapFactory.decodeResource(getResources(), R.drawable.b_red);
				Gui.setButtonEnable(button, buttonData.used);
			}
		}
		catch (Throwable e) {
			Notify.e(this, "setButtonAD() " + e.toString());
		}
	}
	
	private View.OnTouchListener buttonMan_onTouchListener = new View.OnTouchListener() {
		@Override
		public boolean onTouch(View view, MotionEvent event) {
			int action = Gui.getMotionEventAction(event.getAction());
			buttonMan_touch(view, action);
			
			return false;
		}
	};
	
	private void buttonMan_touch(View view, int action) {
		try {
			if ( TimerService.onDrive ) {
				int manIndex = 0;
				if ( view == this.button_man1 )
					manIndex = 1;
				if ( view == this.button_man2 )
					manIndex = 2;
				
				if ( manIndex > 0 ) {
					HashMap<Integer, Integer> manSettings = maneuverSettings.get(manIndex);
					Set<Integer> keys = manSettings.keySet();
					Iterator<Integer> keyIter = keys.iterator();
					while ( keyIter.hasNext() ) {
						int key = keyIter.next();
						if ( action == MotionEvent.ACTION_DOWN ) {
							TimerService.periodicChannelData.setChannel(key, manSettings.get(key));
							Notify.d(this, view.toString() + " " + manIndex + " " + key + " " + manSettings.get(key));
						}
						if ( action == MotionEvent.ACTION_UP ) {
							TimerService.periodicChannelData.setChannel(key, TimerService.channelCalculator.getChannelByIndex(key).getTrimSettings().getTrimValue());
						}
					}
				}
			}
		}
		catch (Throwable e) {
			Notify.e(this, "buttonMan_touch() " + e.toString());
		}
	}
	
	private void setButtonMan(ImageButton button, int manIndex) {
		try {
			Boolean enabled = false;
			HashMap<Integer, Integer> manSettings = maneuverSettings.get(manIndex);
			Set<Integer> keys = manSettings.keySet();
			Iterator<Integer> keyIter = keys.iterator();
			enabled = keyIter.hasNext();
			Gui.setButtonEnable(button, enabled);
		}
		catch (Throwable e) {
			Notify.e(this, "setButtonMan() " + e.toString());
		}
	}
	
	/*
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	    super.onActivityResult(requestCode, resultCode, data);
	    
	    if ( PopUpList.position > -1 ) {
	    	TimerService.controlSettings.channelConfigs.get(TimerService.controlSettings.selectedChannel).setValue(PopUpList.position);
	    	TimerService.controlSettings.saveSettings();
	    }
	    reInitControls();
	}
	*/
    
	public void drive_start() {
		TimerService.onDrive = true;
		
		prepareControls();
		TimerService.joyArea_L.startControls();
		TimerService.joyArea_R.startControls();
		((OrientationListener) TimerService.orientationListener).startControls();
		
		Gui.setButtonOff(button_start, R.drawable.stop);
		
		if ( TimerService.developMode ) {
			TimerService.periodicChannelData.start();
		}
	}
	
	public void drive_stop() {
		if ( TimerService.developMode ) {
			TimerService.periodicChannelData.stop();
		}
		
		if ( TimerService.onDrive ) {
			TimerService.onDrive = false;
				
			if ( TimerService.channelCalculator.isUsingLeftJoyX() )
				TimerService.joyArea_L.xChannelSource.deleteObserver(TimerService.channelCalculator);
			if ( TimerService.channelCalculator.isUsingLeftJoyY() )
				TimerService.joyArea_L.yChannelSource.deleteObserver(TimerService.channelCalculator);
			if ( TimerService.channelCalculator.isUsingRightJoyX() )
				TimerService.joyArea_R.xChannelSource.deleteObserver(TimerService.channelCalculator);
			if ( TimerService.channelCalculator.isUsingRightJoyY() )
				TimerService.joyArea_R.yChannelSource.deleteObserver(TimerService.channelCalculator);
			
			((OrientationListener) TimerService.orientationListener).stopControls();
			
			if ( TimerService.periodicChannelData != null ) {
				for (int i = 1; i <= 12; i++) {
					TimerService.periodicChannelData.setChannel(i, 1500);
				}
			}
			
			Gui.setButtonOn(button_start, R.drawable.start);
		}
	}
	
	private class TimerTask extends AsyncTask<Void, Void, Void> {

		@Override
		protected Void doInBackground(Void... arg0) {
			while ( onTimer ) {
				timerHandler.sendEmptyMessage(0);
				try {
					Thread.sleep(1000);
				} 
				catch (InterruptedException e) {
				}
			}
			return null;
		}
	};
	
	private Handler timerHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			long ellapsedTime = (SystemClock.elapsedRealtime() - startTime) / 1000;
			int min = (int) (ellapsedTime / 60);
			int sec = (int) (ellapsedTime - (min * 60));
			String time = String.format("%02d:%02d", min, sec);
			textView_time.setText(time);
		}
	};
	
	@Override
	public void onAttachedToWindow() {
		// getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD);
		super.onAttachedToWindow();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		Boolean prevent = false;
		
	    if ( keyCode == KeyEvent.KEYCODE_MENU ) {
	    	if ( layout_bottom.getVisibility() == View.GONE )
	    		layout_bottom.setVisibility(View.VISIBLE);
	    	else
	    		layout_bottom.setVisibility(View.GONE);
	    }

	    if ( TimerService.onDrive ) {
	    	if ( keyCode == KeyEvent.KEYCODE_BACK )
	    		prevent = sharedPreferences.getBoolean(getString(R.string.settingDisableBack), false);
	    	if ( keyCode == KeyEvent.KEYCODE_HOME )
	    		prevent = sharedPreferences.getBoolean(getString(R.string.settingDisableHome), false);
	    }
	    
	    if ( prevent )
	    	return false;
	    else {
	    	home_touch = false;
	    	
	    	return super.onKeyDown(keyCode, event);
	    }
	}

}
