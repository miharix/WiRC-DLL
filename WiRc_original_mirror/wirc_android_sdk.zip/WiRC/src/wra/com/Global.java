package wra.com;

public class Global {
	
	public static final short BROADCAST_SERVICE_UDP_PORT = 1984;

}
