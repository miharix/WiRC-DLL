package wra.com;

import java.io.File;

import over.TimerService;
import wirc.dension.com.R;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import camera.MjpegDisplay;
import camera.Player;
import develop.Notify;
import dialog.Dialog;
import file.storage.ExternalStorage;

public class PlayerActivity extends Activity {
	
	private ExternalStorage externalStorage;
	private Player player;
	private Dialog dialog;
	private File[] files;
	private LayoutInflater inflater;
	
	private camera.MjpegDisplay mjpegDisplay;
	private LinearLayout layout_videos;
	
	private String rootPath = "";
	private int selectedFile = 0;
	private String fileName = "";
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.player);
        
        externalStorage = new ExternalStorage();
        dialog = new Dialog(PlayerActivity.this, dialogInterface_listener); 
        inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE); 
        mjpegDisplay = (MjpegDisplay) this.findViewById(R.player.mjpegDisplay);
        layout_videos = (LinearLayout) this.findViewById(R.player.layout_videos);
        
        if ( externalStorage.isReady() ) {
        	rootPath = externalStorage.getAbsolutePath() + "/" + TimerService.rootPath;
        	player = new Player(mjpegDisplay, rootPath);
        	listFiles();
            addImages();
            Toast.makeText(PlayerActivity.this, getString(R.string.sPleaseTapToPlay), Toast.LENGTH_SHORT).show();
        }
        else {
        	Toast.makeText(PlayerActivity.this, getString(R.string.sExternalStorageNotReady), Toast.LENGTH_SHORT).show();
        	Notify.e(this, "externalStorage.isReady()");
        	finish();
        }
	}
	
	private void listFiles() {
		try {
			File dir = new File(rootPath);
			files = dir.listFiles();
		}
		catch (Throwable e) {
			Notify.e(this, e.toString());
		}
	}
	
	private void addImages() {
		try {
			for (int i=0; i < files.length; i++) {
				FrameLayout layout_video = (FrameLayout) inflater.inflate(R.layout.player_video_item, null);
				layout_video.setTag(i);
				ImageView imageView = (ImageView) layout_video.getChildAt(0);
				TextView textView_time = (TextView) layout_video.getChildAt(1);
				String title = files[i].getName();
				title = title.substring(0, title.lastIndexOf("."));
				textView_time.setText(title);
				ImageButton imageButton_delete = (ImageButton) layout_video.findViewById(R.play_video_item.imageButton_delete);
				imageButton_delete.setOnClickListener(imageButton_delete_OnClickListener);
				imageButton_delete.setTag(i);
				Bitmap bitmap = player.getFirstFrame(rootPath + files[i].getName());
				imageView.setImageBitmap(bitmap);
				layout_video.setOnClickListener(layout_video_OnClickListener);
				layout_videos.addView(layout_video);
			}
			
		}
		catch (Throwable e) {
			Notify.e(this, e.toString());
		}
	}
	
	private OnClickListener layout_video_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View view) {
			try {
				if ( player.onTask )
					player.stop();
				
				int i = Integer.parseInt(view.getTag().toString());
				String fileName = rootPath + files[i].getName();
				String ext = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
				if ( ext.equals("jpg") ) {
					player.showFirstFrame(fileName);
				}
				else {
					player.start(fileName);
				}
			}
			catch (Throwable e) {
				Notify.e(this, e.toString());
			}
		}
	};
	
	private OnClickListener imageButton_delete_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View view) {
			selectedFile = Integer.parseInt(view.getTag().toString());
			fileName = files[selectedFile].getName();
			
			dialog.message(getString(R.string.sDeleteFile), fileName, getString(R.string.sYes), getString(R.string.sNo));
		}
	};
	
	private DialogInterface.OnClickListener dialogInterface_listener = new DialogInterface.OnClickListener() {
		@Override
		public void onClick(DialogInterface dialog, int which) {
			if ( which == -1 ) {
				if ( externalStorage.deleteFile(rootPath + fileName) ) {
					View view = layout_videos.getChildAt(selectedFile);
					view.setVisibility(View.GONE);
				}
			}
		}
	}; 

}
