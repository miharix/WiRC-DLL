package com.dension.sqliteaccess;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import channel.ChannelInfo;
import develop.Notify;

public class ControlsTable {
	
	
	public static final String KEY_ROWID = "_id";
	public static final String KEY_NAME = "name";
	public static final String KEY_CHANNEL_INDEX = "channel_index";
	public static final String KEY_MODE_NUM = "mode_num";
	public static final String KEY_SOURCE_NUM = "source_num";
	public static final String KEY_IS_DIGITAL = "is_digital";
	public static final String KEY_PROFILE_ID = "profile_id";
	public static final String DATABASE_CREATE = "CREATE TABLE controls ("
			+ "_id            integer PRIMARY KEY AUTOINCREMENT NOT NULL,"
			+ "profile_id     integer NOT NULL,"
			+ "mode_num       integer NOT NULL,"
			+ "source_num     integer NOT NULL,"
			+ "channel_index  integer,"
			+ "is_digital     integer NOT NULL DEFAULT 0,"
			+ "name           varchar(50) NOT NULL);";

	public static final String DATABASE_TABLE = "controls";
	
	private SQLiteDatabase db;
	
	public ControlsTable(SQLiteDatabase db) {
		this.db = db;
	}

	public boolean createControlsForProfile(long profileId) {
		boolean res = true;
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= ChannelInfo.CHANNELS; j++) {
				ContentValues args = new ContentValues();
				args.put(KEY_NAME, "Channel " + j);
				args.put(KEY_MODE_NUM, i);
				args.put(KEY_CHANNEL_INDEX, j);
				args.put(KEY_SOURCE_NUM, 0);
				args.put(KEY_PROFILE_ID, profileId);
				args.put(KEY_IS_DIGITAL, 0);
				long resId = db.insert(DATABASE_TABLE, null, args);
				
				if (resId < 0) {
					res = false;
				}
			}
			for (int j = 1; j <= ChannelInfo.DIGITAL_CHANNELS; j++) {
				ContentValues args = new ContentValues();
				args.put(KEY_NAME, "Channel " + j);
				args.put(KEY_MODE_NUM, i);
				args.put(KEY_CHANNEL_INDEX, j);
				args.put(KEY_SOURCE_NUM, 0);
				args.put(KEY_PROFILE_ID, profileId);
				args.put(KEY_IS_DIGITAL, 1);
				long resId = db.insert(DATABASE_TABLE, null, args);
				
				if (resId < 0) {
					res = false;
				}
			}
		}
		return res;
	}

	public boolean deleteControl(final long rowId) {
		return db.delete(DATABASE_TABLE, KEY_ROWID + "=" + rowId, null) > 0;
	}

	public boolean delControlsByProfile(long profileId) {
		boolean res = db.delete(DATABASE_TABLE, KEY_PROFILE_ID + "="
				+ profileId, null) > 0;
		
		return res;
	}

	public Cursor fetchControls(final long profileId, final int modeNum)
			throws SQLException {
		Cursor mCursor =

		db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID,
				KEY_CHANNEL_INDEX, KEY_MODE_NUM, KEY_IS_DIGITAL, KEY_NAME,
				KEY_PROFILE_ID, KEY_SOURCE_NUM }, KEY_PROFILE_ID + "="
				+ profileId + " AND " + KEY_MODE_NUM + "=" + modeNum, null,
				null, null, null, null);
		if (mCursor != null) {
			mCursor.moveToFirst();
		}
		return mCursor;

	}

	public Cursor fetchControl(final long chIndex, final long profileId,
			final int modeNum, final boolean isDigital) throws SQLException {
		Cursor mCursor =

		db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID,
				KEY_CHANNEL_INDEX, KEY_MODE_NUM, KEY_NAME, KEY_PROFILE_ID,
				KEY_SOURCE_NUM, KEY_IS_DIGITAL }, KEY_CHANNEL_INDEX + "="
				+ chIndex + " AND " + KEY_PROFILE_ID + "=" + profileId
				+ " AND " + KEY_MODE_NUM + "=" + modeNum + " AND "
				+ KEY_IS_DIGITAL + "=" + (isDigital ? 1 : 0), null, null,
				null, null, null);
		
		if (mCursor != null) {
			mCursor.moveToFirst();
		}
		return mCursor;

	}

	public int fetchSourceByChannelIdx(final long chIndex, final long profileId, final int modeNum) {
		int result = -1;
		
		Cursor cursor =	db.query(
				true, DATABASE_TABLE, new String[] { KEY_ROWID,
				KEY_CHANNEL_INDEX, KEY_MODE_NUM, KEY_NAME, KEY_PROFILE_ID,
				KEY_SOURCE_NUM, KEY_IS_DIGITAL }, KEY_CHANNEL_INDEX + "="
				+ chIndex + " AND " + KEY_PROFILE_ID + "=" + profileId
				+ " AND " + KEY_MODE_NUM + "=" + modeNum, null, null, null,
				null, null);
		if (cursor != null) {
			cursor.moveToFirst();
			if ( cursor.getCount() > 0 )
				result = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_SOURCE_NUM));
			cursor.close();
		}
		
		return result; 
	}
	
	public int fetchSourceByChannelIdx(final long chIndex, final long profileId, final int modeNum, Boolean isDigital) {
		int result = -1;
		
		try {
			String selection = 
				KEY_CHANNEL_INDEX + "=" + chIndex + " AND " + 
				KEY_PROFILE_ID + "=" + profileId + " AND " + 
				KEY_MODE_NUM + "=" + modeNum;
			
			if ( isDigital )
				selection = selection + " AND " + KEY_IS_DIGITAL;
			
			Cursor cursor =	db.query(
				true, 
				DATABASE_TABLE, 
				new String[] { 
					KEY_ROWID, 
					KEY_CHANNEL_INDEX, 
					KEY_MODE_NUM, 
					KEY_NAME, 
					KEY_PROFILE_ID, KEY_SOURCE_NUM, 
					KEY_IS_DIGITAL 
				},
				selection,
				null, null, null, null, null);
			if (cursor != null) {
				cursor.moveToFirst();
				if ( cursor.getCount() > 0 )
					result = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_SOURCE_NUM));
				cursor.close();
			}
		}
		catch (Throwable e) {
			Notify.e(this, "fetchSourceByChannelIdx() " + e.toString());
		}
		
		return result; 
	}

	public long updateControl(final long rowId, final int chIdx,
			final int modeNum, final int sourceNum, final int profileIdx) {
		ContentValues args = new ContentValues();
		args.put(KEY_CHANNEL_INDEX, chIdx);
		args.put(KEY_MODE_NUM, modeNum);
		args.put(KEY_SOURCE_NUM, sourceNum);
		args.put(KEY_PROFILE_ID, profileIdx);

		return db.update(DATABASE_TABLE, args, KEY_ROWID + "=" + rowId,	null);
	}

	public long updateControl(final int chIdx, final int modeNum, final int sourceNum, final long profileId, int isDigital) {
		ContentValues args = new ContentValues();
		args.put(KEY_SOURCE_NUM, sourceNum);

		return db.update(DATABASE_TABLE, args, KEY_MODE_NUM + "=" + modeNum
				+ " AND " + KEY_CHANNEL_INDEX + "=" + chIdx + " AND "
				+ KEY_PROFILE_ID + "=" + profileId + " AND "
				+ KEY_IS_DIGITAL + "=" + isDigital, null);
	}
}