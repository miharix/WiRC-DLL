package com.dension.sqliteaccess;

public class ChannelDTO {

	public long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getChIdx() {
		return chIdx;
	}

	public void setChIdx(int chIdx) {
		this.chIdx = chIdx;
	}

	public int getIsReverse() {
		return isReverse;
	}

	public void setIsReverse(int isReverse) {
		this.isReverse = isReverse;
	}

	public int getMinValue() {
		return minValue;
	}

	public void setMinValue(int minValue) {
		this.minValue = minValue;
	}

	public int getMaxValue() {
		return maxValue;
	}

	public void setMaxValue(int maxValue) {
		this.maxValue = maxValue;
	}

	public int getTrimValue() {
		return trimValue;
	}

	public void setTrimValue(int trimValue) {
		this.trimValue = trimValue;
	}

	public int getFailsafeMode() {
		return failsafeMode;
	}

	public void setFailsafeMode(int failsafeMode) {
		this.failsafeMode = failsafeMode;
	}

	public int getFailsafePreset() {
		return failsafePreset;
	}

	public void setFailsafePreset(int failsafePreset) {
		this.failsafePreset = failsafePreset;
	}

	public int getSensType() {
		return sensType;
	}

	public void setSensType(int sensType) {
		this.sensType = sensType;
	}

	public int getExpFactor() {
		return expFactor;
	}

	public void setExpFactor(int expFactor) {
		this.expFactor = expFactor;
	}

	public int getSensMix() {
		return sensMix;
	}

	public void setSensMix(int sensMix) {
		this.sensMix = sensMix;
	}

	public int getSensMixCh() {
		return sensMixCh;
	}

	public void setSensMixCh(int sensMixCh) {
		this.sensMixCh = sensMixCh;
	}

	public int getSensMixAbs() {
		return sensMixAbs;
	}

	public void setSensMixAbs(int sensMixAbs) {
		this.sensMixAbs = sensMixAbs;
	}

	public int getSensMixFact() {
		return sensMixFact;
	}

	public void setSensMixFact(int sensMixFact) {
		this.sensMixFact = sensMixFact;
	}

	public int getValMix() {
		return valMix;
	}

	public void setValMix(int valMix) {
		this.valMix = valMix;
	}

	public int getValMixCh() {
		return valMixCh;
	}

	public void setValMixCh(int valMixCh) {
		this.valMixCh = valMixCh;
	}

	public int getValMixAbs() {
		return valMixAbs;
	}

	public void setValMixAbs(int valMixAbs) {
		this.valMixAbs = valMixAbs;
	}

	public int getValMixFact() {
		return valMixFact;
	}

	public void setValMixFact(int valMixFact) {
		this.valMixFact = valMixFact;
	}

	public int getRepFq() {
		return repFq;
	}

	public void setRepFq(int repFq) {
		this.repFq = repFq;
	}

	public int getProfileId() {
		return profileId;
	}

	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}

	public long rowId;
	public String name;
	public int chIdx;
	public int isReverse;
	public int minValue;
	public int maxValue;
	public int trimValue;
	public int failsafeMode;
	public int failsafePreset;
	public int sensType;
	public int expFactor;
	public int sensMix;
	public int sensMixCh;
	public int sensMixAbs;
	public int sensMixFact;
	public int valMix;
	public int valMixCh;
	public int valMixAbs;
	public int valMixFact;
	public int repFq;
	public int profileId;
}
