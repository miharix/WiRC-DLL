package com.dension.sqliteaccess;

import wirc.dension.com.R;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import channel.ChannelInfo;
import channel.ChannelSource;
import develop.Notify;

public class WircDbAdapter {

	public class ProfilesTable {
		public static final int QUERY_FAILED = -1;
		public static final String KEY_ROWID = "_id";
		public static final String KEY_NAME = "name";
		public static final String KEY_IS_DEFAULT = "is_default";
		public static final String KEY_IS_ACTIVE = "is_active";
		public static final String DATABASE_CREATE = "CREATE TABLE profiles (" + "_id integer PRIMARY KEY AUTOINCREMENT NOT NULL," + "name varchar(50) NOT NULL," + "is_default integer NOT NULL DEFAULT 0," + "is_active integer NOT NULL DEFAULT 0);";
		public static final String ROW1 = "INSERT INTO profiles (_id, name, is_default, is_active) VALUES (1, 'Default', 1, 0);";
		public static final String ROW2 = "INSERT INTO profiles (_id, name, is_default, is_active) VALUES (2, 'Default', 0, 1);";
		public static final String DATABASE_TABLE = "profiles";

		public long createProfile(final String name, final int isActive) {
			ContentValues initialValues = new ContentValues();
			initialValues.put(KEY_NAME, name);
			initialValues.put(KEY_IS_ACTIVE, isActive);

			long profileId = db.insert(DATABASE_TABLE, null, initialValues);

			if (profileId > 0) {
				getChannelsTable().createChannelsForProfile(profileId);
				getDigitalChannelsTable().createDigitalChannelsForProfile(profileId);
				getControlsTable().createControlsForProfile(profileId);
				getManeuversTable().createManeuversForProfile(profileId);
				getButtonsTable().createButtonsForProfile(profileId);
				getPositionsTable().createPositionsForProfile(profileId);
				if (isActive == 1)
					clearActives(profileId);
			}
			return profileId;
		}

		public int setActiveProfile(final long rowId) {
			ContentValues args = new ContentValues();
			args.put(KEY_IS_ACTIVE, 1);

			int res = db.update(DATABASE_TABLE, args, KEY_ROWID + "=" + rowId, null);
			if (res > 0) {
				clearActives(rowId);
			}
			return res;
		}

		public int updateProfile(final long rowId, final String name, final int isActive) {
			ContentValues args = new ContentValues();
			args.put(KEY_NAME, name);
			args.put(KEY_IS_ACTIVE, isActive);

			int res = db.update(DATABASE_TABLE, args, KEY_ROWID + "=" + rowId, null);
			if (res > 0 && isActive == 1) {
				clearActives(rowId);
			}
			return res;
		}

		private void clearActives(long rowId) {
			ContentValues args = new ContentValues();
			args.put(KEY_IS_ACTIVE, 0);
			db.update(DATABASE_TABLE, args, KEY_ROWID + "<>" + rowId, null);

		}

		public int deleteProfile(final long profileId) {
			int result = -1;

			Cursor profile = fetchProfile(profileId);
			int isActive = profile.getInt(profile.getColumnIndexOrThrow(KEY_IS_ACTIVE));
			if (isActive == 1) {
				result = -1;
			} else {
				result = db.delete(DATABASE_TABLE, KEY_ROWID + "=" + profileId, null);
				if (result > 0) {
					getChannelsTable().delChannelsByProfile(profileId);
					getDigitalChannelsTable().delDigitalChannelsByProfile(profileId);
					getControlsTable().delControlsByProfile(profileId);
					getManeuversTable().delManeuversByProfile(profileId);
					getButtonsTable().delButtonsByProfile(profileId);
					getPositionsTable().delPositionsByProfile(profileId);
				}
			}

			profile.close();

			return result;
		}

		public Cursor fetchAllProfiles() {

			return db.query(DATABASE_TABLE, new String[] { KEY_ROWID, KEY_NAME, KEY_IS_DEFAULT, KEY_IS_ACTIVE }, KEY_IS_DEFAULT + " = 0", null, null, null, null);
		}

		public Cursor fetchProfile(final long rowId) throws SQLException {

			Cursor mCursor =

			db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID, KEY_NAME, KEY_IS_DEFAULT, KEY_IS_ACTIVE }, KEY_ROWID + "=" + rowId, null, null, null, null, null);
			if (mCursor != null) {
				mCursor.moveToFirst();
			}
			return mCursor;

		}

		public long getActiveProfileId() {
			long result = -1;
			Cursor cursor = db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID, KEY_IS_ACTIVE }, KEY_IS_ACTIVE + "=1", null, null, null, null, null);
			if (cursor != null) {
				cursor.moveToFirst();
			}

			result = cursor.getLong(cursor.getColumnIndexOrThrow(KEY_ROWID));
			cursor.close();

			return result;
		}
	}

	public class ChannelsTable {
		public static final String KEY_ROWID = "_id";
		public static final String KEY_CHANNEL_INDEX = "channel_index";
		public static final String KEY_NAME = "name";
		public static final String KEY_IS_REVERSE = "is_reverse";
		public static final String KEY_MIN_VALUE = "min_value";
		public static final String KEY_MAX_VALUE = "max_value";
		public static final String KEY_TRIM_VALUE = "trim_value";
		public static final String KEY_FAILSAFE_MODE = "failsafe_mode";
		public static final String KEY_FAILSAFE_PRESET = "failsafe_preset";
		public static final String KEY_SENSITIVITY_TYPE = "sensitivity_type";
		public static final String KEY_EXPONENTIAL_FACTOR = "exponential_factor";
		public static final String KEY_SENSITIVITY_MIXER = "sensitivity_mixer";
		public static final String KEY_SENSITIVITY_MIXER_CHANNEL = "sensitivity_mixer_channel";
		public static final String KEY_SENSITIVITY_MIXER_ABSOLUTE = "sensitivity_mixer_absolute";
		public static final String KEY_SENSITIVITY_MIXER_FACTOR = "sensitivity_mixer_factor";
		public static final String KEY_VALUE_MIXER = "value_mixer";
		public static final String KEY_VALUE_MIXER_CHANNEL = "value_mixer_channel";
		public static final String KEY_VALUE_MIXER_ABSOLUTE = "value_mixer_absolute";
		public static final String KEY_VALUE_MIXER_FACTOR = "value_mixer_factor";
		public static final String KEY_REPEAT_FQ = "repeat_fq";
		public static final String KEY_PROFILE_ID = "profile_id";
		public static final String DATABASE_CREATE = "CREATE TABLE channels (" + "_id                         integer PRIMARY KEY AUTOINCREMENT NOT NULL," + "channel_index               integer NOT NULL," + "name                        varchar(50) NOT NULL," + "is_reverse                  integer NOT NULL DEFAULT 0," + "min_value                   integer NOT NULL DEFAULT 1000," + "max_value                   integer NOT NULL DEFAULT 2000," + "trim_value                  integer NOT NULL DEFAULT 1500," + "failsafe_mode               integer NOT NULL DEFAULT 0," + "failsafe_preset             integer NOT NULL DEFAULT 1500," + "sensitivity_type            integer NOT NULL DEFAULT 0," + "exponential_factor          integer NOT NULL DEFAULT 0," + "sensitivity_mixer           integer NOT NULL DEFAULT 0," + "sensitivity_mixer_channel   integer," + "sensitivity_mixer_absolute  integer NOT NULL DEFAULT 0," + "sensitivity_mixer_factor    integer NOT NULL DEFAULT 0," + "value_mixer                 integer NOT NULL DEFAULT 0," + "value_mixer_channel         integer," + "value_mixer_absolute        integer NOT NULL DEFAULT 0," + "value_mixer_factor          integer NOT NULL DEFAULT 0," + "repeat_fq                   integer NOT NULL DEFAULT 50," + "profile_id                  integer NOT NULL);";

		public static final String DATABASE_TABLE = "channels";

		public long createChannel(final long rowId, final String name, final int chIdx, final int isReverse, final int minValue, final int maxValue, final int trimValue, final int failsafeMode, final int failsafePreset, final int sensType, final int expFactor, final int sensMix, final int sensMixCh, final int sensMixAbs, final int sensMixFact, final int valMix, final int valMixCh, final int valMixAbs, final int valMixFact, final int repFq, final int profileIdx) {
			ContentValues args = new ContentValues();
			args.put(KEY_CHANNEL_INDEX, chIdx);
			args.put(KEY_NAME, name);
			args.put(KEY_IS_REVERSE, isReverse);
			args.put(KEY_MIN_VALUE, minValue);
			args.put(KEY_MAX_VALUE, maxValue);
			args.put(KEY_TRIM_VALUE, trimValue);
			args.put(KEY_FAILSAFE_MODE, failsafeMode);
			args.put(KEY_FAILSAFE_PRESET, failsafePreset);
			args.put(KEY_SENSITIVITY_TYPE, sensType);
			args.put(KEY_EXPONENTIAL_FACTOR, expFactor);
			args.put(KEY_SENSITIVITY_MIXER, sensMix);
			args.put(KEY_SENSITIVITY_MIXER_CHANNEL, sensMixCh);
			args.put(KEY_SENSITIVITY_MIXER_ABSOLUTE, sensMixAbs);
			args.put(KEY_SENSITIVITY_MIXER_FACTOR, sensMixFact);
			args.put(KEY_VALUE_MIXER, valMix);
			args.put(KEY_VALUE_MIXER_CHANNEL, valMixCh);
			args.put(KEY_VALUE_MIXER_ABSOLUTE, valMixAbs);
			args.put(KEY_VALUE_MIXER_FACTOR, valMixFact);
			args.put(KEY_REPEAT_FQ, repFq);
			args.put(KEY_PROFILE_ID, profileIdx);

			return db.insert(DATABASE_TABLE, null, args);
		}

		public boolean createChannelsForProfile(long profileId) {
			boolean res = true;
			for (int i = 1; i <= ChannelInfo.CHANNELS; i++) {
				ContentValues args = new ContentValues();
				args.put(KEY_NAME, "Channel" + i);
				args.put(KEY_CHANNEL_INDEX, i);
				args.put(KEY_PROFILE_ID, profileId);
				long resId = db.insert(DATABASE_TABLE, null, args);

				if (resId < 0) {
					res = false;
				}
			}
			return res;
		}

		public boolean deleteChannel(final long rowId) {
			return db.delete(DATABASE_TABLE, KEY_ROWID + "=" + rowId, null) > 0;
		}

		public boolean delChannelsByProfile(long profileId) {
			boolean res = db.delete(DATABASE_TABLE, KEY_PROFILE_ID + "=" + profileId, null) > 0;

			return res;
		}

		public Cursor fetchChannel(final long rowId) throws SQLException {
			Cursor mCursor =

			db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID, KEY_CHANNEL_INDEX, KEY_NAME, KEY_IS_REVERSE, KEY_MIN_VALUE, KEY_MAX_VALUE, KEY_TRIM_VALUE, KEY_FAILSAFE_MODE, KEY_FAILSAFE_PRESET, KEY_SENSITIVITY_TYPE, KEY_EXPONENTIAL_FACTOR, KEY_SENSITIVITY_MIXER, KEY_SENSITIVITY_MIXER_CHANNEL, KEY_SENSITIVITY_MIXER_ABSOLUTE, KEY_SENSITIVITY_MIXER_FACTOR, KEY_VALUE_MIXER, KEY_VALUE_MIXER_CHANNEL, KEY_VALUE_MIXER_ABSOLUTE, KEY_VALUE_MIXER_FACTOR, KEY_REPEAT_FQ, KEY_PROFILE_ID }, KEY_ROWID + "=" + rowId, null, null, null, null, null);
			if (mCursor != null) {
				mCursor.moveToFirst();
			}
			return mCursor;

		}

		public Cursor fechChannelsByProfile(final long profileId) {
			Cursor cursor =

			db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID, KEY_CHANNEL_INDEX, KEY_NAME, KEY_IS_REVERSE, KEY_MIN_VALUE, KEY_MAX_VALUE, KEY_TRIM_VALUE, KEY_FAILSAFE_MODE, KEY_FAILSAFE_PRESET, KEY_SENSITIVITY_TYPE, KEY_EXPONENTIAL_FACTOR, KEY_SENSITIVITY_MIXER, KEY_SENSITIVITY_MIXER_CHANNEL, KEY_SENSITIVITY_MIXER_ABSOLUTE, KEY_SENSITIVITY_MIXER_FACTOR, KEY_VALUE_MIXER, KEY_VALUE_MIXER_CHANNEL, KEY_VALUE_MIXER_ABSOLUTE, KEY_VALUE_MIXER_FACTOR, KEY_REPEAT_FQ, KEY_PROFILE_ID }, KEY_PROFILE_ID + "=" + profileId, null, null, null, KEY_CHANNEL_INDEX, null);
			if (cursor != null) {
				cursor.moveToFirst();
			}
			return cursor;
		}

		public Cursor fetchChannel(final long chIndex, final long profileId) throws SQLException {
			Cursor mCursor =

			db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID, KEY_CHANNEL_INDEX, KEY_NAME, KEY_IS_REVERSE, KEY_MIN_VALUE, KEY_MAX_VALUE, KEY_TRIM_VALUE, KEY_FAILSAFE_MODE, KEY_FAILSAFE_PRESET, KEY_SENSITIVITY_TYPE, KEY_EXPONENTIAL_FACTOR, KEY_SENSITIVITY_MIXER, KEY_SENSITIVITY_MIXER_CHANNEL, KEY_SENSITIVITY_MIXER_ABSOLUTE, KEY_SENSITIVITY_MIXER_FACTOR, KEY_VALUE_MIXER, KEY_VALUE_MIXER_CHANNEL, KEY_VALUE_MIXER_ABSOLUTE, KEY_VALUE_MIXER_FACTOR, KEY_REPEAT_FQ, KEY_PROFILE_ID }, KEY_CHANNEL_INDEX + "=" + chIndex + " AND " + KEY_PROFILE_ID + "=" + profileId, null, null, null, null, null);
			if (mCursor != null) {
				mCursor.moveToFirst();
			}
			return mCursor;

		}

		public Cursor fetchChannelsByProfile(long profileId) throws SQLException {
			Cursor mCursor =

			db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID, KEY_CHANNEL_INDEX, KEY_NAME, KEY_IS_REVERSE, KEY_MIN_VALUE, KEY_MAX_VALUE, KEY_TRIM_VALUE, KEY_FAILSAFE_MODE, KEY_FAILSAFE_PRESET, KEY_SENSITIVITY_TYPE, KEY_EXPONENTIAL_FACTOR, KEY_SENSITIVITY_MIXER, KEY_SENSITIVITY_MIXER_CHANNEL, KEY_SENSITIVITY_MIXER_ABSOLUTE, KEY_SENSITIVITY_MIXER_FACTOR, KEY_VALUE_MIXER, KEY_VALUE_MIXER_CHANNEL, KEY_VALUE_MIXER_ABSOLUTE, KEY_VALUE_MIXER_FACTOR, KEY_REPEAT_FQ, KEY_PROFILE_ID }, KEY_PROFILE_ID + "=" + profileId, null, null, null, null, null);
			if (mCursor != null) {
				mCursor.moveToFirst();
			}
			return mCursor;
		}

		public ChannelDTO getChannelDTO(int channelNum, long profileId) {
			ChannelDTO channelDTO = new ChannelDTO();

			Cursor settings = getChannelsTable().fetchChannel(channelNum, profileId);
			channelDTO.rowId = settings.getInt(settings.getColumnIndexOrThrow(ChannelsTable.KEY_ROWID));
			channelDTO.chIdx = channelNum;
			channelDTO.name = settings.getString(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_NAME));
			channelDTO.isReverse = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_IS_REVERSE));
			channelDTO.minValue = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_MIN_VALUE));
			channelDTO.maxValue = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_MAX_VALUE));
			channelDTO.trimValue = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_TRIM_VALUE));
			channelDTO.failsafeMode = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_FAILSAFE_MODE));
			channelDTO.failsafePreset = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_FAILSAFE_PRESET));
			channelDTO.sensType = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_SENSITIVITY_TYPE));
			channelDTO.expFactor = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_EXPONENTIAL_FACTOR));
			channelDTO.sensMix = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_SENSITIVITY_MIXER));
			channelDTO.sensMixCh = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_SENSITIVITY_MIXER_CHANNEL));
			channelDTO.sensMixAbs = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_SENSITIVITY_MIXER_ABSOLUTE));
			channelDTO.sensMixFact = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_SENSITIVITY_MIXER_FACTOR));
			channelDTO.valMix = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_VALUE_MIXER));
			channelDTO.valMixCh = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_VALUE_MIXER_CHANNEL));
			channelDTO.valMixAbs = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_VALUE_MIXER_ABSOLUTE));
			channelDTO.valMixFact = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_VALUE_MIXER_FACTOR));
			channelDTO.repFq = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_REPEAT_FQ));
			channelDTO.profileId = (int) profileId;

			return channelDTO;
		}

		public boolean updateChannel(ChannelDTO channelDTO) {
			ContentValues args = new ContentValues();
			args.put(KEY_CHANNEL_INDEX, channelDTO.getChIdx());
			args.put(KEY_NAME, channelDTO.getName());
			args.put(KEY_IS_REVERSE, channelDTO.getIsReverse());
			args.put(KEY_MIN_VALUE, channelDTO.getMinValue());
			args.put(KEY_MAX_VALUE, channelDTO.getMaxValue());
			args.put(KEY_TRIM_VALUE, channelDTO.getTrimValue());
			args.put(KEY_FAILSAFE_MODE, channelDTO.getFailsafeMode());
			args.put(KEY_FAILSAFE_PRESET, channelDTO.getFailsafePreset());
			args.put(KEY_SENSITIVITY_TYPE, channelDTO.getSensType());
			args.put(KEY_EXPONENTIAL_FACTOR, channelDTO.getExpFactor());
			args.put(KEY_SENSITIVITY_MIXER, channelDTO.getSensMix());
			args.put(KEY_SENSITIVITY_MIXER_CHANNEL, channelDTO.getSensMixCh());
			args.put(KEY_SENSITIVITY_MIXER_ABSOLUTE, channelDTO.getSensMixAbs());
			args.put(KEY_SENSITIVITY_MIXER_FACTOR, channelDTO.getSensMixFact());
			args.put(KEY_VALUE_MIXER, channelDTO.getValMix());
			args.put(KEY_VALUE_MIXER_CHANNEL, channelDTO.getValMixCh());
			args.put(KEY_VALUE_MIXER_ABSOLUTE, channelDTO.getValMixAbs());
			args.put(KEY_VALUE_MIXER_FACTOR, channelDTO.getValMixFact());
			args.put(KEY_REPEAT_FQ, channelDTO.getRepFq());
			args.put(KEY_PROFILE_ID, channelDTO.getProfileId());

			return db.update(DATABASE_TABLE, args, KEY_ROWID + "=" + channelDTO.getRowId(), null) > 0;
		}
	}

	public class DigitalChannelsTable {
		public static final String KEY_ROWID = "_id";
		public static final String KEY_CHANNEL_INDEX = "channel_index";
		public static final String KEY_NAME = "name";
		public static final String KEY_MIN_VALUE = "min_value";
		public static final String KEY_MAX_VALUE = "max_value";
		public static final String KEY_INVERT_OUTPUT = "invert_output";
		public static final String KEY_PROFILE_ID = "profile_id";
		public static final String DATABASE_CREATE = "CREATE TABLE digital_channels (" + "_id                         integer PRIMARY KEY AUTOINCREMENT NOT NULL," + "channel_index               integer NOT NULL," + "name                        varchar(50) NOT NULL," + "invert_output               integer NOT NULL DEFAULT 0," + "min_value                   integer NOT NULL DEFAULT 1000," + "max_value                   integer NOT NULL DEFAULT 2000," + "profile_id                  integer NOT NULL);";

		public static final String DATABASE_TABLE = "digital_channels";

		public long createDigitalChannel(final long rowId, final String name, final int chIdx, final int isInverted, final int minValue, final int maxValue, final int profileIdx) {
			ContentValues args = new ContentValues();
			args.put(KEY_CHANNEL_INDEX, chIdx);
			args.put(KEY_NAME, name);
			args.put(KEY_INVERT_OUTPUT, isInverted);
			args.put(KEY_MIN_VALUE, minValue);
			args.put(KEY_MAX_VALUE, maxValue);
			args.put(KEY_PROFILE_ID, profileIdx);

			return db.insert(DATABASE_TABLE, null, args);
		}

		public boolean createDigitalChannelsForProfile(long profileId) {
			boolean res = true;
			for (int i = 1; i <= ChannelInfo.DIGITAL_CHANNELS; i++) {
				ContentValues args = new ContentValues();
				args.put(KEY_NAME, "Digital Channel" + i);
				args.put(KEY_CHANNEL_INDEX, i);
				args.put(KEY_PROFILE_ID, profileId);
				long resId = db.insert(DATABASE_TABLE, null, args);

				if (resId < 0) {
					res = false;
				}
			}
			return res;
		}

		public boolean deleteDigitalChannel(final long rowId) {
			return db.delete(DATABASE_TABLE, KEY_ROWID + "=" + rowId, null) > 0;
		}

		public boolean delDigitalChannelsByProfile(long profileId) {
			boolean res = db.delete(DATABASE_TABLE, KEY_PROFILE_ID + "=" + profileId, null) > 0;

			return res;
		}

		public Cursor fetchDigitalChannel(final long rowId) throws SQLException {
			Cursor mCursor =

			db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID, KEY_CHANNEL_INDEX, KEY_NAME, KEY_INVERT_OUTPUT, KEY_MIN_VALUE, KEY_MAX_VALUE, KEY_PROFILE_ID }, KEY_ROWID + "=" + rowId, null, null, null, null, null);
			if (mCursor != null) {
				mCursor.moveToFirst();
			}
			return mCursor;

		}

		public Cursor fetchDigitalChannel(final long chIndex, final long profileId) throws SQLException {
			Cursor mCursor =

			db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID, KEY_CHANNEL_INDEX, KEY_NAME, KEY_INVERT_OUTPUT, KEY_MIN_VALUE, KEY_MAX_VALUE, KEY_PROFILE_ID }, KEY_CHANNEL_INDEX + "=" + chIndex + " AND " + KEY_PROFILE_ID + "=" + profileId, null, null, null, null, null);
			if (mCursor != null) {
				mCursor.moveToFirst();
			}
			return mCursor;

		}

		public Cursor fetchDigitalChannelByProfile(final long profileId) throws SQLException {
			Cursor mCursor =

			db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID, KEY_CHANNEL_INDEX, KEY_NAME, KEY_INVERT_OUTPUT, KEY_MIN_VALUE, KEY_MAX_VALUE, KEY_PROFILE_ID }, KEY_PROFILE_ID + "=" + profileId, null, null, null, null, null);
			if (mCursor != null) {
				mCursor.moveToFirst();
			}
			return mCursor;

		}

		public boolean updateDigitalChannel(final long rowId, final String name, final int chIdx, final int isInverted, final int minValue, final int maxValue, final int profileIdx) {
			ContentValues args = new ContentValues();
			args.put(KEY_CHANNEL_INDEX, chIdx);
			args.put(KEY_NAME, name);
			args.put(KEY_INVERT_OUTPUT, isInverted);
			args.put(KEY_MIN_VALUE, minValue);
			args.put(KEY_MAX_VALUE, maxValue);
			args.put(KEY_PROFILE_ID, profileIdx);

			return db.update(DATABASE_TABLE, args, KEY_ROWID + "=" + rowId, null) > 0;
		}
	}

	/*
	public class ControlsTable {
		public static final String KEY_ROWID = "_id";
		public static final String KEY_NAME = "name";
		public static final String KEY_CHANNEL_INDEX = "channel_index";
		public static final String KEY_MODE_NUM = "mode_num";
		public static final String KEY_SOURCE_NUM = "source_num";
		public static final String KEY_IS_DIGITAL = "is_digital";
		public static final String KEY_PROFILE_ID = "profile_id";
		public static final String DATABASE_CREATE = "CREATE TABLE controls ("
				+ "_id            integer PRIMARY KEY AUTOINCREMENT NOT NULL,"
				+ "profile_id     integer NOT NULL,"
				+ "mode_num       integer NOT NULL,"
				+ "source_num     integer NOT NULL,"
				+ "channel_index  integer,"
				+ "is_digital     integer NOT NULL DEFAULT 0,"
				+ "name           varchar(50) NOT NULL);";

		public static final String DATABASE_TABLE = "controls";

		public boolean createControlsForProfile(long profileId) {
			boolean res = true;
			for (int i = 1; i <= 4; i++) {
				for (int j = 1; j <= ChannelInfo.CHANNELS; j++) {
					ContentValues args = new ContentValues();
					args.put(KEY_NAME, "Channel " + j);
					args.put(KEY_MODE_NUM, i);
					args.put(KEY_CHANNEL_INDEX, j);
					args.put(KEY_SOURCE_NUM, 0);
					args.put(KEY_PROFILE_ID, profileId);
					args.put(KEY_IS_DIGITAL, 0);
					long resId = db.insert(DATABASE_TABLE, null, args);
					
					if (resId < 0) {
						res = false;
					}
				}
				for (int j = 1; j <= ChannelInfo.DIGITAL_CHANNELS; j++) {
					ContentValues args = new ContentValues();
					args.put(KEY_NAME, "Channel " + j);
					args.put(KEY_MODE_NUM, i);
					args.put(KEY_CHANNEL_INDEX, j);
					args.put(KEY_SOURCE_NUM, 0);
					args.put(KEY_PROFILE_ID, profileId);
					args.put(KEY_IS_DIGITAL, 1);
					long resId = db.insert(DATABASE_TABLE, null, args);
					
					if (resId < 0) {
						res = false;
					}
				}
			}
			return res;
		}

		public boolean deleteControl(final long rowId) {
			return db.delete(DATABASE_TABLE, KEY_ROWID + "=" + rowId, null) > 0;
		}

		public boolean delControlsByProfile(long profileId) {
			boolean res = db.delete(DATABASE_TABLE, KEY_PROFILE_ID + "="
					+ profileId, null) > 0;
			
			return res;
		}

		public Cursor fetchControls(final long profileId, final int modeNum)
				throws SQLException {
			Cursor mCursor =

			db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID,
					KEY_CHANNEL_INDEX, KEY_MODE_NUM, KEY_IS_DIGITAL, KEY_NAME,
					KEY_PROFILE_ID, KEY_SOURCE_NUM }, KEY_PROFILE_ID + "="
					+ profileId + " AND " + KEY_MODE_NUM + "=" + modeNum, null,
					null, null, null, null);
			if (mCursor != null) {
				mCursor.moveToFirst();
			}
			return mCursor;

		}

		public Cursor fetchControl(final long chIndex, final long profileId,
				final int modeNum, final boolean isDigital) throws SQLException {
			Cursor mCursor =

			db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID,
					KEY_CHANNEL_INDEX, KEY_MODE_NUM, KEY_NAME, KEY_PROFILE_ID,
					KEY_SOURCE_NUM, KEY_IS_DIGITAL }, KEY_CHANNEL_INDEX + "="
					+ chIndex + " AND " + KEY_PROFILE_ID + "=" + profileId
					+ " AND " + KEY_MODE_NUM + "=" + modeNum + " AND "
					+ KEY_IS_DIGITAL + "=" + (isDigital ? 1 : 0), null, null,
					null, null, null);
			
			if (mCursor != null) {
				mCursor.moveToFirst();
			}
			return mCursor;

		}

		public int fetchSourceByChannelIdx(final long chIndex, final long profileId, final int modeNum) {
			int result = -1;
			
			Cursor cursor =	db.query(
					true, DATABASE_TABLE, new String[] { KEY_ROWID,
					KEY_CHANNEL_INDEX, KEY_MODE_NUM, KEY_NAME, KEY_PROFILE_ID,
					KEY_SOURCE_NUM, KEY_IS_DIGITAL }, KEY_CHANNEL_INDEX + "="
					+ chIndex + " AND " + KEY_PROFILE_ID + "=" + profileId
					+ " AND " + KEY_MODE_NUM + "=" + modeNum, null, null, null,
					null, null);
			if (cursor != null) {
				cursor.moveToFirst();
				if ( cursor.getCount() > 0 )
					result = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_SOURCE_NUM));
				cursor.close();
			}
			
			return result; 
		}
		
		public int fetchSourceByChannelIdx(final long chIndex, final long profileId, final int modeNum, Boolean isDigital) {
			int result = -1;
			
			try {
				String selection = 
					KEY_CHANNEL_INDEX + "=" + chIndex + " AND " + 
					KEY_PROFILE_ID + "=" + profileId + " AND " + 
					KEY_MODE_NUM + "=" + modeNum;
				
				if ( isDigital )
					selection = selection + " AND " + KEY_IS_DIGITAL;
				
				Cursor cursor =	db.query(
					true, 
					DATABASE_TABLE, 
					new String[] { 
						KEY_ROWID, 
						KEY_CHANNEL_INDEX, 
						KEY_MODE_NUM, 
						KEY_NAME, 
						KEY_PROFILE_ID, KEY_SOURCE_NUM, 
						KEY_IS_DIGITAL 
					},
					selection,
					null, null, null, null, null);
				if (cursor != null) {
					cursor.moveToFirst();
					if ( cursor.getCount() > 0 )
						result = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_SOURCE_NUM));
					cursor.close();
				}
			}
			catch (Throwable e) {
				Notify.e(this, "fetchSourceByChannelIdx() " + e.toString());
			}
			
			return result; 
		}

		public long updateControl(final long rowId, final int chIdx,
				final int modeNum, final int sourceNum, final int profileIdx) {
			ContentValues args = new ContentValues();
			args.put(KEY_CHANNEL_INDEX, chIdx);
			args.put(KEY_MODE_NUM, modeNum);
			args.put(KEY_SOURCE_NUM, sourceNum);
			args.put(KEY_PROFILE_ID, profileIdx);

			return db.update(DATABASE_TABLE, args, KEY_ROWID + "=" + rowId,
					null);
		}

		public long updateControl(final int chIdx, final int modeNum,
				final int sourceNum, final long profileId, int isDigital) {
			ContentValues args = new ContentValues();
			args.put(KEY_SOURCE_NUM, sourceNum);

			return db.update(DATABASE_TABLE, args, KEY_MODE_NUM + "=" + modeNum
					+ " AND " + KEY_CHANNEL_INDEX + "=" + chIdx + " AND "
					+ KEY_PROFILE_ID + "=" + profileId + " AND "
					+ KEY_IS_DIGITAL + "=" + isDigital, null);
		}
	}
	*/

	public class ManeuversTable {
		public static final String KEY_ROWID = "_id";
		public static final String KEY_MANEUVER_INDEX = "maneuver_index";
		public static final String KEY_CHANNEL_INDEX = "channel_index";
		public static final String KEY_IS_OVERRIDING = "is_overriding";
		public static final String KEY_VALUE = "value";
		public static final String KEY_PROFILE_ID = "profile_id";
		public static final String DATABASE_CREATE = "CREATE TABLE maneuvers (" + "_id             integer PRIMARY KEY AUTOINCREMENT NOT NULL," + "maneuver_index  integer NOT NULL," + "channel_index   integer NOT NULL," + "is_overriding   integer NOT NULL DEFAULT 0," + "profile_id      integer NOT NULL, " + "value           integer NOT NULL DEFAULT 1500" + ");";

		public static final String DATABASE_TABLE = "maneuvers";

		public boolean createManeuversForProfile(long profileId) {
			boolean res = true;
			for (int i = 1; i <= 2; i++) {
				for (int j = 1; j < ChannelInfo.CHANNELS + 1; j++) {
					ContentValues args = new ContentValues();
					args.put(KEY_MANEUVER_INDEX, i);
					args.put(KEY_CHANNEL_INDEX, j);
					args.put(KEY_PROFILE_ID, profileId);
					long resId = db.insert(DATABASE_TABLE, null, args);

					if (resId < 0) {
						res = false;
					}
				}
			}
			return res;
		}

		public boolean deleteManeuver(final long rowId) {
			return db.delete(DATABASE_TABLE, KEY_ROWID + "=" + rowId, null) > 0;
		}

		public boolean delManeuversByProfile(long profileId) {
			boolean res = db.delete(DATABASE_TABLE, KEY_PROFILE_ID + "=" + profileId, null) > 0;

			return res;
		}

		public Cursor fetchManeuver(final long manIdx, final long profileId, final int chIdx) {
			Cursor cursor =

			db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID, KEY_CHANNEL_INDEX, KEY_PROFILE_ID, KEY_MANEUVER_INDEX, KEY_IS_OVERRIDING, KEY_VALUE, KEY_ROWID }, KEY_MANEUVER_INDEX + "=" + manIdx + " AND " + KEY_PROFILE_ID + "=" + profileId + " AND " + KEY_CHANNEL_INDEX + "=" + chIdx, null, null, null, null, null);
			if (cursor != null) {
				cursor.moveToFirst();
			}
			return cursor;
		}

		public Cursor fetchManeuvers(final long manIdx, final long profileId) {
			Cursor cursor =

			db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID, KEY_CHANNEL_INDEX, KEY_PROFILE_ID, KEY_MANEUVER_INDEX, KEY_IS_OVERRIDING, KEY_VALUE, KEY_ROWID }, KEY_MANEUVER_INDEX + "=" + manIdx + " AND " + KEY_PROFILE_ID + "=" + profileId, null, null, null, null, null);
			if (cursor != null) {
				cursor.moveToFirst();
			}
			return cursor;
		}

		public long updateManeuver(final int chIdx, final int manIdx, final int value, final boolean isOverriding, final long profileId) {
			ContentValues args = new ContentValues();
			args.put(KEY_CHANNEL_INDEX, chIdx);
			args.put(KEY_MANEUVER_INDEX, manIdx);
			args.put(KEY_VALUE, value);
			args.put(KEY_IS_OVERRIDING, isOverriding ? 1 : 0);
			args.put(KEY_PROFILE_ID, profileId);

			return db.update(DATABASE_TABLE, args, KEY_CHANNEL_INDEX + "=" + chIdx + " AND " + KEY_MANEUVER_INDEX + "=" + manIdx + " AND " + KEY_PROFILE_ID + "=" + profileId, null);
		}
	}

	public static final String[] NAMES = { "Button A", "Button B", "Button C", "Button D" };

	public class ButtonsTable {
		public static final int TYPE_TRIGGER = 0;
		public static final int TYPE_TOGGLE = 1;
		public static final String KEY_ROWID = "_id";
		public static final String KEY_BUTTON_INDEX = "button_index";
		public static final String KEY_NAME = "name";
		public static final String KEY_TYPE = "type";
		public static final String KEY_OFF_LEVEL = "off_level";
		public static final String KEY_ON_LEVEL = "on_level";
		public static final String KEY_PROFILE_ID = "profile_id";
		public static final String KEY_MODE_NUM = "mode_num";
		public static final String DATABASE_CREATE = "CREATE TABLE buttons (" + "_id           integer PRIMARY KEY AUTOINCREMENT NOT NULL," + "button_index  integer NOT NULL," + "name          varchar(50) NOT NULL," + "type          integer NOT NULL DEFAULT 0," + "off_level     integer NOT NULL DEFAULT 1500," + "on_level      integer NOT NULL DEFAULT 2000," + "profile_id    integer NOT NULL," + "mode_num      integer NOT NULL" + ");";
		public static final String DATABASE_TABLE = "buttons";

		public boolean createButtonsForProfile(long profileId) {
			boolean res = true;
			for (int i = 1; i <= 4; i++) {
				for (int j = 0; j < 4; j++) {
					ContentValues args = new ContentValues();
					args.put(KEY_MODE_NUM, i);
					args.put(KEY_BUTTON_INDEX, j + 1);
					args.put(KEY_PROFILE_ID, profileId);
					args.put(KEY_NAME, NAMES[j]);
					long resId = db.insert(DATABASE_TABLE, null, args);

					if (resId < 0) {
						res = false;
					}
				}
			}
			return res;
		}

		public boolean deleteButton(final long rowId) {
			return db.delete(DATABASE_TABLE, KEY_ROWID + "=" + rowId, null) > 0;
		}

		public boolean delButtonsByProfile(long profileId) {
			boolean res = db.delete(DATABASE_TABLE, KEY_PROFILE_ID + "=" + profileId, null) > 0;

			return res;
		}

		public Cursor fetchButton(final long btnIdx, final long profileId, final long modeNum) {
			Cursor cursor =

			db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID, KEY_BUTTON_INDEX, KEY_PROFILE_ID, KEY_NAME, KEY_TYPE, KEY_OFF_LEVEL, KEY_ON_LEVEL, KEY_MODE_NUM }, KEY_BUTTON_INDEX + "=" + btnIdx + " AND " + KEY_PROFILE_ID + "=" + profileId + " AND " + KEY_MODE_NUM + "=" + modeNum, null, null, null, null, null);
			if (cursor != null) {
				cursor.moveToFirst();
			}
			return cursor;
		}

		public Cursor fetchButtons(final long modeNum, final long profileId) {
			Cursor cursor =

			db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID, KEY_BUTTON_INDEX, KEY_PROFILE_ID, KEY_NAME, KEY_TYPE, KEY_OFF_LEVEL, KEY_ON_LEVEL, KEY_MODE_NUM }, KEY_MODE_NUM + "=" + modeNum + " AND " + KEY_PROFILE_ID + "=" + profileId, null, null, null, null, null);
			if (cursor != null) {
				cursor.moveToFirst();
			}
			return cursor;
		}

		public long updateButton(final int btnIdx, final int modeNum, final int onLevel, final int offLevel, final int type, final long profileId) {
			ContentValues args = new ContentValues();
			args.put(KEY_BUTTON_INDEX, btnIdx);
			args.put(KEY_MODE_NUM, modeNum);
			args.put(KEY_ON_LEVEL, onLevel);
			args.put(KEY_OFF_LEVEL, offLevel);
			args.put(KEY_TYPE, type);
			args.put(KEY_PROFILE_ID, profileId);

			return db.update(DATABASE_TABLE, args, KEY_BUTTON_INDEX + "=" + btnIdx + " AND " + KEY_MODE_NUM + "=" + modeNum + " AND " + KEY_PROFILE_ID + "=" + profileId, null);
		}
	}

	public class PositionsTable {
		public static final String KEY_ROWID = "_id";
		public static final String KEY_RIGHT_JOY_X = "right_joy_x";
		public static final String KEY_RIGHT_JOY_Y = "right_joy_y";
		public static final String KEY_LEFT_JOY_X = "left_joy_x";
		public static final String KEY_LEFT_JOY_Y = "left_joy_y";
		public static final String KEY_PROFILE_ID = "profile_id";
		public static final String KEY_MODE_NUM = "mode_num";
		public static final String DATABASE_CREATE = "CREATE TABLE positions (" + "_id          integer PRIMARY KEY AUTOINCREMENT NOT NULL," + "right_joy_x  integer NOT NULL DEFAULT 0," + "left_joy_x   integer NOT NULL DEFAULT 0," + "left_joy_y   integer NOT NULL DEFAULT 0," + "right_joy_y  integer NOT NULL DEFAULT 0," + "profile_id   integer NOT NULL," + "  mode_num     integer NOT NULL" + ");";
		public static final String DATABASE_TABLE = "positions";

		public boolean createPositionsForProfile(long profileId) {
			boolean res = true;
			for (int i = 1; i <= 4; i++) {
				ContentValues args = new ContentValues();
				args.put(KEY_MODE_NUM, i);
				args.put(KEY_PROFILE_ID, profileId);
				long resId = db.insert(DATABASE_TABLE, null, args);

				if (resId < 0) {
					res = false;
				}
			}
			return res;
		}

		public boolean delPositionsByProfile(long profileId) {
			boolean res = db.delete(DATABASE_TABLE, KEY_PROFILE_ID + "=" + profileId, null) > 0;

			return res;
		}

		public Cursor fetchPositionRecord(final long profileId, final long modeNum) {
			Cursor cursor =

			db.query(true, DATABASE_TABLE, new String[] { KEY_ROWID, KEY_PROFILE_ID, KEY_MODE_NUM, KEY_RIGHT_JOY_X, KEY_RIGHT_JOY_Y, KEY_LEFT_JOY_X, KEY_LEFT_JOY_Y }, KEY_PROFILE_ID + "=" + profileId + " AND " + KEY_MODE_NUM + "=" + modeNum, null, null, null, null, null);
			if (cursor != null) {
				cursor.moveToFirst();
			}
			return cursor;
		}

		public long updatePositionRecord(final int modeNum, final long profileId, final int rightJoyX, final int rightJoyY, final int leftJoyX, final int leftJoyY) {
			ContentValues args = new ContentValues();
			args.put(KEY_MODE_NUM, modeNum);
			args.put(KEY_PROFILE_ID, profileId);
			args.put(KEY_RIGHT_JOY_X, rightJoyX);
			args.put(KEY_RIGHT_JOY_Y, rightJoyY);
			args.put(KEY_LEFT_JOY_X, leftJoyX);
			args.put(KEY_LEFT_JOY_Y, leftJoyY);

			return db.update(DATABASE_TABLE, args, KEY_MODE_NUM + "=" + modeNum + " AND " + KEY_PROFILE_ID + "=" + profileId, null);
		}
	}

	private static final String TAG = "WircDbAdapter";
	private static final String DATABASE_NAME = "wirc_db";
	private static final int DATABASE_VERSION = 3;
	private DatabaseHelper dbHelper;
	private SQLiteDatabase db;
	private ProfilesTable profilesTable;
	private ChannelsTable channelsTable;
	private DigitalChannelsTable digiChannelsTable;
	private ControlsTable controlsTable;
	private ManeuversTable maneuversTable;
	private ButtonsTable buttonsTable;
	private PositionsTable positionsTable;
	private static Context context;

	private static class DatabaseHelper extends SQLiteOpenHelper {

		DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(ProfilesTable.DATABASE_CREATE);
			db.execSQL(ProfilesTable.ROW1);
			db.execSQL(ProfilesTable.ROW2);
			db.execSQL(ChannelsTable.DATABASE_CREATE);
			db.execSQL(DigitalChannelsTable.DATABASE_CREATE);
			db.execSQL(ControlsTable.DATABASE_CREATE);
			db.execSQL(ManeuversTable.DATABASE_CREATE);
			db.execSQL(ButtonsTable.DATABASE_CREATE);
			db.execSQL(PositionsTable.DATABASE_CREATE);
			for (int i = 1; i <= 2; i++) {
				for (int j = 1; j <= ChannelInfo.CHANNELS; j++) {
					db.execSQL(GET_CH_SQL_STRING(j, i));
					for (int k = 1; k <= 4; k++) {
						db.execSQL(GET_CONTROL_SQL_STRING(j, i, k, false));
					}
					for (int l = 1; l <= 2; l++) {
						db.execSQL(GET_MANEUVER_SQL_STRING(j, i, l));
					}
				}
				for (int j = 1; j <= ChannelInfo.DIGITAL_CHANNELS; j++) {
					db.execSQL(GET_DIGI_CH_SQL_STRING(j, i));
					for (int k = 1; k <= 4; k++) {
						db.execSQL(GET_CONTROL_SQL_STRING(j, i, k, true));
					}
				}
				for (int j = 1; j <= 4; j++) {
					for (int k = 1; k <= 4; k++) {
						db.execSQL(GET_BUTTON_SQL_STRING(j, i, k));
					}
					db.execSQL(GET_POSITION_SQL_STRING(j, i));
				}
			}

			/*
			int chIdx = 1;
			int modeNum = 1;
			long profileId = 1;
			ChannelConfig channelConfig = new ChannelConfig();
			Cursor control = getControlsTable().fetchControl(chIdx, profileId, modeNum, false);
			getControlsTable().updateControl(1, modeNum, channelConfigs.get(i).getValue(), profileId, 0);
			*/
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to " + newVersion + ", which will destroy all old data");
			db.execSQL("DROP TABLE IF EXISTS profiles");
			onCreate(db);
		}
	}

	public static String GET_CONTROL_SQL_STRING(int chIdx, int profileId, int modeNum, boolean isDigital) {

		String[] configValues = context.getResources().getStringArray(R.array.a_Channels);
		String name = configValues[chIdx];
		if (isDigital)
			name = "Channel";
		if (isDigital || (chIdx > 2))
			name = name + " " + chIdx;

		return "INSERT INTO controls (channel_index, name, profile_id, source_num, mode_num, is_digital) VALUES (" + chIdx + ", '" + (isDigital ? "Digital " : "") + name
		// + chIdx
		+ "', " + profileId + ", " + ChannelSource.NO_SOURCE + ", " + modeNum + ", " + (isDigital ? 1 : 0) + ")";
	}

	public static String GET_CH_SQL_STRING(int chIdx, int profileId) {
		return "INSERT INTO channels (channel_index, name, profile_id) VALUES (" + chIdx + ", 'Channel " + chIdx + "', " + profileId + ")";
	}

	public static String GET_DIGI_CH_SQL_STRING(int chIdx, int profileId) {
		return "INSERT INTO digital_channels (channel_index, name, profile_id) VALUES (" + chIdx + ", 'Digital Channel " + chIdx + "', " + profileId + ")";
	}

	public static String GET_MANEUVER_SQL_STRING(int chIdx, int profileId, int manId) {
		return "INSERT INTO " + ManeuversTable.DATABASE_TABLE + " (" + ManeuversTable.KEY_CHANNEL_INDEX + ", " + ManeuversTable.KEY_PROFILE_ID + "," + ManeuversTable.KEY_MANEUVER_INDEX + " ) VALUES (" + chIdx + ", " + profileId + ", " + manId + ")";
	}

	public static String GET_BUTTON_SQL_STRING(int modeNum, int profileId, int btnIdx) {
		return "INSERT INTO " + ButtonsTable.DATABASE_TABLE + " (" + ButtonsTable.KEY_BUTTON_INDEX + ", " + ButtonsTable.KEY_PROFILE_ID + ", " + ButtonsTable.KEY_NAME + ", " + ButtonsTable.KEY_MODE_NUM + " ) VALUES (" + btnIdx + ", " + profileId + ", '" + NAMES[btnIdx - 1] + "', " + modeNum + ")";
	}

	public static String GET_POSITION_SQL_STRING(int modeNum, int profileId) {
		return "INSERT INTO " + PositionsTable.DATABASE_TABLE + " (" + ButtonsTable.KEY_PROFILE_ID + ", " + ButtonsTable.KEY_MODE_NUM + " ) VALUES (" + profileId + ", " + modeNum + ")";
	}

	public WircDbAdapter(Context ctx) {
		this.context = ctx;
	}

	public WircDbAdapter open() throws SQLException {
		dbHelper = new DatabaseHelper(context);
		db = dbHelper.getWritableDatabase();
		Notify.d(this, "open");

		return this;
	}

	public void close() {
		db.close();
		dbHelper.close();

		Notify.d(this, "close");
	}

	public Boolean isOpen() {
		Boolean open = false;
		if (db != null)
			open = db.isOpen();

		return open;
	}

	// getters and setters

	public ProfilesTable getProfilesTable() {
		if (profilesTable == null) {
			profilesTable = new ProfilesTable();
		}
		return profilesTable;
	}

	public ChannelsTable getChannelsTable() {
		if (channelsTable == null) {
			channelsTable = new ChannelsTable();
		}
		return channelsTable;
	}

	public DigitalChannelsTable getDigitalChannelsTable() {
		if (digiChannelsTable == null) {
			digiChannelsTable = new DigitalChannelsTable();
		}
		return digiChannelsTable;
	}

	public ControlsTable getControlsTable() {
		if (controlsTable == null) {
			controlsTable = new ControlsTable(db);
		}
		return controlsTable;
	}

	public ManeuversTable getManeuversTable() {
		if (maneuversTable == null) {
			maneuversTable = new ManeuversTable();
		}
		return maneuversTable;
	}

	public ButtonsTable getButtonsTable() {
		if (buttonsTable == null) {
			buttonsTable = new ButtonsTable();
		}
		return buttonsTable;
	}

	public PositionsTable getPositionsTable() {
		if (positionsTable == null) {
			positionsTable = new PositionsTable();
		}
		return positionsTable;
	}
}
