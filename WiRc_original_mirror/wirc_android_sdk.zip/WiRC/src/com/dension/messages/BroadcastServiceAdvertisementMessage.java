package com.dension.messages;

public class BroadcastServiceAdvertisementMessage extends Message{
	private byte l_u8_hw_ver_major;
	private byte l_u8_hw_ver_minor;
	private byte l_u8_sw_ver_major;
	private byte l_u8_sw_ver_minor;
	private String l_st_wrc_name;
	private String l_st_serial;
	
	public BroadcastServiceAdvertisementMessage(byte[] p_au8_raw, int p_length){
		super(MSG_CMD_BROADCAST_SERVICE_ADVERTISEMENT, MSG_LEN_BROADCAST_SERVICE_ADVERTISEMENT);
		rawPacket = p_au8_raw;
		rawDataLength = p_length;
		/* parse input stream to body and check CRC */
		parse();

		if(isValid) {
			assert(MSG_LEN_BROADCAST_SERVICE_ADVERTISEMENT == messageBody.length);
			int rawidx = 0;
			/* parse message body */
			l_u8_hw_ver_major = messageBody[rawidx++];
			l_u8_hw_ver_minor = messageBody[rawidx++];
			l_u8_sw_ver_major = messageBody[rawidx++];
			l_u8_sw_ver_minor = messageBody[rawidx++];
			byte[] st = new byte[MSG_MAX_NAME_LEN+1];
			int i;
			for(i = 0; i < MSG_MAX_NAME_LEN; ++i) {
				st[i] = messageBody[rawidx+i];
				if('\0' == st[i])
					break;
			}
			st[i] = '\0';
			l_st_wrc_name = new String(st, 0, i);
			rawidx += MSG_MAX_NAME_LEN;
			st = new byte[MSG_MAX_SERIAL_LEN+1];
			for(i = 0; i < MSG_MAX_SERIAL_LEN; ++i) {
				st[i] = messageBody[rawidx+i];
				if('\0' == st[i])
					break;
			}
			st[i] = '\0';
			l_st_serial = new String(st, 0, i);
			rawidx += MSG_MAX_SERIAL_LEN;
			assert(MSG_LEN_BROADCAST_SERVICE_ADVERTISEMENT == rawidx);
		}
	}
	
	public String getWRCName() {
		return l_st_wrc_name;
	}
	
	public String getSerial() {
		return l_st_serial;
	}
	
	public byte getHwMajor() {
		return l_u8_hw_ver_major;
	}
	
	public byte getHwMinor() {
		return l_u8_hw_ver_minor;
	}
	
	public byte getSwMajor() {
		return l_u8_sw_ver_major;
	}
	
	public byte getSwMinor() {
		return l_u8_sw_ver_minor;
	}
}
