package com.dension.messages;

public class BroadcastServiceDiscoveryMessage extends Message{
	private byte l_u8_sys;
	private byte l_u8_ver_major;
	private byte l_u8_ver_minor;
	
	
	public BroadcastServiceDiscoveryMessage(byte p_u8_sys, byte p_u8_ver_major, byte p_u8_ver_minor) {
		super(MSG_CMD_BROADCAST_SERVICE_DISCOVERY, MSG_LEN_BROADCAST_SERVICE_DISCOVERY);
		l_u8_sys = p_u8_sys;
		l_u8_ver_major = p_u8_ver_major;
		l_u8_ver_minor = p_u8_ver_minor;
		
		messageBody = new byte[] { 
			l_u8_sys, l_u8_ver_major, l_u8_ver_minor
		};
		assert(MSG_LEN_BROADCAST_SERVICE_DISCOVERY == messageBody.length);
		construct();
	}
}
