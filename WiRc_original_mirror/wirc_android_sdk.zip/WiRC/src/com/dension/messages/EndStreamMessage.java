package com.dension.messages;


public class EndStreamMessage extends Message {
	private byte l_u8_id;
	
	public EndStreamMessage(byte p_u8_id) {
		super(MSG_CMD_END_STREAM, MSG_LEN_END_STREAM);
		l_u8_id = p_u8_id;
		
		/* fill message body */
		messageBody = new byte[MSG_LEN_END_STREAM];
		int rawidx = 0;
		messageBody[rawidx++] = l_u8_id;
		assert(MSG_LEN_END_STREAM == rawidx);
		construct();
	}
}
