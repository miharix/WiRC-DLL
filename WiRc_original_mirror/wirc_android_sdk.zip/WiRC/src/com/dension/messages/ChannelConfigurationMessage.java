package com.dension.messages;

public class ChannelConfigurationMessage extends Message {
	private short l_au16_ch_t[];
	private static final short DEFAULT_FQ = 20000;

	public ChannelConfigurationMessage() {
		super(MSG_CMD_CHANNEL_CONFIG, MSG_LEN_CHANNEL_CONFIG);
		l_au16_ch_t = new short[MSG_NUM_CH];
	}

	public void assemble() {
		/* create message body */
		messageBody = new byte[MSG_LEN_CHANNEL_CONFIG];
		int rawidx = 0;
		for (int i = 0; i < MSG_NUM_CH; ++i) {
			if (l_au16_ch_t[i] == 0) {
				l_au16_ch_t[i] = DEFAULT_FQ;
			}
			messageBody[rawidx++] = (byte) (l_au16_ch_t[i] >> 8);
			messageBody[rawidx++] = (byte) (l_au16_ch_t[i] & (byte) 0xFF);
		}
		assert (MSG_LEN_CHANNEL_CONFIG == rawidx);
		construct();
	}

	public void putValue(short idx, short value) {
		l_au16_ch_t[idx] = value;
	}
}
