package com.dension.messages;

public class PeriodicalChannelDataMessage extends Message {
	private short data[];

	public PeriodicalChannelDataMessage(short valuesArray[]) {
		super(MSG_CMD_PERIODICAL_CHANNEL_DATA, MSG_LEN_PERIODICAL_CHANNEL_DATA);
		setValues(valuesArray);
	}

	public void setValues(short valuesArray[]) {
		data = valuesArray;

		messageBody = new byte[MSG_LEN_PERIODICAL_CHANNEL_DATA];
		int rawidx = 0;
		StringBuilder log = new StringBuilder();
		log.append("|" + System.currentTimeMillis() + "|");
		for (int i = 0; i < data.length; ++i) {
			log.append((i + 1) + "/" + data[i] + "|");
			messageBody[rawidx++] = (byte) (data[i] >> 8);
			messageBody[rawidx++] = (byte) (data[i] & (byte) 0xFF);
		}
		construct();
	}
}
