package com.dension.messages;

public class TransmitterLoginMessage extends Message {
	private byte system;
	private byte majorVersion;
	private byte minorVersion;
	private byte transmitterPriority;
	private String transmitterName;
	private short port;

	public TransmitterLoginMessage(byte system, byte majorVersion,
			byte minorVersion, byte transmitterPriority,
			String transmitterName, short port) {
		super(MSG_CMD_TRANSMITTER_LOGIN, TRANSMITTER_LOGIN_MSG_LENGTH);
		this.system = system;
		this.majorVersion = majorVersion;
		this.minorVersion = minorVersion;
		this.transmitterPriority = transmitterPriority;
		this.transmitterName = transmitterName;
		this.port = port;

		messageBody = new byte[TRANSMITTER_LOGIN_MSG_LENGTH];
		int rawidx = 0;
		messageBody[rawidx++] = this.system;
		messageBody[rawidx++] = this.majorVersion;
		messageBody[rawidx++] = this.minorVersion;
		messageBody[rawidx++] = this.transmitterPriority;
		for (int i = 0; i < MSG_MAX_NAME_LEN; ++i) {
			byte rawname[] = this.transmitterName.getBytes();
			if (i < rawname.length)
				messageBody[rawidx++] = rawname[i];
			else
				messageBody[rawidx++] = '\0';
		}
		messageBody[rawidx++] = (byte) (this.port >> 8);
		messageBody[rawidx++] = (byte) (this.port & (byte) 0xFF);

		assert (TRANSMITTER_LOGIN_MSG_LENGTH == rawidx);
		construct();
	}
}