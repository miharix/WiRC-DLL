package com.dension.messages;


public class WRCDStartupMessage extends Message {
	private int l_u8_id;
	private int l_u8_cn;
	private int l_u16_pcd_port;
	
	public WRCDStartupMessage(byte[] p_au8_raw, int p_length) {
		super(MSG_CMD_WRCD_STARTUP, MSG_LEN_WRCD_STARTUP);
		rawPacket = p_au8_raw;
		rawDataLength = p_length;
		/* parse input stream */
		parse();
		if(isValid) {
			assert(MSG_LEN_WRCD_STARTUP == messageBody.length);
			int rawidx = 0;
			l_u8_id = messageBody[rawidx++];
			l_u8_cn = messageBody[rawidx++];
			short u16_port;
			u16_port = (short)(messageBody[rawidx++] << 8);
			u16_port |= (short)(messageBody[rawidx++] & (short)0x00FF);
			l_u16_pcd_port = (u16_port & 0xFFFF);
			assert(MSG_LEN_WRCD_STARTUP == rawidx);
		}
	}
	
	public int getId() {
		return l_u8_id;
	}
	
	public int getCameraNum() {
		return l_u8_cn;
	}
	
	public int getPCDPort() {
		return l_u16_pcd_port;
	}
}
