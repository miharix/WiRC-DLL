package com.dension.messages;

public class DeviceConfigurationMessage extends Message {
	String l_st_wrc_name;
	short l_u16_cam_off;
	short l_u16_wrc_off;
	
	public DeviceConfigurationMessage(String p_st_name, short p_u16_cam_off, short p_u16_wrc_off) {
		super(MSG_CMD_DEVICE_CONFIG, MSG_LEN_DEVICE_CONFIG);
		l_st_wrc_name = p_st_name;
		l_u16_cam_off = p_u16_cam_off;
		l_u16_wrc_off = p_u16_wrc_off;
		
		messageBody = new byte[MSG_LEN_DEVICE_CONFIG];
		int rawidx = 0;
		/* store WRC name */
		for(int i = 0; i < MSG_MAX_NAME_LEN; ++i) {
			byte rawname[] = l_st_wrc_name.getBytes();
			if(i < rawname.length)
				messageBody[rawidx++] = rawname[i];
			else
				messageBody[rawidx++] = '\0';
		}
		/* store camera switch off voltage */
		messageBody[rawidx++] = (byte)(l_u16_cam_off >> 8);
		messageBody[rawidx++] = (byte)(l_u16_cam_off & (byte)0xFF);
		/* store WRC switch off voltage */
		messageBody[rawidx++] = (byte)(l_u16_wrc_off >> 8);
		messageBody[rawidx++] = (byte)(l_u16_wrc_off & (byte)0xFF);
		
		assert(MSG_LEN_DEVICE_CONFIG == rawidx);
		construct();
	}
}
