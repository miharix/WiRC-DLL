package com.dension.messages;

import java.io.IOException;
import java.io.InputStream;


/** Super Class of Messages */
public class Message {
	/* public constants */
	public static final int MSG_MAX_RAW_LEN = 256+6;
	/* system type and version info */
	public static final byte MSG_SYS_ANDROID = (byte)0x02;
	public static final byte MSG_VERSION_MAJOR = 0;
	public static final byte MSG_VERSION_MINOR = 1;
	
	/* message types */
	public static final byte MSG_CMD_BROADCAST_SERVICE_DISCOVERY = (byte)0x01;
	public static final byte MSG_CMD_BROADCAST_SERVICE_ADVERTISEMENT = (byte)0x02;
	public static final byte MSG_CMD_TRANSMITTER_LOGIN   = (byte)0x11;
	public static final byte MSG_CMD_DEVICE_CONFIG = (byte)0x12;	
	public static final byte MSG_CMD_CHANNEL_CONFIG = (byte)0x13;
	public static final byte MSG_CMD_FAILSAFE_CONFIG = (byte)0x14;
	public static final byte MSG_CMD_WRCD_STARTUP  = (byte)0x1A;
	public static final byte MSG_CMD_PERIODICAL_CHANNEL_DATA  = (byte)0x21;
	public static final byte MSG_CMD_PERIODICAL_STATUS_DATA  = (byte)0x22;
	public static final byte MSG_CMD_WIFI_CONFIG = (byte)0x31;
	public static final byte MSG_CMD_TRANSMITTER_LIST_REQ  = (byte)0x32;
	public static final byte MSG_CMD_TRANSMITTER_LIST = (byte)0x33;
	public static final byte MSG_CMD_TRANSMITTER_LIST_END = (byte)0x34;
	public static final byte MSG_CMD_ACCESS_REQ = (byte)0x35;
	public static final byte MSG_CMD_ACCESS_GRANTED  = (byte)0x36;
	public static final byte MSG_CMD_FIRMWARE_UPDATE = (byte)0x37;
	public static final byte MSG_CMD_START_STREAM = (byte)0x41;
	public static final byte MSG_CMD_END_STREAM  = (byte)0x42;
	public static final byte MSG_CMD_ERR  = (byte)0xFF;
	
	/* message length */
	public static final byte MSG_LEN_BROADCAST_SERVICE_DISCOVERY = (byte)0x03;
	public static final byte MSG_LEN_BROADCAST_SERVICE_ADVERTISEMENT = (byte)0x4B;
	public static final byte TRANSMITTER_LOGIN_MSG_LENGTH   = (byte)0x46;
	public static final byte MSG_LEN_DEVICE_CONFIG = (byte)0x44;
	public static final byte MSG_LEN_CHANNEL_CONFIG = (byte)0x18;
	public static final byte MSG_LEN_FAILSAFE_CONFIG = (byte)0x18;
	public static final byte MSG_LEN_WRCD_STARTUP  = (byte)0x04;
	public static final byte MSG_LEN_PERIODICAL_CHANNEL_DATA  = (byte)0x18;
	public static final byte MSG_LEN_PERIODICAL_STATUS_DATA  = (byte)0x08;
	public static final byte MSG_LEN_WIFI_CONFIG = (byte)0x66;
	public static final byte MSG_LEN_TRANSMITTER_LIST_REQ  = (byte)0x00;
	public static final byte MSG_LEN_TRANSMITTER_LIST = (byte)0x42;
	public static final byte MSG_LEN_TRANSMITTER_LIST_END = (byte)0x00;
	public static final byte MSG_LEN_ACCESS_REQ = (byte)0x01;
	public static final byte MSG_LEN_ACCESS_GRANTED  = (byte)0x43;
	public static final byte MSG_LEN_FIRMWARE_UPDATE = (byte)0x10;
	public static final byte MSG_LEN_START_STREAM = (byte)0x03;
	public static final byte MSG_LEN_END_STREAM  = (byte)0x01;
	public static final byte MSG_LEN_ERR  = (byte)0x03;
	
	/* number of control channel */
	public static final int MSG_NUM_CH	= 12;
	/* number of input channels */
	public static final int MSG_NUM_INPUT = 4;
	/* number of measured battery values */
	public static final int MSG_NUM_BATT = 2;
	
	/* message field length */
	public static final int MSG_MAX_NAME_LEN = 64;
	public static final int MSG_MAX_SERIAL_LEN = 7;
	public static final int MSG_MAX_SSID_LEN = 32;
	public static final int MSG_MAX_PASS_LEN = 64;
	public static final int MSG_MAX_CCODE_LEN = 3;
	public static final int MSG_MAX_MD5_LEN = 16;
	
	/* access granted (AGR) notification types */
	/* access granted to the current transmitter */
	public static final byte MSG_NOTIF_GRANTED 	= (byte)0x00;
	/* access denied to the current transmitter - reply for request */
	public static final byte MSG_NOTIF_DENIED 	= (byte)0x01;
	/* current transmitter has lost its access control right */
	public static final byte MSG_NOTIF_LOST 		= (byte)0x02;
	/* access granted notification message to everybody r */
	public static final byte MSG_NOTIF_NOTE 		= (byte)0x03;
	
	/* internal constants */
	private static final byte FRAME_START1 = (byte)0xAA;
	private static final byte FRAME_START2 = (byte)0xBB;
	
	/* global data */
	public boolean isValid;
	public int rawIdx;
	
	/* internal globals */
	protected byte[] frame;	/**< frame start indicator bytes */
	protected byte commandCode;		/**< command code - message type */
	protected int messageBodyLength;			/**< length of the message body */
	protected short crc;		/**< CRC of the cmd, len and the message body */
	protected byte[] messageBody;	/**< message body */
	protected byte[] rawPacket;		/**< packet in raw format */
	protected int rawDataLength;		/**< raw format data length */
	
	public Message(byte commandCode, byte messageBodyLength) {
		frame = new byte[] { FRAME_START1, FRAME_START2};
		this.commandCode = commandCode;
		this.messageBodyLength = messageBodyLength;
		isValid = false;
		rawDataLength = 0;
		messageBody = null;
		rawPacket = null;
	}
	
	public byte[] getRaw() {
		return rawPacket;
	}
	
	/* construct raw message and calculate CRC */
	protected void construct() {
		/* calculate CRC */
		crc = calcCRC();
		
		/* create raw packet */
		int rawlength = getRawLength(); 
		if(null == rawPacket)
			rawPacket = new byte[rawlength];
		int rawIndex = 0;
		/* raw header */
		rawPacket[rawIndex++] = frame[0];
		rawPacket[rawIndex++] = frame[1];
		rawPacket[rawIndex++] = commandCode;
		rawPacket[rawIndex++] = (byte)messageBodyLength;
		/* raw body */
		for(int i = 0; i < messageBody.length; ++i) {
			assert(rawIndex < rawlength);
			rawPacket[rawIndex++] = messageBody[i];
		}
		assert(rawIndex+2 == rawlength);
		/* raw CRC */
		rawPacket[rawIndex++] = (byte)(crc >> 8);
		rawPacket[rawIndex++] = (byte)(crc & (byte)0xFF);
	}
	
	/* parse the raw message and check CRC */
	protected void parse() {
		isValid = false;
		int rawIndex = 0;
		
		if(rawDataLength < 6)	// too short
			return;
		
		/* parse header */
		frame[0] = rawPacket[rawIndex++];
		frame[1] = rawPacket[rawIndex++];
		commandCode = rawPacket[rawIndex++];
		messageBodyLength = rawPacket[rawIndex++];
		
		/* check length */
		if(getRawLength() != rawDataLength)
			return;
		
		messageBody = new byte[messageBodyLength];
		/* copy message body */
		for(int i =0; i < messageBodyLength; ++i) {
			messageBody[i] = rawPacket[rawIndex++];
		}
		
		assert(rawIndex+2 == rawDataLength);
		/* parse CRC */
		crc = (short)(rawPacket[rawIndex] << 8);
		crc |= (short)(rawPacket[rawIndex+1] & 0xFF);
		
		/* check CRC */
		short u16_crc = calcCRC();
		if(u16_crc != crc)
			return;
		
		/* valid message */
		isValid = true;
	}
	
	/* get size of the raw packet in bytes */
	public int getRawLength() {
		return messageBodyLength + 6;
	}
	/* calculate CRC-CCITT value */
	private short calcCRC_CCITT(short p_u16_init, byte p_u8_byte) {
		short u16_crc;
		int index;
		
		index = (((byte)(p_u16_init >> 8))^p_u8_byte);
		if(index < 0)
			index += 256;
		u16_crc = (short)(ccittCrcTable[index]^(p_u16_init << 8));
		return u16_crc;
	}
	private short calcCRC() {
		short crc = 0;
		crc = calcCRC_CCITT(crc, commandCode);
		crc = calcCRC_CCITT(crc, (byte)messageBodyLength);
		for(int i = 0; i < messageBodyLength; ++i)
			crc = calcCRC_CCITT(crc, messageBody[i]);
		return crc;
	}
	
    private static final short ccittCrcTable[] = {
        (short)0x0000, (short)0x1021, (short)0x2042, (short)0x3063, (short)0x4084, (short)0x50a5, (short)0x60c6, (short)0x70e7,
        (short)0x8108, (short)0x9129, (short)0xa14a, (short)0xb16b, (short)0xc18c, (short)0xd1ad, (short)0xe1ce, (short)0xf1ef,
        (short)0x1231, (short)0x0210, (short)0x3273, (short)0x2252, (short)0x52b5, (short)0x4294, (short)0x72f7, (short)0x62d6,
        (short)0x9339, (short)0x8318, (short)0xb37b, (short)0xa35a, (short)0xd3bd, (short)0xc39c, (short)0xf3ff, (short)0xe3de,
        (short)0x2462, (short)0x3443, (short)0x0420, (short)0x1401, (short)0x64e6, (short)0x74c7, (short)0x44a4, (short)0x5485,
        (short)0xa56a, (short)0xb54b, (short)0x8528, (short)0x9509, (short)0xe5ee, (short)0xf5cf, (short)0xc5ac, (short)0xd58d,
        (short)0x3653, (short)0x2672, (short)0x1611, (short)0x0630, (short)0x76d7, (short)0x66f6, (short)0x5695, (short)0x46b4,
        (short)0xb75b, (short)0xa77a, (short)0x9719, (short)0x8738, (short)0xf7df, (short)0xe7fe, (short)0xd79d, (short)0xc7bc,
        (short)0x48c4, (short)0x58e5, (short)0x6886, (short)0x78a7, (short)0x0840, (short)0x1861, (short)0x2802, (short)0x3823,
        (short)0xc9cc, (short)0xd9ed, (short)0xe98e, (short)0xf9af, (short)0x8948, (short)0x9969, (short)0xa90a, (short)0xb92b,
        (short)0x5af5, (short)0x4ad4, (short)0x7ab7, (short)0x6a96, (short)0x1a71, (short)0x0a50, (short)0x3a33, (short)0x2a12,
        (short)0xdbfd, (short)0xcbdc, (short)0xfbbf, (short)0xeb9e, (short)0x9b79, (short)0x8b58, (short)0xbb3b, (short)0xab1a,
        (short)0x6ca6, (short)0x7c87, (short)0x4ce4, (short)0x5cc5, (short)0x2c22, (short)0x3c03, (short)0x0c60, (short)0x1c41,
        (short)0xedae, (short)0xfd8f, (short)0xcdec, (short)0xddcd, (short)0xad2a, (short)0xbd0b, (short)0x8d68, (short)0x9d49,
        (short)0x7e97, (short)0x6eb6, (short)0x5ed5, (short)0x4ef4, (short)0x3e13, (short)0x2e32, (short)0x1e51, (short)0x0e70,
        (short)0xff9f, (short)0xefbe, (short)0xdfdd, (short)0xcffc, (short)0xbf1b, (short)0xaf3a, (short)0x9f59, (short)0x8f78,
        (short)0x9188, (short)0x81a9, (short)0xb1ca, (short)0xa1eb, (short)0xd10c, (short)0xc12d, (short)0xf14e, (short)0xe16f,
        (short)0x1080, (short)0x00a1, (short)0x30c2, (short)0x20e3, (short)0x5004, (short)0x4025, (short)0x7046, (short)0x6067,
        (short)0x83b9, (short)0x9398, (short)0xa3fb, (short)0xb3da, (short)0xc33d, (short)0xd31c, (short)0xe37f, (short)0xf35e,
        (short)0x02b1, (short)0x1290, (short)0x22f3, (short)0x32d2, (short)0x4235, (short)0x5214, (short)0x6277, (short)0x7256,
        (short)0xb5ea, (short)0xa5cb, (short)0x95a8, (short)0x8589, (short)0xf56e, (short)0xe54f, (short)0xd52c, (short)0xc50d,
        (short)0x34e2, (short)0x24c3, (short)0x14a0, (short)0x0481, (short)0x7466, (short)0x6447, (short)0x5424, (short)0x4405,
        (short)0xa7db, (short)0xb7fa, (short)0x8799, (short)0x97b8, (short)0xe75f, (short)0xf77e, (short)0xc71d, (short)0xd73c,
        (short)0x26d3, (short)0x36f2, (short)0x0691, (short)0x16b0, (short)0x6657, (short)0x7676, (short)0x4615, (short)0x5634,
        (short)0xd94c, (short)0xc96d, (short)0xf90e, (short)0xe92f, (short)0x99c8, (short)0x89e9, (short)0xb98a, (short)0xa9ab,
        (short)0x5844, (short)0x4865, (short)0x7806, (short)0x6827, (short)0x18c0, (short)0x08e1, (short)0x3882, (short)0x28a3,
        (short)0xcb7d, (short)0xdb5c, (short)0xeb3f, (short)0xfb1e, (short)0x8bf9, (short)0x9bd8, (short)0xabbb, (short)0xbb9a,
        (short)0x4a75, (short)0x5a54, (short)0x6a37, (short)0x7a16, (short)0x0af1, (short)0x1ad0, (short)0x2ab3, (short)0x3a92,
        (short)0xfd2e, (short)0xed0f, (short)0xdd6c, (short)0xcd4d, (short)0xbdaa, (short)0xad8b, (short)0x9de8, (short)0x8dc9,
        (short)0x7c26, (short)0x6c07, (short)0x5c64, (short)0x4c45, (short)0x3ca2, (short)0x2c83, (short)0x1ce0, (short)0x0cc1,
        (short)0xef1f, (short)0xff3e, (short)0xcf5d, (short)0xdf7c, (short)0xaf9b, (short)0xbfba, (short)0x8fd9, (short)0x9ff8,
        (short)0x6e17, (short)0x7e36, (short)0x4e55, (short)0x5e74, (short)0x2e93, (short)0x3eb2, (short)0x0ed1, (short)0x1ef0
    };
    
    public static Message receive(InputStream input) throws IOException {
    	byte start1 = 0;
    	byte start2 = 0;
    	int commandCode = 0;
    	int length = 0;
    	int result;
    	
    	/* read frame start bytes */
    	start1 = (byte)input.read();
    	start2 = (byte)input.read();
    	while((FRAME_START1 != start1) ||
    		  (FRAME_START2 != start2)) {
    		start1 = start2;
    		start2 = (byte)input.read();
    	}
    	/* read command code */
    	commandCode = input.read();
    	/* read length */
    	length = input.read();
    	/* read message body */
    	byte rawBuffer[] = new byte[length+6];
    	rawBuffer[0] = start1;
    	rawBuffer[1] = start2;
    	rawBuffer[2] = (byte) commandCode;
    	rawBuffer[3] = (byte) length;
    	result = input.read(rawBuffer, 4, length+2);
    	if(result != length + 2) {
    		throw new IOException(String.format("read %d instead of %d", result, length+2));
    	}
    	/* chose message type */
    	switch(commandCode) {
    	case MSG_CMD_WRCD_STARTUP:
    		WRCDStartupMessage wst = new WRCDStartupMessage(rawBuffer, rawBuffer.length);
    		return wst;
    	case MSG_CMD_ACCESS_GRANTED:
    		AccessGrantedMessage agr = new AccessGrantedMessage(rawBuffer, rawBuffer.length);
    		return agr;
    	}
    	
    	return null;
    }
    /* read command code */
    public byte getCmd() {
    	return commandCode;
    }
    
    public void stringToMessageBody(String str, int msgLenght) {
    	for(int i = 0; i < msgLenght; ++i) {
			byte rawname[] = str.getBytes();
			if( i < rawname.length )
				messageBody[rawIdx++] = rawname[i];
			else
				messageBody[rawIdx++] = '\0';
		}
    }
}

