package com.dension.messages;

import java.util.HashMap;

public class FirmwareUpgradeMessage extends Message {
	
	HashMap<String, Integer> hashMap;
	
	public FirmwareUpgradeMessage(String firmware_md5) {
		super(MSG_CMD_FIRMWARE_UPDATE, MSG_LEN_FIRMWARE_UPDATE);
		
		/*
		hashMap = new HashMap<String, Integer>();
		hashMap.put("0", 0);
		hashMap.put("1", 1);
		hashMap.put("2", 2);
		hashMap.put("3", 3);
		hashMap.put("4", 4);
		*/
		
		byte[] md5 = fromHexString(firmware_md5);
		messageBody = new byte[MSG_LEN_FIRMWARE_UPDATE];
		int rawidx = 16;
		messageBody = md5;

		// this.rawIdx = 0;
		// this.stringToMessageBody(firmware_md5, MSG_LEN_FIRMWARE_UPDATE);
		assert(MSG_LEN_FIRMWARE_UPDATE == rawidx);
		construct();
	}
	
	private static byte[] fromHexString(final String encoded) {
	    final byte result[] = new byte[encoded.length()/2];
	    final char enc[] = encoded.toCharArray();
	    for (int i = 0; i < enc.length; i += 2) {
	        StringBuilder curr = new StringBuilder(2);
	        curr.append(enc[i]).append(enc[i + 1]);
	        result[i/2] = (byte) Integer.parseInt(curr.toString(), 16);
	    }
	    return result;
	}


}
