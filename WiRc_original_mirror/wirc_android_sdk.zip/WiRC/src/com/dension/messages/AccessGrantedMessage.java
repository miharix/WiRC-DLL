package com.dension.messages;

public class AccessGrantedMessage extends Message {
	private byte l_u8_id;
	private byte l_u8_prio;
	private String l_st_tr_name;
	private byte l_u8_notif;
	
	public AccessGrantedMessage(byte[] p_au8_raw, int p_length) {
		super(MSG_CMD_ACCESS_GRANTED, MSG_LEN_ACCESS_GRANTED);
		rawPacket = p_au8_raw;
		rawDataLength = p_length;
		/* parse input stream */
		parse();
		if(isValid) {
			assert(MSG_LEN_ACCESS_GRANTED == messageBody.length);
			int rawidx = 0;
			l_u8_id = messageBody[rawidx++];
			l_u8_prio = messageBody[rawidx++];
			byte[] st = new byte[MSG_MAX_NAME_LEN+1];
			int i;
			for(i = 0; i < MSG_MAX_NAME_LEN; ++i) {
				st[i] = messageBody[rawidx+i];
				if('\0' == st[i])
					break;
			}
			st[i] = '\0';
			l_st_tr_name = new String(st, 0, i);
			rawidx += MSG_MAX_NAME_LEN;
			l_u8_notif = messageBody[rawidx++];
			assert(MSG_LEN_ACCESS_GRANTED == rawidx);
		}
	}
	
	public byte getId() {
		return l_u8_id;
	}
	
	public byte getPrio() {
		return l_u8_prio;
	}
	
	public String getTrName() {
		return l_st_tr_name;
	}
	
	public byte getNotif() {
		return l_u8_notif;
	}

}
