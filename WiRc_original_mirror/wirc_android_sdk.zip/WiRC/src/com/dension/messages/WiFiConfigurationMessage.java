package com.dension.messages;

public class WiFiConfigurationMessage extends Message {

	public WiFiConfigurationMessage(String ssid, String passw, byte ap, byte sec, byte ch, String country) {
		super(MSG_CMD_WIFI_CONFIG, MSG_LEN_WIFI_CONFIG);
		
		messageBody = new byte[MSG_LEN_WIFI_CONFIG];
		this.rawIdx = 0;
		
		stringToMessageBody(ssid, 32);
		stringToMessageBody(passw, 64);
		messageBody[rawIdx++] = ap;
		messageBody[rawIdx++] = sec;
		messageBody[rawIdx++] = ch;
		stringToMessageBody(country, 3);
		
		assert(MSG_LEN_WIFI_CONFIG == rawIdx);
		construct();
	}

}
