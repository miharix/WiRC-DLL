package com.dension.messages;

public class FailsafeConfigurationMessage extends Message {
	private short l_au16_ch_v[];
	private static final short DEFAULT_FAILSAFE = 1500;

	public FailsafeConfigurationMessage() {
		super(MSG_CMD_FAILSAFE_CONFIG, MSG_LEN_FAILSAFE_CONFIG);
		l_au16_ch_v = new short[MSG_NUM_CH];
	}

	public void assemble() {
		/* create message body */
		messageBody = new byte[MSG_LEN_FAILSAFE_CONFIG];
		int rawidx = 0;
		for (int i = 0; i < MSG_NUM_CH; ++i) {
			if (l_au16_ch_v[i] == 0) {
				l_au16_ch_v[i] = DEFAULT_FAILSAFE;
			}
			messageBody[rawidx++] = (byte) (l_au16_ch_v[i] >> 8);
			messageBody[rawidx++] = (byte) (l_au16_ch_v[i] & (byte) 0xFF);
		}
		assert (MSG_LEN_FAILSAFE_CONFIG == rawidx);
		construct();
	}

	public void putValue(short idx, short value) {
		l_au16_ch_v[idx] = value;
	}
}
