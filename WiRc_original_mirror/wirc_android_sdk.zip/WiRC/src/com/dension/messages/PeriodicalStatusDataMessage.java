package com.dension.messages;

public class PeriodicalStatusDataMessage extends Message {
	private short l_au16_batt[];
	private byte l_au8_input[];
	
	public PeriodicalStatusDataMessage(byte[] p_au8_raw, int p_length) {
		super(MSG_CMD_PERIODICAL_STATUS_DATA, MSG_LEN_PERIODICAL_STATUS_DATA);
		rawPacket = p_au8_raw;
		rawDataLength = p_length;
		/* parse input stream to body and check CRC */
		parse();
		if(isValid) {
			assert(MSG_LEN_BROADCAST_SERVICE_ADVERTISEMENT == messageBody.length);
			int rawidx = 0;
			/* parse message body */
			int i;
			/* parse battery values */
			l_au16_batt = new short[MSG_NUM_BATT];
			for(i = 0; i < MSG_NUM_BATT; ++i) {
				l_au16_batt[i] = (short)(messageBody[rawidx++] << 8);
				l_au16_batt[i] |= (short)(messageBody[rawidx++] & 0xFF);
			}
			/* parse input values */
			l_au8_input = new byte[MSG_NUM_INPUT];
			for(i = 0; i < MSG_NUM_INPUT; ++i) {
				l_au8_input[i] = messageBody[rawidx++];
			}
			assert(MSG_LEN_PERIODICAL_STATUS_DATA == rawidx);
		}
	}

	public short getBattery(int p_idx) {
		if((p_idx >= 0) && (p_idx < l_au16_batt.length)) {
			return l_au16_batt[p_idx];
		} else {
			return 0;
		}
	}
	
	public short getInput(int p_idx) {
		if((p_idx >= 0) && (p_idx < l_au8_input.length)) {
			return l_au8_input[p_idx];
		} else {
			return 0;
		}
	}
}
