package com.dension.messages;

public class StartStreamMessage extends Message {
	private byte l_u8_id;
	@SuppressWarnings("unused")
	private short l_u16_port;
	
	public StartStreamMessage(byte p_u8_id, short p_u16_port) {
		super(MSG_CMD_START_STREAM, MSG_LEN_START_STREAM);
		l_u8_id = p_u8_id;
		l_u16_port = p_u16_port;
		
		/* fill message body */
		messageBody = new byte[MSG_LEN_START_STREAM];
		int rawidx = 0;
		messageBody[rawidx++] = l_u8_id;
		messageBody[rawidx++] = (byte)(p_u16_port >> 8);
		messageBody[rawidx++] = (byte)(p_u16_port & (byte)0xFF);
		assert(MSG_LEN_START_STREAM == rawidx);
		construct();
	}
}
