package com.dension.wra;

import java.util.ArrayList;

import over.TimerService;
import settings.ChannelConfig;
import wirc.dension.com.R;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import channel.ChannelInfo;

import com.dension.sqliteaccess.ControlsTable;
import com.dension.sqliteaccess.WircDbAdapter;

public class ControlSettingsActivity extends ListActivity {
	public static final String KEY_BUNDLE_MODE_INDEX = "bundle_mode_index";
	public static final String KEY_CTRL_HOLD_RIGHTX = "control_hold_right_x";
	public static final String KEY_CTRL_HOLD_RIGHTY = "control_hold_right_y";
	public static final String KEY_CTRL_HOLD_LEFTX = "control_hold_left_x";
	public static final String KEY_CTRL_HOLD_LEFTY = "control_hold_left_y";

	/*
	private static final int L_DEFAULT_CHANNEL = 0;
	private static final int L_DEFAULT_OFF_LEVEL = 1500;
	private static final int L_DEFAULT_ON_LEVEL = 2000;
	*/

	private static final String[] configValues = new String[] { "None",
			"Right Joystick X", "Right Joystick Y", "Left Joystick X",
			"Left Joystick Y", "Gyro X", "Gyro Z", "Button A", "Button B",
			"Button C", "Button D", };

	private static final String[] buttonTypes = new String[] { "Trigger",
			"Toggle", };

	private ChannelConfig[] channelCfg;
	private ArrayList<ChannelConfig> channelConfigs;
	private ChannelConfigAdatper mAdapter;
	private boolean[] isHoldPosition;
	private int mIndex;
	private Spinner mSpinnerBtnType;
	private SliderView mSliderBtnOn;
	private SliderView mSliderBtnOff;

	private int modeNum;
	// private WircDbAdapter dbHelper;
	private long profileId;

	private class ChannelConfigAdatper extends ArrayAdapter<ChannelConfig> {
		private ArrayList<ChannelConfig> mItems;

		public ChannelConfigAdatper(Context context, int textViewResourceId,
				ArrayList<ChannelConfig> items) {
			super(context, textViewResourceId, items);

			mItems = items;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View v = convertView;
			if (null == v) {
				LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				try {
					v = vi.inflate(R.layout.control_config_row, null);
				} catch (Exception e) {
					DisplayToast(e.toString());
				}
			}
			ChannelConfig cfg = mItems.get(position);
			if (null != cfg) {
				TextView textName = (TextView) v.findViewById(R.id.textName);
				TextView textValue = (TextView) v.findViewById(R.id.textValue);
				if (null != textName) {
					textName.setText(cfg.getChannelName());
					textValue.setText(cfg.getValueName());
				}
			}
			return v;
		}
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		profileId = TimerService.dbHelper.getProfilesTable().getActiveProfileId();

		channelCfg = new ChannelConfig[12];
		isHoldPosition = new boolean[4];

		Bundle bundle = this.getIntent().getExtras();
		modeNum = bundle.getInt(KEY_BUNDLE_MODE_INDEX);
		if (modeNum < 1)
			modeNum = 1;
		if (modeNum > 4)
			modeNum = 4;

		setTitle(String.format("Mode %d Control Settings", modeNum));
		channelConfigs = new ArrayList<ChannelConfig>();

		int[] cfgs = new int[channelCfg.length];
		for (int i = 0; i < ChannelInfo.CHANNELS; ++i) {
			Cursor control = TimerService.dbHelper.getControlsTable().fetchControl(i + 1,
					profileId, modeNum, false);
			cfgs[i] = control
					.getInt(control
							.getColumnIndexOrThrow(ControlsTable.KEY_SOURCE_NUM));
			channelConfigs
					.add(new ChannelConfig(
							control.getString(control
									.getColumnIndexOrThrow(ControlsTable.KEY_NAME)),
							cfgs[i]));
		}
		for (int i = 0; i < ChannelInfo.DIGITAL_CHANNELS; ++i) {
			Cursor control = TimerService.dbHelper.getControlsTable().fetchControl(i + 1,
					profileId, modeNum, true);
			cfgs[ChannelInfo.CHANNELS + i] = control
					.getInt(control
							.getColumnIndexOrThrow(ControlsTable.KEY_SOURCE_NUM));
			channelConfigs
					.add(new ChannelConfig(
							control.getString(control
									.getColumnIndexOrThrow(ControlsTable.KEY_NAME)),
							cfgs[ChannelInfo.CHANNELS + i]));
		}

		channelConfigs.add(new ChannelConfig("Hold Position", -1));
		channelConfigs.add(new ChannelConfig("Button A", -1));
		channelConfigs.add(new ChannelConfig("Button B", -1));
		channelConfigs.add(new ChannelConfig("Button C", -1));
		channelConfigs.add(new ChannelConfig("Button D", -1));

		mAdapter = new ChannelConfigAdatper(this, R.layout.control_config_row,
				channelConfigs);
		setListAdapter(mAdapter);
		getListView().setOnItemClickListener(itemClickListener);
	}

	@Override
	public void onStop() {
		super.onStop();

		// save to db
		saveSettings();
	}

	private void saveSettings() {
		for (int i = 0; i < ChannelInfo.CHANNELS; ++i) {
			TimerService.dbHelper.getControlsTable().updateControl(i + 1, modeNum,
					channelConfigs.get(i).getValue(), profileId, 0);
		}
		for (int i = ChannelInfo.CHANNELS; i < ChannelInfo.CHANNELS
				+ ChannelInfo.DIGITAL_CHANNELS; ++i) {
			TimerService.dbHelper.getControlsTable().updateControl(
					i + 1 - ChannelInfo.CHANNELS, modeNum,
					channelConfigs.get(i).getValue(), profileId, 1);
		}
	}

	private AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> parent, View v, int position,
				long id) {
			if (position < 12)
				startChannelConfig(position + 1);
			else if (12 == position)
				dialogHoldSettings();
			else
				dialogButtonSettings(position - 12);
		}
	};

	private void DisplayToast(String msg) {
		Toast.makeText(getBaseContext(), msg, Toast.LENGTH_SHORT).show();
	}

	private void startChannelConfig(int index) {
		mIndex = index - 1;
		AlertDialog.Builder dialog = new AlertDialog.Builder(this);
		dialog.setTitle("Select Channel Input");
		dialog.setSingleChoiceItems(configValues, channelConfigs.get(mIndex)
				.getValue(), null);
		dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int id) {
				int item = ((AlertDialog) dialog).getListView()
						.getCheckedItemPosition();
				if ((item >= 0) && (item < configValues.length)) {
					channelConfigs.get(mIndex).setValue(item);
					mAdapter.notifyDataSetChanged();
				}
			}
		});
		dialog.show();
	}

	public static String KEY_PREFS_CTRL(int index) {
		return String.format("control%d_settings", index);
	}

	public String KEY_CTRL_CHANNEL(int index) {
		return String.format("control_channel%d", index);
	}

	private void dialogHoldSettings() {
		LayoutInflater li = getLayoutInflater();
		final View v = li.inflate(R.layout.hold_position, null);
		AlertDialog.Builder dialog = new AlertDialog.Builder(this);
		dialog.setView(v);
		final CheckBox right_x = (CheckBox) v.findViewById(R.id.CheckRightX);
		final CheckBox right_y = (CheckBox) v.findViewById(R.id.CheckRightY);
		final CheckBox left_x = (CheckBox) v.findViewById(R.id.CheckLeftX);
		final CheckBox left_y = (CheckBox) v.findViewById(R.id.CheckLeftY);

		dialog.setTitle("Set hold position mode");
		dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {

				TimerService.dbHelper.getPositionsTable().updatePositionRecord(modeNum,
						profileId, right_x.isChecked() ? 1 : 0,
						right_y.isChecked() ? 1 : 0,
						left_x.isChecked() ? 1 : 0, left_y.isChecked() ? 1 : 0);
			}
		});

		Cursor settings = TimerService.dbHelper.getPositionsTable().fetchPositionRecord(
				profileId, modeNum);
		boolean b_rightx = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.PositionsTable.KEY_RIGHT_JOY_X)) == 1 ? true
				: false;
		boolean b_righty = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.PositionsTable.KEY_RIGHT_JOY_Y)) == 1 ? true
				: false;
		boolean b_leftx = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.PositionsTable.KEY_LEFT_JOY_X)) == 1 ? true
				: false;
		boolean b_lefty = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.PositionsTable.KEY_LEFT_JOY_Y)) == 1 ? true
				: false;

		right_x.setChecked(b_rightx);
		right_y.setChecked(b_righty);
		left_x.setChecked(b_leftx);
		left_y.setChecked(b_lefty);

		dialog.show();
	}

	private void dialogButtonSettings(int index) {
		char[] btn_label = { 'A', 'B', 'C', 'D' };

		LayoutInflater li = getLayoutInflater();
		final View v = li.inflate(R.layout.button_settings, null);

		mIndex = index;

		AlertDialog.Builder dialog = new AlertDialog.Builder(this);
		dialog.setView(v);

		Spinner spinnerType = (Spinner) v.findViewById(R.id.SpinnerBtnType);
		SliderView sliderOn = (SliderView) v.findViewById(R.id.SliderOn);
		SliderView sliderOff = (SliderView) v.findViewById(R.id.SliderOff);

		ArrayAdapter adapter = new ArrayAdapter(this,
				android.R.layout.simple_spinner_item, buttonTypes);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

		spinnerType.setAdapter(adapter);

		SliderHandler handler;
		sliderOn.setRange(ChannelSettingsActivity.CHANNEL_MIN_US,
				ChannelSettingsActivity.CHANNEL_MAX_US);
		handler = new SliderHandler() {
			@Override
			public String toString(int value) {
				return ChannelSettingsActivity.convertToDispUs(value);
			}
		};
		sliderOn.setHandler(handler);

		sliderOff.setRange(ChannelSettingsActivity.CHANNEL_MIN_US,
				ChannelSettingsActivity.CHANNEL_MAX_US);
		handler = new SliderHandler() {
			@Override
			public String toString(int value) {
				return ChannelSettingsActivity.convertToDispUs(value);
			}
		};
		sliderOff.setHandler(handler);

		char c = ' ';
		if ((index > 0) && (index <= 4))
			c = btn_label[index - 1];

		mSpinnerBtnType = spinnerType;
		mSliderBtnOn = sliderOn;
		mSliderBtnOff = sliderOff;

		dialog.setTitle(String.format("Button %c settings", c));
		dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				TimerService.dbHelper.getButtonsTable().updateButton(mIndex, modeNum,
						mSliderBtnOn.get(), mSliderBtnOff.get(),
						mSpinnerBtnType.getSelectedItemPosition(), profileId);
			}
		});

		Cursor btnSettings = TimerService.dbHelper.getButtonsTable().fetchButton(mIndex,
				profileId, modeNum);
		int btn_type = btnSettings.getInt(btnSettings
				.getColumnIndexOrThrow(WircDbAdapter.ButtonsTable.KEY_TYPE));
		int on_level = btnSettings
				.getInt(btnSettings
						.getColumnIndexOrThrow(WircDbAdapter.ButtonsTable.KEY_ON_LEVEL));
		int off_level = btnSettings
				.getInt(btnSettings
						.getColumnIndexOrThrow(WircDbAdapter.ButtonsTable.KEY_OFF_LEVEL));

		spinnerType.setSelection(btn_type);
		sliderOn.set(on_level);
		sliderOff.set(off_level);

		dialog.show();
	}

	public static String KEY_CTRL_BTN_TYPE(int index) {
		return String.format("control_button%d_type", index);
	}

	public static String KEY_CTRL_BTN_ON(int index) {
		return String.format("control_button%d_on", index);
	}

	public static String KEY_CTRL_BTN_OFF(int index) {
		return String.format("control_button%d_off", index);
	}

	private static int L_DEFAULT_BTN_TYPE(int index) {
		if ((1 == index) || (2 == index))
			return 0;
		else
			return 1;
	}
}
