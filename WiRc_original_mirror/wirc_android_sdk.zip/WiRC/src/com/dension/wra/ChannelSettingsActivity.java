package com.dension.wra;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import over.TimerService;
import wirc.dension.com.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import channel.ChannelInfo;

import com.dension.sqliteaccess.ChannelDTO;
import com.dension.sqliteaccess.WircDbAdapter;

public class ChannelSettingsActivity extends Activity {

	private static final String[] failsafeModes = new String[] {
			"Disable output", "Last good", "Pre-set", };

	private static final String[] sensitivityTypes = new String[] { "Linear",
			"Exponential", };

	private static final String[] mixTypes = new String[] { "Off", "On" };

	// preferences
	public static final String CHANNEL_SETTING_PREFERENCES = "ChannelSetting";

	// default values
	public static final int DEFAULT_MIN = 1000;
	public static final int DEFAULT_MAX = 2000;
	public static final int DEFAULT_TRIM = 1500;
	public static final int DEFAULT_FAILSAFE = 1500;
	public static final int FAILSAFE_DISABLE = 0;
	public static final int FAILSAFE_LAST_GOOD = 1;
	public static final int FAILSAFE_PRE_SET = 2;
	public static final int PERC_CHANNEL_MIN_US = 1000;
	public static final int PERC_CHANNEL_MAX_US = 2000;
	public static final int SPI_REP_FREQ = 50;
	public static final int FACTOR_SLIDER_MIN = -100;
	public static final int FACTOR_SLIDER_MAX = 100;
	public static final int CHANNEL_MIN_US = 800;
	public static final int CHANNEL_MAX_US = 2200;

	// setting blueprints
	public static final String KEY_BUNDLE_INDEX = "bundle_channel_index";
	public static final String IS_REVERSE = "channel%d_reverse";
	public static final String MIN_VALUE = "channel%d_min";
	public static final String MAX_VALUE = "channel%d_max";
	public static final String NAME = "channel%d_name";
	public static final String TRIM_VALUE = "channel%d_trim";
	public static final String FAILSAFE_MODE = "channel%d_failsafe_mode";
	public static final String FAILSAFE_PRESET = "channel%d_failsafe_preset";
	public static final String SENSITIVITY = "channel%d_sensitivity";
	public static final String EXP_FACT = "channel%d_exp_factor";
	public static final String SENS_MIX = "channel%d_sens_mix";
	public static final String SENS_MIX_CH = "channel%d_sens_mix_ch";
	public static final String SENS_MIX_ABS = "channel%d_sens_mix_abs";
	public static final String SENS_MIX_FACT = "channel%d_sens_mix_factor";
	public static final String VALUE_MIX = "channel%d_value_mix";
	public static final String VALUE_MIX_CH = "channel%d_value_mix_ch";
	public static final String VALUE_MIX_ABS = "channel%d_value_mix_abs";
	public static final String VALUE_MIX_FACT = "channel%d_value_mix_factor";

	private TextView channelNameText;
	private CheckBox reverseButton;
	private ToggleButton testButton;
	private SliderView minSlider;
	private SliderView maxSlider;
	private SliderView trimSlider;
	private Spinner failsafeSpinner;
	private SliderView failsafeSlider;
	private Spinner sensitivitySpinner;
	private SliderView expFactorSlider;
	private Spinner sensMixSpinner;
	private Spinner sensMixChSpinner;
	private CheckBox sensMixAbsCheckbox;
	private SliderView sensMixFactorSlider;
	private Spinner valueMixSpinner;
	private Spinner valueMixChSpinner;
	private CheckBox valueMixAbsCheckbox;
	private SliderView valueMixFactorSlider;
	private SliderView repFreqSlider;

	// these are lookup tables since spinners cannot handle key-value pairs
	private HashMap<Integer, Integer> valueChLookup = new HashMap<Integer, Integer>();
	private HashMap<Integer, Integer> sensChLookup = new HashMap<Integer, Integer>();

	private int channelNum;
	private int rowId;
	// private WircDbAdapter dbHelper;
	private boolean isTesting;

	// needed for test
	private String wrcName;
	private String wrcIp;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		/*
		dbHelper = new WircDbAdapter(this);
		dbHelper.open();
		*/
		setContentView(R.layout.channel_settings);
		SliderHandler handler;
		ArrayAdapter<?> adapter;

		// getting channel num
		Bundle bundle = this.getIntent().getExtras();
		channelNum = bundle.getInt(KEY_BUNDLE_INDEX);
		if (channelNum < 1)
			channelNum = 1;
		if (channelNum > ChannelInfo.CHANNELS)
			channelNum = ChannelInfo.CHANNELS;

		// Channel name
		channelNameText = (TextView) findViewById(R.id.EditName);
		channelNameText.setText(String.format("CHANNEL %d", channelNum));
		channelNameText.setOnClickListener(ListenerChName);

		setTitle(String.format("Channel %d settings", channelNum));

		// Reverse check box
		reverseButton = (CheckBox) findViewById(R.id.CheckBoxReverse);
		// Test toggle button
		testButton = (ToggleButton) findViewById(R.id.ToggleTest);
		TableRow tableRow_ToggleTest = (TableRow) findViewById(R.id.tableRow_ToggleTest);
		if ( TimerService.access )
			tableRow_ToggleTest.setVisibility(View.VISIBLE);
		else
			tableRow_ToggleTest.setVisibility(View.GONE);
			
		testButton.setOnTouchListener(new View.OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (event.getAction() == MotionEvent.ACTION_DOWN) {
					isTesting = !isTesting;
					testButton.toggle();
				}
				return true;
			}
		});

		// Min, Max, Trimming
		minSlider = (SliderView) findViewById(R.id.SliderMin);
		minSlider.setRange(CHANNEL_MIN_US, CHANNEL_MAX_US);
		maxSlider = (SliderView) findViewById(R.id.SliderMax);
		maxSlider.setRange(CHANNEL_MIN_US, CHANNEL_MAX_US);
		trimSlider = (SliderView) findViewById(R.id.SliderTrimming);
		trimSlider.setRange(CHANNEL_MIN_US, CHANNEL_MAX_US);

		handler = new SliderHandler() {
			@Override
			public String toString(int value) {
				return convertToDispUs(value);
			}

			@Override
			public int onChanged(int value) {
				if ( trimSlider.get() > 0 ) {
					if (value > trimSlider.get()) {
						value = trimSlider.get();
						minSlider.set(value);
					}
					else {
						if (value > maxSlider.get()) {
							maxSlider.set(value);
						}
						if (maxSlider.get() < value) {
							maxSlider.set(value);
						}
						
						if (isTesting) {
							TimerService.periodicChannelData.setChannel(channelNum, value);
						}
					}
				}
				
				return value;
			}
		};
		minSlider.setHandler(handler);

		handler = new SliderHandler() {
			@Override
			public String toString(int value) {
				return convertToDispUs(value);
			}

			@Override
			public int onChanged(int value) {
				if ( trimSlider.get() > 0 ) {
					if (value < trimSlider.get()) {
						value = trimSlider.get();
						maxSlider.set(value);
					}
					else {
						if (value < minSlider.get()) {
							minSlider.set(value);
						}
						if (trimSlider.get() > value) {
							trimSlider.set(value);
						}
						if (isTesting) {
							TimerService.periodicChannelData.setChannel(channelNum, value);
						}
					}
				}
				
				return value;
			}
		};
		maxSlider.setHandler(handler);

		handler = new SliderHandler() {
			@Override
			public String toString(int value) {
				return convertToDispUs(value);
			}

			@Override
			public int onChanged(int value) {
				if (value < minSlider.get()) {
					minSlider.set(value);
				}
				if (value > maxSlider.get()) {
					maxSlider.set(value);
				}
				if (isTesting) {
					TimerService.periodicChannelData.setChannel(channelNum, value);
				}
				
				return value;
			}
		};
		trimSlider.setHandler(handler);

		// Failsafe mode
		failsafeSpinner = (Spinner) findViewById(R.id.SpinnerFailsafe);
		adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item,
				failsafeModes);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		failsafeSpinner.setAdapter(adapter);
		failsafeSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parentView,
					View selectedItemView, int position, long id) {
				if (2 != position) {
					failsafeSlider.setEnabled(false);
				} else {
					failsafeSlider.setEnabled(true);
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> parentView) {
			}
		});

		failsafeSlider = (SliderView) findViewById(R.id.SliderFailsafe);
		failsafeSlider.setRange(CHANNEL_MIN_US, CHANNEL_MAX_US);

		handler = new SliderHandler() {
			@Override
			public String toString(int value) {
				return convertToDispUs(value);
			}
		};
		failsafeSlider.setHandler(handler);

		// Sensitivity
		sensitivitySpinner = (Spinner) findViewById(R.id.SpinnerSens);
		adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item,
				sensitivityTypes);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		sensitivitySpinner.setAdapter(adapter);
		sensitivitySpinner
				.setOnItemSelectedListener(new OnItemSelectedListener() {
					@Override
					public void onItemSelected(AdapterView<?> parentView,
							View selectedItemView, int position, long id) {
						if (0 == position) {
							expFactorSlider.setEnabled(false);
						} else {
							expFactorSlider.setEnabled(true);
						}
					}

					@Override
					public void onNothingSelected(AdapterView<?> parentView) {
					}
				});
		expFactorSlider = (SliderView) findViewById(R.id.SliderExpFact);
		expFactorSlider.setRange(FACTOR_SLIDER_MIN, FACTOR_SLIDER_MAX);
		handler = new SliderHandler() {
			@Override
			public String toString(int value) {
				return convertToDispPerc(value);
			}
		};
		expFactorSlider.setHandler(handler);

		// Sensitivity Mixer
		sensMixSpinner = (Spinner) findViewById(R.id.SpinnerSensMix);
		adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item,
				mixTypes);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		sensMixSpinner.setAdapter(adapter);
		sensMixSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parentView,
					View selectedItemView, int position, long id) {
				if (0 == position) {
					sensMixChSpinner.setEnabled(false);
					sensMixFactorSlider.setEnabled(false);
					sensMixAbsCheckbox.setEnabled(false);
				} else {
					sensMixChSpinner.setEnabled(true);
					sensMixFactorSlider.setEnabled(true);
					sensMixAbsCheckbox.setEnabled(true);
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> parentView) {
			}
		});

		sensMixChSpinner = (Spinner) findViewById(R.id.SpinnerSensMixCh);
		String[] channels;
		int i, j;
		channels = new String[ChannelInfo.CHANNELS - 1];
		for (i = 0, j = 0; i <= channels.length; ++i) {
			if (i + 1 != channelNum) {
				channels[j] = Integer.toString(i + 1);
				sensChLookup.put(j, i + 1);
				j++;
			}
		}
		adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item,
				channels);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		sensMixChSpinner.setAdapter(adapter);

		sensMixAbsCheckbox = (CheckBox) findViewById(R.id.CheckBoxSensAbs);
		sensMixFactorSlider = (SliderView) findViewById(R.id.SliderSensMix);
		sensMixFactorSlider.setRange(FACTOR_SLIDER_MIN, FACTOR_SLIDER_MAX);
		handler = new SliderHandler() {
			@Override
			public String toString(int value) {
				return convertToDispPerc(value);
			}
		};
		sensMixFactorSlider.setHandler(handler);

		// value mixer
		valueMixSpinner = (Spinner) findViewById(R.id.SpinnerValueMix);
		adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item,
				mixTypes);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		valueMixSpinner.setAdapter(adapter);
		valueMixSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parentView,
					View selectedItemView, int position, long id) {
				if (0 == position) {
					valueMixChSpinner.setEnabled(false);
					valueMixFactorSlider.setEnabled(false);
					valueMixAbsCheckbox.setEnabled(false);
				} else {
					valueMixChSpinner.setEnabled(true);
					valueMixFactorSlider.setEnabled(true);
					valueMixAbsCheckbox.setEnabled(true);
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> parentView) {
			}
		});

		valueMixChSpinner = (Spinner) findViewById(R.id.SpinnerValueMixCh);
		channels = new String[ChannelInfo.CHANNELS - 1];
		for (i = 0, j = 0; i <= channels.length; ++i) {
			if (i + 1 != channelNum) {
				channels[j] = Integer.toString(i + 1);
				valueChLookup.put(j, i + 1);
				j++;
			}
		}
		adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item,
				channels);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		valueMixChSpinner.setAdapter(adapter);

		valueMixAbsCheckbox = (CheckBox) findViewById(R.id.CheckBoxValueAbs);
		valueMixFactorSlider = (SliderView) findViewById(R.id.SliderValueMix);
		valueMixFactorSlider.setRange(FACTOR_SLIDER_MIN, FACTOR_SLIDER_MAX);
		handler = new SliderHandler() {
			@Override
			public String toString(int value) {
				return convertToDispPerc(value);
			}
		};
		valueMixFactorSlider.setHandler(handler);

		// Repeat frequency
		repFreqSlider = (SliderView) findViewById(R.id.SliderRepFreq);
		repFreqSlider.setRange(50, 200);
		handler = new SliderHandler() {
			@Override
			public String toString(int value) {
				int hz, ms;
				hz = value;
				ms = (int) (1e3 / value);
				return String.format("%d Hz / %d ms", hz, ms);
			}
		};
		repFreqSlider.setHandler(handler);

		getSettings();
	}

	// utility methods
	private void getSettings() {
		Cursor settings = 
			TimerService.dbHelper.getChannelsTable().fetchChannel(channelNum, TimerService.dbHelper.getProfilesTable().getActiveProfileId());
		rowId = settings.getInt(settings
				.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_ROWID));
		String channelName = settings.getString(settings
				.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_NAME));
		boolean isReverse = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_IS_REVERSE)) == 1 ? true
				: false;
		int minValue = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_MIN_VALUE));
		int maxValue = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_MAX_VALUE));
		int trimValue = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_TRIM_VALUE));
		int failsafeMode = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_FAILSAFE_MODE));
		int failsafePresetValue = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_FAILSAFE_PRESET));
		int sensType = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_SENSITIVITY_TYPE));
		int expFactor = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_EXPONENTIAL_FACTOR));
		int isSensMixerActive = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_SENSITIVITY_MIXER));
		int sensMixerChannel = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_SENSITIVITY_MIXER_CHANNEL));
		boolean isSensMixerAbsolulte = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_SENSITIVITY_MIXER_ABSOLUTE)) > 0 ? true
				: false;
		int sensMixFactor = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_SENSITIVITY_MIXER_FACTOR));
		int isValueMixerActive = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_VALUE_MIXER));
		int valueMixerChannel = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_VALUE_MIXER_CHANNEL));
		boolean isValueMixerAbsolute = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_VALUE_MIXER_ABSOLUTE)) > 0 ? true
				: false;
		int valueMixFactor = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_VALUE_MIXER_FACTOR));
		int repeatFreq = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_REPEAT_FQ));

		channelNameText.setText(channelName);
		reverseButton.setChecked(isReverse);
		minSlider.set(minValue);
		maxSlider.set(maxValue);
		trimSlider.set(trimValue);
		failsafeSpinner.setSelection(failsafeMode);
		failsafeSlider.set(failsafePresetValue);
		sensitivitySpinner.setSelection(sensType);
		expFactorSlider.set(expFactor);
		sensMixSpinner.setSelection(isSensMixerActive);
		Set<Integer> keySet = sensChLookup.keySet();
		Iterator<Integer> keyIter = keySet.iterator();
		boolean isFound = false;
		while (keyIter.hasNext() && !isFound) {
			Integer key = keyIter.next();
			if (sensChLookup.get(key) == sensMixerChannel) {
				sensMixChSpinner.setSelection(key);
				isFound = true;
			}
		}
		sensMixAbsCheckbox.setChecked(isSensMixerAbsolulte);
		sensMixFactorSlider.set(sensMixFactor);
		valueMixSpinner.setSelection(isValueMixerActive);
		keySet = valueChLookup.keySet();
		keyIter = keySet.iterator();
		isFound = false;
		while (keyIter.hasNext() && !isFound) {
			Integer key = keyIter.next();
			if (valueChLookup.get(key) == valueMixerChannel) {
				valueMixChSpinner.setSelection(key);
				isFound = true;
			}
		}
		valueMixAbsCheckbox.setChecked(isValueMixerAbsolute);
		valueMixFactorSlider.set(valueMixFactor);
		repFreqSlider.set(repeatFreq);
		if ((7 == channelNum) || (8 == channelNum)) {
			repFreqSlider.set(SPI_REP_FREQ);
			repFreqSlider.setEnabled(false);
		}
		if (((2 == channelNum) || (4 == channelNum)) || (6 == channelNum)) {
			repFreqSlider.setEnabled(false);
		}
	}

	private void saveSettings() {
		int sensCh;
		int valCh;
		try {
			sensCh = sensChLookup.get(sensMixChSpinner
					.getSelectedItemPosition());
		} catch (NullPointerException e) {
			sensCh = channelNum;
		}
		try {
			valCh = valueChLookup.get(valueMixChSpinner
					.getSelectedItemPosition());
		} catch (NullPointerException e) {
			valCh = channelNum;
		}
		ChannelDTO channelDTO = new ChannelDTO();
		channelDTO.setChIdx(channelNum);
		channelDTO.setExpFactor(expFactorSlider.get());
		channelDTO.setFailsafeMode(failsafeSpinner.getSelectedItemPosition());
		channelDTO.setFailsafePreset(failsafeSlider.get());
		channelDTO.setIsReverse(reverseButton.isChecked() ? 1 : 0);
		channelDTO.setMaxValue(maxSlider.get());
		channelDTO.setMinValue(minSlider.get());
		channelDTO.setName(channelNameText.getText().toString());
		channelDTO.setProfileId((int) TimerService.dbHelper.getProfilesTable().getActiveProfileId());
		channelDTO.setRepFq(repFreqSlider.get());
		channelDTO.setRowId((long) rowId);
		channelDTO.setSensMix(sensMixSpinner.getSelectedItemPosition());
		channelDTO.setSensMixAbs(sensMixAbsCheckbox.isChecked() ? 1 : 0);
		channelDTO.setSensMixCh(sensCh);
		channelDTO.setSensMixFact(sensMixFactorSlider.get());
		channelDTO.setSensType(sensitivitySpinner.getSelectedItemPosition());
		channelDTO.setTrimValue(trimSlider.get());
		channelDTO.setValMix(valueMixSpinner.getSelectedItemPosition());
		channelDTO.setValMixAbs(valueMixAbsCheckbox.isChecked() ? 1 : 0);
		channelDTO.setValMixCh(valCh);
		channelDTO.setValMixFact(valueMixFactorSlider.get());
		TimerService.dbHelper.getChannelsTable().updateChannel(channelDTO);
	}

	@Override
	public void onStop() {
		super.onStop();
		// save settings
		saveSettings();
	}

	public static String convertToDispPerc(int value) {
		return String.format("%d%%", value);
	}

	public static String convertToDispUs(int value) {
		float slope = 200f / (PERC_CHANNEL_MAX_US - PERC_CHANNEL_MIN_US);
		float offset = -100 - (slope * PERC_CHANNEL_MIN_US);
		int percentage = (int) (slope * value + offset);

		return String.format("%d%% / %d us", percentage, value);
	}

	public static String KEY_CH_REP_FREQ(int index) {
		if (2 == index)
			index = 1;
		if (4 == index)
			index = 3;
		if (6 == index)
			index = 5;
		return String.format("channel%d_rep_freq", index);
	}

	private View.OnClickListener ListenerChName = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			dialogChannelName();
		}
	};

	private void dialogChannelName() {
		LinearLayout compoundView = new LinearLayout(this);
		compoundView.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));
		compoundView.setPadding(30, 0, 30, 0);

		final EditText editChName = new EditText(this);
		editChName.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));
		editChName.setText(channelNameText.getText());
		editChName.setSingleLine();
		AlertDialog.Builder dialog = new AlertDialog.Builder(this);
		dialog.setTitle("Rename Channel");
		dialog.setMessage("Rename Channel");

		compoundView.addView(editChName);

		dialog.setView(compoundView);

		dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				channelNameText.setText(editChName.getText());
			}
		});

		dialog.show();
	}
	
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

}
