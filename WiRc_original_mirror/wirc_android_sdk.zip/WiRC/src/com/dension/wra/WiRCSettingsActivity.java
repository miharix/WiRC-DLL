package com.dension.wra;

import java.io.InputStream;
import java.util.List;

import over.TimerService;
import wirc.dension.com.R;
import wrc.WRCDevice;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.dension.messages.DeviceConfigurationMessage;
import com.dension.messages.FirmwareUpgradeMessage;
import com.dension.messages.WiFiConfigurationMessage;

import ftp.FTP;

public class WiRCSettingsActivity extends Activity {
	public static final String KEY_PREFS_WIRC = "WiRC_settings";

	private static final int L_VOLT_MIN = 5000;
	private static final int L_VOLT_MAX = 15000;

	private Context context;
	private WRCDevice wrcDevice;
	private FTP ftp;
	private ProgressDialog progressDialog;
	private AlertDialog alertDialogFTP;
	private AlertDialog alertDialogWarning;

	private TextView mTextHwVersion;
	private TextView mTextSwVersion;
	private TextView mTextSerial;
	private SliderView mSliderCamVolt;
	private SliderView mSliderDevVolt;
	private TextView mTextSSID;
	private Spinner spinner_ap;
	private Spinner spinner_sec;
	private TextView mTextPassword;
	private Spinner spinner_ch;
	private Button button_WCFG;
	private LinearLayout mLayoutFwUp;
	private TextView mTextFwUp;
	private Button button_firmware;
	private Button button_update_name;
	private EditText editText_name;
	private EditText editText_ssid;
	private EditText editText_passw;

	private static final String[] mWiFiChannels = new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" };

	private static final String[] mWiFiMode = new String[] { "Client (Station)", "Access Point (AP)" };

	private static final String[] mWiFiSec = new String[] { "Open", "WPA/WPA2" };

	private String ssid;
	private String passw;
	private byte ap;
	private byte sec;
	private byte ch;
	private String country;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.wirc_settings);

		this.context = this.getApplicationContext();

		SliderHandler handler;
		ArrayAdapter<String> adapter;

		mTextHwVersion = (TextView) findViewById(R.id.TextHWVersion);
		mTextSwVersion = (TextView) findViewById(R.id.TextSWVersion);
		mTextSerial = (TextView) findViewById(R.id.TextSerial);
		mSliderCamVolt = (SliderView) findViewById(R.id.SliderCamVolt);
		mSliderDevVolt = (SliderView) findViewById(R.id.SliderDevVolt);

		editText_ssid = (EditText) findViewById(R.id.editText_ssid);
		spinner_ap = (Spinner) findViewById(R.id.spinner_ap);
		spinner_sec = (Spinner) findViewById(R.id.spinner_sec);
		spinner_sec.setOnItemSelectedListener(spinner_sec_OnItemSelectedListener);
		spinner_ch = (Spinner) findViewById(R.id.spinner_ch);
		editText_passw = (EditText) findViewById(R.id.editText_passw);
		// editText_passw = (EditText) findViewById(R.id.editText_name); // bad

		button_WCFG = (Button) findViewById(R.id.button_WCFG);
		button_WCFG.setOnClickListener(button_WCFG_OnClickListener);

		mLayoutFwUp = (LinearLayout) findViewById(R.id.LayoutFwUp);
		mTextFwUp = (TextView) findViewById(R.id.TextFwUp);
		button_firmware = (Button) findViewById(R.id.button_firmware);
		button_firmware.setOnClickListener(button_firmware_OnClickListener);
		editText_name = (EditText) findViewById(R.id.editText_name);

		handler = new SliderHandler() {
			@Override
			public String toString(int value) {
				return convertToDispVolt(value);
			}
		};
		mSliderCamVolt.setHandler(handler);
		mSliderDevVolt.setHandler(handler);
		mSliderCamVolt.setRange(L_VOLT_MIN, L_VOLT_MAX);
		mSliderDevVolt.setRange(L_VOLT_MIN, L_VOLT_MAX);
		mSliderCamVolt.set(TimerService.sharedPreferences.getInt(getString(R.string.prefCamVolt), 7000));
		mSliderDevVolt.set(TimerService.sharedPreferences.getInt(getString(R.string.prefDevVolt), 7000));

		adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, mWiFiMode);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner_ap.setAdapter(adapter);
		spinner_ap.setSelection(1);
		adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, mWiFiChannels);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner_ch.setAdapter(adapter);
		adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, mWiFiSec);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner_sec.setAdapter(adapter);
		setPasswVisibility(spinner_sec.getSelectedItemPosition());

		button_update_name = (Button) findViewById(R.id.button_update_name);
		button_update_name.setOnClickListener(button_update_name_OnClickListener);

		ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
		if (networkInfo.isConnected()) {
			WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
			WifiInfo wifiInfo = wifiManager.getConnectionInfo();
			List<WifiConfiguration> configs = wifiManager.getConfiguredNetworks();
			ssid = wifiInfo.getSSID();
			int i = 0;
			WifiConfiguration wifiConfiguration = null;
			while ((i < configs.size()) && (wifiConfiguration == null)) {
				String configSSID = configs.get(i).SSID;
				configSSID = configSSID.replace('"', ' ').trim();
				if (ssid.equals(configSSID))
					wifiConfiguration = configs.get(i);
				i++;
			}

			editText_ssid.setText(ssid);
			if (wifiConfiguration != null) {
			}
		}

		ftp = new FTP(handlerFTP);

		Boolean updatable = false;

		if (TimerService.status.connected) {
			wrcDevice = TimerService.wrcList.deviceList.get(TimerService.selectedWRCDevice);
			editText_name.setText(wrcDevice.getName());
			mTextHwVersion.setText(wrcDevice.getMajorHardwareVersion() + "." + wrcDevice.getMinorHardwareVersion());
			mTextSwVersion.setText(wrcDevice.getMajorSoftwareVersion() + "." + wrcDevice.getMinorSoftwareVersion());
			mTextSerial.setText(wrcDevice.getSerial());

			updatable = isGreatherOrEqual(wrcDevice.getMajorHardwareVersion(), wrcDevice.getMinorHardwareVersion(), TimerService.majorHWVersion, TimerService.minorHWVersion);

			updatable = updatable && !isGreatherOrEqual(wrcDevice.getMajorSoftwareVersion(), wrcDevice.getMinorSoftwareVersion(), TimerService.majorFirmwareVersion, TimerService.minorFirmwareVersion);
		} else {
			findViewById(R.wirc_setting.layout_device).setVisibility(View.GONE);
			findViewById(R.wirc_setting.layout_other).setVisibility(View.GONE);
		}

		// updatable = false;
		if (updatable) {
			String oldVersion = mTextSwVersion.getText().toString();
			String newVersion = TimerService.majorFirmwareVersion + "." + TimerService.minorFirmwareVersion;
			mLayoutFwUp.setVisibility(View.VISIBLE);
			mTextFwUp.setText(mTextFwUp.getText() + oldVersion + " -> " + newVersion);
		} else {
			mLayoutFwUp.setVisibility(View.GONE);
		}
	}

	@Override
	public void onDestroy() {
		SharedPreferences.Editor editor = TimerService.sharedPreferences.edit();
		editor.putInt(getString(R.string.prefCamVolt), mSliderCamVolt.get());
		editor.putInt(getString(R.string.prefDevVolt), mSliderDevVolt.get());
		editor.commit();

		super.onDestroy();
	}

	private Boolean isGreatherOrEqual(int majorA, int minorA, int majorB, int minorB) {
		Boolean greather = false;

		if (majorA > majorB)
			greather = true;
		else {
			if (majorA == majorB)
				greather = minorA >= minorB;
		}

		return greather;
	}

	private OnClickListener button_update_name_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View view) {
			if (!editText_name.getText().toString().equals("")) {
				DeviceConfigurationMessage dcfg = new DeviceConfigurationMessage(editText_name.getText().toString(), (short) 0, (short) 0);
				TimerService.control.sendMsg(dcfg);
			}
		}
	};

	private OnClickListener button_firmware_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View view) {
			// update();
			alertDialogWarning = new AlertDialog.Builder(WiRCSettingsActivity.this).create();
			alertDialogWarning.setTitle(getString(R.string.sWarning));
			alertDialogWarning.setMessage(getString(R.string.sFirmwareWarning));
			alertDialogWarning.setButton(getString(R.string.sUpdateFirmware).toString(), listenet_alertDialogWarning);
			alertDialogWarning.setButton2(getString(R.string.sCancel).toString(), listenet_alertDialogWarning);
			alertDialogWarning.show();
		}
	};

	private Handler handlerFTP = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			ftp.disconnect();
			progressDialog.dismiss();

			if (msg.arg1 == FTP.SUCCESS) {
				update();
			} else {
				alertDialogFTP = new AlertDialog.Builder(WiRCSettingsActivity.this).create();
				alertDialogFTP.setTitle(getString(R.string.sUpload));
				alertDialogFTP.setMessage(getString(R.string.sError));
				alertDialogFTP.setButton(getString(R.string.sOk).toString(), listener_alertDialog);
				alertDialogFTP.show();
			}
		}
	};

	private DialogInterface.OnClickListener listenet_alertDialogWarning = new DialogInterface.OnClickListener() {
		@Override
		public void onClick(DialogInterface arg0, int arg1) {
			if (arg1 == -1) {
				if (wrcDevice != null) {
					progressDialog = ProgressDialog.show(WiRCSettingsActivity.this, getString(R.string.sUpload), getString(R.string.sWait));
					InputStream inputStream = getResources().openRawResource(R.raw.wrc_update);
					ftp.connect(wrcDevice.getIp());
					ftp.uploadStream("WRC_update.den", inputStream);
				}
			}
		}
	};

	private void update() {
		FirmwareUpgradeMessage fwup = new FirmwareUpgradeMessage(TimerService.firmware_md5);
		TimerService.control.sendMsg(fwup);
		Toast toast = Toast.makeText(context, getString(R.string.sUpdateStarted), Toast.LENGTH_LONG);
		toast.show();
		// finish();
	}

	private DialogInterface.OnClickListener listener_alertDialog = new DialogInterface.OnClickListener() {
		@Override
		public void onClick(DialogInterface arg0, int arg1) {
		}
	};

	private OnClickListener button_WCFG_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View view) {
			ch = (byte) Integer.parseInt((String) spinner_ch.getSelectedItem());
			ap = (byte) spinner_ap.getSelectedItemId();
			sec = (byte) spinner_sec.getSelectedItemId();
			WiFiConfigurationMessage wcfg = new WiFiConfigurationMessage(editText_ssid.getText().toString(), editText_passw.getText().toString(), ap, sec, ch, "HU");
			if (TimerService.access) {
				TimerService.control.sendMsg(wcfg);
				Toast toast = Toast.makeText(context, getString(R.string.sWcfgStarted), Toast.LENGTH_LONG);
				toast.show();
			}
		}
	};

	private AdapterView.OnItemSelectedListener spinner_sec_OnItemSelectedListener = new AdapterView.OnItemSelectedListener() {
		@Override
		public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
			setPasswVisibility(pos);
		}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
		}
	};

	private void setPasswVisibility(int pos) {
		if (pos == 0) {
			findViewById(R.id.tableRow_passw).setVisibility(View.GONE);
		} else {
			findViewById(R.id.tableRow_passw).setVisibility(View.VISIBLE);
		}
	}

	private static final String convertToDispVolt(int value) {
		return String.format("%.1f V", value / 1000f);
	}
}
