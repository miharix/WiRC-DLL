package com.dension.wra.profile;

public class ProfileData {
	
	public long rowId;
	public String name;
	public boolean isActive;

	public ProfileData(long rowId, String name, boolean isActive) {
		this.rowId = rowId;
		this.name = name;
		this.isActive = isActive;
	}
	
	public ProfileData() {
		this.rowId = 0;
		this.name = "";
		this.isActive = false;
	}
	
}