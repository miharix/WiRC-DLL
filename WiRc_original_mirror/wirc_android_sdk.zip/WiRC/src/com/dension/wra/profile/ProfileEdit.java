/*
 * Copyright (C) 2008 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.dension.wra.profile;

import over.TimerService;
import wirc.dension.com.R;
import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.dension.sqliteaccess.WircDbAdapter;

public class ProfileEdit extends Activity {

	private ProfileData profileData;
	private EditText nameText;
	private CheckBox checkBox_active;
	private Long rowId;
	private WircDbAdapter dbHelper;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.profile_edit);
		setTitle("Edit profile");
		
		getWindow().setLayout(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
		
		dbHelper = new WircDbAdapter(this);
		dbHelper.open();


		nameText = (EditText) findViewById(R.profile_edit.editText_name);
		checkBox_active = (CheckBox) findViewById(R.profile_edit.checkBox_active);
		((Button) findViewById(R.profile_edit.button_ok)).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				String name = nameText.getText().toString();
				if (name.equals("")) {
					Toast.makeText(ProfileEdit.this, "Name field was empty, profile not saved.", Toast.LENGTH_LONG).show();
				} 
				else {
					int isActive = checkBox_active.isChecked() ? 1 : 0;

					if (rowId == null) {
						long id = dbHelper.getProfilesTable().createProfile(name, isActive);
						TimerService.saveDefaultSettings(id);
						if (id > 0) {
							rowId = id;
						}
					} 
					else {
						dbHelper.getProfilesTable().updateProfile(rowId, name, isActive);
					}
					
					finish();
				}
			}
		});
		
		((Button) findViewById(R.profile_edit.button_cancel)).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		
		profileData = new ProfileData();
		Bundle bundle = getIntent().getExtras();
		if ( bundle != null ) {
			int mode = bundle.getInt(ProfileListSettingsActivity.PROFILE_MODE, ProfileListSettingsActivity.PROFILE_MODE_NONE);
			switch ( mode ) {
			case ProfileListSettingsActivity.PROFILE_MODE_ADD:
				break;
			case ProfileListSettingsActivity.PROFILE_MODE_EDIT:
				rowId = bundle.getLong(ProfileListSettingsActivity.PROFILE_ROWID);
				Cursor profile = dbHelper.getProfilesTable().fetchProfile(rowId);
				startManagingCursor(profile);
				profileData.rowId = rowId;
				profileData.name = profile.getString(profile.getColumnIndexOrThrow(WircDbAdapter.ProfilesTable.KEY_NAME));
				profileData.isActive = profile.getInt(profile.getColumnIndexOrThrow(WircDbAdapter.ProfilesTable.KEY_IS_ACTIVE)) == 1 ? true	: false;
				break;
			}
			
			nameText.setText(profileData.name);
			checkBox_active.setChecked(profileData.isActive);
			if ( profileData.isActive )
				checkBox_active.setVisibility(View.GONE);
		}
	}

}
