package com.dension.wra.profile;


import wirc.dension.com.R;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

public class ProfileListAdapter extends ArrayAdapter<ProfileData> {

	private Activity activity;
	private ProfileData[] profiles;
	private Listener listener;
	
	public ProfileListAdapter(Activity activity, int textViewResourceId, ProfileData[] profiles, Listener listener) {
		super(activity, textViewResourceId, profiles);
		
		this.activity = activity;
		this.profiles = profiles;
		this.listener = listener;
		
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final int index = position;
		
		View view = convertView;
		if (view == null) {
			LayoutInflater inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			view = inflater.inflate(R.layout.profiles_row, parent, false);
		}
		
		TextView textView_name = (TextView) view.findViewById(R.profiles_row.textView_name);
		TextView textView_name_active = (TextView) view.findViewById(R.profiles_row.textView_name_active);
		if ( profiles[position].isActive ) {
			textView_name_active.setText(profiles[position].name);
			textView_name_active.setVisibility(View.VISIBLE);
			textView_name.setVisibility(View.GONE);
		}
		else {
			textView_name.setText(profiles[position].name);
			textView_name_active.setVisibility(View.GONE);
			textView_name.setVisibility(View.VISIBLE);
		}
		
		Button button_edit = (Button) view.findViewById(R.profiles_row.button_edit);
		button_edit.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				listener.onButtonClick(index);
			}
		});
		
		view.invalidate();

		return view;
	}
	
	public interface Listener {
		public abstract void onButtonClick(int index);
	}
}