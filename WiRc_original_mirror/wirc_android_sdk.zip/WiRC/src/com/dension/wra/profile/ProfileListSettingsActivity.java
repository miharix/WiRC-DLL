package com.dension.wra.profile;

import over.TimerService;
import wirc.dension.com.R;
import android.app.ListActivity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View.OnClickListener;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.dension.sqliteaccess.WircDbAdapter;

import develop.Notify;

public class ProfileListSettingsActivity extends ListActivity {

	public static final String PROFILE_MODE = "MODE";
	public static final int PROFILE_MODE_NONE = 0;
	public static final int PROFILE_MODE_EDIT = 1;
	public static final int PROFILE_MODE_ADD = 2;
	public static final String PROFILE_ROWID = "PROFILE_ROWID";
	
	private WircDbAdapter dbHelper;
	private ProfileListAdapter adapter;
	
	private static final String TITLE = "Profiles";
	private static final int ACTIVITY_CREATE = 0;
	private static final int ACTIVITY_EDIT = 1;
	private static final int INSERT_ID = Menu.FIRST;
	private static final int DELETE_ID = Menu.FIRST + 1;
	private static final int RENAME_ID = Menu.FIRST + 2;
	private static final int RESET_ID = Menu.FIRST + 3;
	private ProfileData[] profiles;
	private int selectedItem;


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.profile_list);
		setTitle(TITLE);
		
		dbHelper = new WircDbAdapter(this);
		dbHelper.open();
		fillData();
		registerForContextMenu(getListView());
		
		((Button) findViewById(R.profile_list.button_add)).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(ProfileListSettingsActivity.this, ProfileEdit.class);
				intent.putExtra(PROFILE_MODE, PROFILE_MODE_ADD);
				intent.putExtra(PROFILE_ROWID, 0);
				startActivityForResult(intent, ACTIVITY_CREATE);
			}
		});
	}

	private void fillData() {
		Cursor profCursor = dbHelper.getProfilesTable().fetchAllProfiles();
		profCursor.moveToFirst();

		profiles = new ProfileData[profCursor.getCount()];
		for (int i = 0; i < profCursor.getCount(); i++) {
			profiles[i] = new ProfileData(
					profCursor
							.getInt(profCursor
									.getColumnIndexOrThrow(WircDbAdapter.ProfilesTable.KEY_ROWID)),
					profCursor.getString(profCursor
							.getColumnIndexOrThrow(WircDbAdapter.ProfilesTable.KEY_NAME)),
					profCursor.getInt(profCursor
							.getColumnIndexOrThrow(WircDbAdapter.ProfilesTable.KEY_IS_ACTIVE)) == 1 ? true
							: false);
			profCursor.moveToNext();
		}
		adapter = new ProfileListAdapter(this, android.R.layout.simple_list_item_1, profiles, profileListAdapter_listener);
		setListAdapter(adapter);
	}
	
	private ProfileListAdapter.Listener profileListAdapter_listener = new ProfileListAdapter.Listener() {

		@Override
		public void onButtonClick(int index) {
			selectedItem = index;
			openContextMenu(getListView());
		}
		
	};

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		
		menu.setHeaderTitle(profiles[selectedItem].name);
		menu.add(0, DELETE_ID, 0, "Delete profile");
		menu.add(0, RENAME_ID, 1, "Edit profile");
		menu.add(0, RESET_ID, 2, "Reset profile");
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {
		int res;
		long rowId;
		switch (item.getItemId()) {
		case DELETE_ID:
			res = dbHelper.getProfilesTable().deleteProfile(
					profiles[selectedItem].rowId);
			if (res == WircDbAdapter.ProfilesTable.QUERY_FAILED) {
				Toast.makeText(this, "You cannot delete an active profile!",
						Toast.LENGTH_LONG).show();
			}
			fillData();
			break;
			
		case RENAME_ID:
			Intent intent = new Intent(this, ProfileEdit.class);
			rowId = profiles[selectedItem].rowId;
			intent.putExtra(PROFILE_MODE, PROFILE_MODE_EDIT);
			intent.putExtra(PROFILE_ROWID, rowId);
			startActivityForResult(intent, ACTIVITY_EDIT);
			break;
			
		case RESET_ID:
			ProfileData profile = profiles[selectedItem];
			long id = dbHelper.getProfilesTable().createProfile(profile.name, profile.isActive ? 1 : 0);
			dbHelper.getProfilesTable().deleteProfile(profile.rowId);
			TimerService.saveDefaultSettings(id);
			fillData();
			break;
			
		}
		return super.onContextItemSelected(item);
	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		dbHelper.getProfilesTable().setActiveProfile(profiles[position].rowId);
		fillData();
		
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
		super.onActivityResult(requestCode, resultCode, intent);
		fillData();
	}
}
