package com.dension.wra;

import java.util.ArrayList;

import over.TimerService;
import wirc.dension.com.R;
import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.Toast;
import android.widget.ToggleButton;
import channel.ChannelInfo;

import com.dension.sqliteaccess.WircDbAdapter;

public class ManeuverSettingsActivity extends Activity {
	public static final String KEY_MANEUVER_BUNDLE_INDEX = "maneuver_index";

	public static final int L_DEFAULT_VALUE = 1500;

	private int manIdx;

	private ToggleButton toggleTest;
	private boolean isTesting = false;
	ArrayList<SliderView> chSliders;
	ArrayList<CheckBox> chOverrides;
	// private WircDbAdapter dbHelper;
	private long profileId;

	// needed for test
	// private ControlThread controlThread;
	// private PeriodicChannelDataThread pcdThread;
	/*
	private String wrcName;
	private String wrcIp;
	*/
	// private PeriodicStatusDataThread psdThread;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		profileId = TimerService.dbHelper.getProfilesTable().getActiveProfileId();
		setContentView(R.layout.maneuver_settings);
		SliderHandler handler;

		chSliders = new ArrayList<SliderView>(8);
		chOverrides = new ArrayList<CheckBox>(8);

		Bundle bundle = this.getIntent().getExtras();
		manIdx = bundle.getInt(KEY_MANEUVER_BUNDLE_INDEX);
		if (manIdx < 1)
			manIdx = 1;
		if (manIdx > 2)
			manIdx = 2;

		/* Test toggle button */
		toggleTest = (ToggleButton) findViewById(R.id.ToggleTest);
		toggleTest.setOnTouchListener(new View.OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (event.getAction() == MotionEvent.ACTION_DOWN) {
					isTesting = !isTesting;
					toggleTest.toggle();
				}
				return true;
			}
		});
		int i;
		final int[] slider_ids = { R.id.SliderChannel1, R.id.SliderChannel2,
				R.id.SliderChannel3, R.id.SliderChannel4, R.id.SliderChannel5,
				R.id.SliderChannel6, R.id.SliderChannel7, R.id.SliderChannel8 };
		final int[] enable_ids = { R.id.CheckBoxEn1, R.id.CheckBoxEn2,
				R.id.CheckBoxEn3, R.id.CheckBoxEn4, R.id.CheckBoxEn5,
				R.id.CheckBoxEn6, R.id.CheckBoxEn7, R.id.CheckBoxEn8 };
		// get preference file

		for (i = 0; i < ChannelInfo.CHANNELS; ++i) {
			Cursor settings = TimerService.dbHelper.getManeuversTable().fetchManeuver(
					manIdx, profileId, i + 1);
			boolean isEnabled = settings
					.getInt(settings
							.getColumnIndexOrThrow(WircDbAdapter.ManeuversTable.KEY_IS_OVERRIDING)) == 1 ? true
					: false;
			int value = settings
					.getInt(settings
							.getColumnIndexOrThrow(WircDbAdapter.ManeuversTable.KEY_VALUE));

			SliderView slider = (SliderView) findViewById(slider_ids[i]);
			slider.setRange(ChannelSettingsActivity.CHANNEL_MIN_US,
					ChannelSettingsActivity.CHANNEL_MAX_US);

			handler = new SliderHandler() {
				@Override
				public String toString(int value) {
					return ChannelSettingsActivity.convertToDispUs(value);
				}
			};
			slider.setHandler(handler);
			chSliders.add(slider);

			CheckBox enable = (CheckBox) findViewById(enable_ids[i]);
			chOverrides.add(enable);
			enable.setOnCheckedChangeListener(ListenerEnable);

			slider.set(value);
			chSliders.get(i).getSeekBar().setId(i + 1);
			/*
			chSliders.get(i).getSeekBar()
					.setOnSeekBarChangeListener(
							new SeekBar.OnSeekBarChangeListener() {

								@Override
								public void onStopTrackingTouch(SeekBar seekBar) {
									// not used
								}

								@Override
								public void onStartTrackingTouch(SeekBar seekBar) {
									// not used
								}

								@Override
								public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
									if ( isTesting ) {
										int id = seekBar.getId();
										int val = seekBar.getProgress();
										TimerService.periodicChannelData.setChannel(id, val + ChannelSettingsActivity.CHANNEL_MIN_US);
									}

								}
							});
			*/
			slider.setEnabled(isEnabled);
			enable.setChecked(isEnabled);
		}
	}
	
	
	/*
	private void initConnection(String name, String ip) {
		// start PSD thread
		psdThread = new PeriodicStatusDataThread(this);
		new Thread(psdThread).start();

		try {
			controlThread = new ControlThread();
			controlThread.connect(ip, ControlThread.CONTROL_PORT);
			displayToast(String.format("Connected to %s", name));
			new Thread(controlThread).start();
			// send TL
			SharedPreferences prefs = getSharedPreferences(
					"TransmitterSettings", 0);
			String trName = prefs.getString(SettingsActivity.KEY_TR_NAME,
					SettingsActivity.DEFAULT_TRANSMITTER_NAME);
			int trPriority = prefs.getInt(SettingsActivity.KEY_TR_PRIO, 0);

			TransmitterLoginMessage tl = new TransmitterLoginMessage((byte) 2,
					(byte) 0, (byte) 1, (byte) trPriority, trName,
					psdThread.getPSDPort());
			controlThread.sendMsg(tl);

			// send DCFG
			DeviceConfigurationMessage dcfg = new DeviceConfigurationMessage(
					name, (short) 0, (short) 0);
			controlThread.sendMsg(dcfg);

			// send CCFG
			Cursor cfgs = dbHelper.getChannelsTable().fechChannelsByProfile(
					dbHelper.getProfilesTable().getActiveProfileId());

			// send CCFG and FCFG
			ChannelConfigurationMessage ccfg = new ChannelConfigurationMessage();
			FailsafeConfigurationMessage fcfg = new FailsafeConfigurationMessage();
			for (int i = 0; i < cfgs.getCount(); i++) {
				ccfg.putValue(
						(short) i,
						(short) cfgs.getInt(cfgs
								.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_REPEAT_FQ)));
				int failsafeMode = cfgs
						.getInt(cfgs
								.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_FAILSAFE_MODE));
				if (failsafeMode == ChannelSettingsActivity.FAILSAFE_DISABLE) {
					fcfg.putValue((short) i, (short) 0x0000);
				} else if (failsafeMode == ChannelSettingsActivity.FAILSAFE_LAST_GOOD) {
					fcfg.putValue((short) i, (short) 0xFFFF);
				} else {
					fcfg.putValue(
							(short) i,
							(short) cfgs.getInt(cfgs
									.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_FAILSAFE_PRESET)));
				}
				cfgs.moveToNext();
			}
			ccfg.assemble();
			controlThread.sendMsg(ccfg);
			fcfg.assemble();
			controlThread.sendMsg(fcfg);

			// wait for WST
			if (null == controlThread.getWrcdStartupMessage()) {
				synchronized (controlThread.wst_wait) {
					controlThread.wst_wait.wait();
				}
			}

			// start PCD thread
			pcdThread = new PeriodicChannelDataThread(ip, controlThread
					.getWrcdStartupMessage().getPCDPort(), (short) 1500);
			controlThread.setPCD(pcdThread);
			new Thread(pcdThread).start();
			pcdThread.setHasDeviceControl(true);

		} catch (Exception e) {
			displayToast(String.format("Connecting to %s:%d - %s", ip,
					ControlThread.CONTROL_PORT, e.toString()));
		}
	}
	*/

	@Override
	public void onResume() {
		super.onResume();
		/*
		if (null != controlThread) {
			try {
				controlThread.disconnect();
				controlThread.exit();
			} catch (IOException e) {

			}
		}
		SharedPreferences prefs = getSharedPreferences("WrcInfo", 0);
		wrcName = prefs.getString("wrcName", null);
		wrcIp = prefs.getString("wrcIp", null);
		if (wrcIp == null || wrcName == null) {
			toggleTest.setEnabled(false);
			displayToast("No connection for testing...\n Test Settings button is disabled");
		} else {
			initConnection(wrcName, wrcIp);
		}
		*/
	}

	@Override
	public void onPause() {
		super.onPause();
		try {
			/*
			controlThread.disconnect();
			controlThread.exit();
			pcdThread.exit();
			psdThread.exit();
			*/
		} catch (Exception e) {
			displayToast(String.format("Disconnecting - %s", e.toString()));
		}
	}

	@Override
	public void onStop() {
		super.onStop();

		// save preference file
		for (int i = 0; i < ChannelInfo.CHANNELS; ++i) {
			TimerService.dbHelper.getManeuversTable().updateManeuver(i + 1, manIdx,
					chSliders.get(i).get(), chOverrides.get(i).isChecked(),
					profileId);
		}
	}

	private OnCheckedChangeListener ListenerEnable = new OnCheckedChangeListener() {

		@Override
		public void onCheckedChanged(CompoundButton buttonView,	boolean isChecked) {
			/* find ID */
			CheckBox cb = (CheckBox) buttonView;
			int i;
			for (i = 0; i < chOverrides.size(); ++i) {
				if (cb == chOverrides.get(i))
					break;
			}
			if (i < chSliders.size()) {
				chSliders.get(i).setEnabled(isChecked);
			}
		}
	};

	public static final String KEY_PREFS_MANEUVER(int index) {
		return String.format("maneuver%d_settings", index);
	}

	public static String KEY_MANEUVER_ENABLE(int index) {
		return String.format("maneuver_enable%d", index);
	}

	public static String KEY_MANEUVER_VALUE(int index) {
		return String.format("maneuver_value%d", index);
	}

	private void displayToast(String msg) {
		Toast.makeText(getBaseContext(), msg, Toast.LENGTH_SHORT).show();
	}
}
