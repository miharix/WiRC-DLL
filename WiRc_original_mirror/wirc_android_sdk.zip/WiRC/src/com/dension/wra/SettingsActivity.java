package com.dension.wra;

import com.dension.wra.profile.ProfileListSettingsActivity;

import settings.GeneralPreferencesActivity;
import wra.com.PlayerActivity;
import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

public class SettingsActivity extends ListActivity {
	private static final int TRANSMITTER = 0;
	private static final int CHANNELS = 1;
	private static final int CONTROLS = 2;
	private static final int MANEUVER = 3;
	private static final int WIRC = 4;
	private static final int PROFILES = 5;
	private static final int VIDEOS = 6;
	/*
	private static final int MIN_PRIORITY = 0;
	private static final int MAX_PRIORITY = 255;
	*/

	public static final String KEY_TR_NAME = "transmitter_name";
	public static final String KEY_TR_PRIO = "transmitter_prio";
	public static final String DEFAULT_TRANSMITTER_NAME = "My Android";
	
	private Context context;
	
	private static final String[] mSettingItems = new String[] {
			"General Settings", "Channels", "Controls", "Maneuver",
			"WiRC settings", "Profiles", "Videos" };

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		context = this.getApplicationContext();
		
		setTitle("Dension RC Settings");
		setListAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, mSettingItems));
		getListView().setOnItemClickListener(itemClickListener);
	}

	/*
	private void DisplayToast(String msg) {
		Toast.makeText(getBaseContext(), msg, Toast.LENGTH_SHORT).show();
	}
	*/

	private AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> parent, View v, int position,
				long id) {
			switch (position) {
			case TRANSMITTER:
				Intent newIntent = new Intent(context,	GeneralPreferencesActivity.class);
				startActivity(newIntent);
				break;
			case CHANNELS:
				startChannelList();
				break;
			case CONTROLS:
				startControlList();
				break;
			case MANEUVER:
				startManeuverList();
				break;
			case WIRC:
				startWiRC();
				break;
			case PROFILES:
				startProfiles();
				break;
			case VIDEOS:
				startPlayer();
				break;
			}
		}
	};

	private void startChannelList() {
		Intent newIntent = new Intent(this.getApplicationContext(),	ChannelListSettingsActivity.class);
		startActivity(newIntent);
	}

	private void startControlList() {
		Intent newIntent = new Intent(this.getApplicationContext(),	ControlListSettingsActivity.class);
		startActivity(newIntent);
	}

	private void startManeuverList() {
		Intent newIntent = new Intent(this.getApplicationContext(),	ManeuverListSettings.class);
		startActivity(newIntent);
	}
	
	private void startWiRC() {
		Intent newIntent = new Intent(this.getApplicationContext(),	WiRCSettingsActivity.class);
		startActivity(newIntent);
	}
	
	private void startPlayer() {
		Intent newIntent = new Intent(this.getApplicationContext(),	PlayerActivity.class);
		startActivity(newIntent);
	}

	private void startProfiles() {
		Intent newIntent = new Intent(this.getApplicationContext(),	ProfileListSettingsActivity.class);
		startActivity(newIntent);
	}

	/*
	private void dialogTransmitterSettings() {
		LayoutInflater li = getLayoutInflater();
		final View v = li.inflate(R.layout.transmitter_settings_dialog, null);
		AlertDialog.Builder dialog = new AlertDialog.Builder(this);
		dialog.setView(v);
		final EditText editTrName = (EditText) v.findViewById(R.id.editTrName);
		final EditText editTrPrio = (EditText) v.findViewById(R.id.editTrPrio);
		dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				SharedPreferences prefs = getSharedPreferences(
						"TransmitterSettings", 0);
				SharedPreferences.Editor editor = prefs.edit();

				editor.putString(KEY_TR_NAME, editTrName.getText().toString());
				int prio;
				try {
					prio = Integer.parseInt(editTrPrio.getText().toString());
				} catch (Exception e) {
					prio = MIN_PRIORITY;
				}
				// range check
				if (prio < MIN_PRIORITY)
					prio = MIN_PRIORITY;
				if (prio > MAX_PRIORITY)
					prio = MAX_PRIORITY;

				editor.putInt(KEY_TR_PRIO, prio);

				editor.commit();
			}
		});

		SharedPreferences prefs = getSharedPreferences("TransmitterSettings", 0);
		String name = prefs.getString(KEY_TR_NAME, DEFAULT_TRANSMITTER_NAME);
		int prio = prefs.getInt(KEY_TR_PRIO, 0);

		editTrName.setText(name);
		editTrPrio.setText(Integer.toString(prio));

		dialog.show();
	}
	*/

}
