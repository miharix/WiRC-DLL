package com.dension.wra;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

public class ControlListSettingsActivity extends ListActivity {
	private static final String[] items = new String[] { "Mode 1", "Mode 2",
			"Mode 3", "Mode 4", };

	private static final String TITLE = "Control Settings";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setTitle(TITLE);

		setListAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, items));
		getListView().setOnItemClickListener(ListenerItemClick);
	}

	private AdapterView.OnItemClickListener ListenerItemClick = new AdapterView.OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> parent, View v, int position,
				long id) {
			startControlMenu(position + 1);
		}
	};

	private void startControlMenu(int index) {
		Bundle bundle = new Bundle();
		bundle.putInt(ControlSettingsActivity.KEY_BUNDLE_MODE_INDEX, index);

		Intent newIntent = new Intent(this.getApplicationContext(),
				ControlSettingsActivity.class);
		newIntent.putExtras(bundle);
		startActivity(newIntent);
	}
}
