package com.dension.wra;

import wirc.dension.com.R;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class SliderView extends LinearLayout {
	private Button plusButton;
	private Button minusButton;
	private TextView textView;
	private SeekBar seekBar;

	public SeekBar getSeekBar() {
		return seekBar;
	}

	private int value;
	private int minValue;
	private int maxValue;
	private SliderHandler sliderHandler;

	public SliderView(Context context, AttributeSet attributes) {
		super(context, attributes);
		init(context, attributes);
	}

	private void init(Context context, AttributeSet attributes) {
		LinearLayout compoundView;

		LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		compoundView = (LinearLayout) inflater.inflate(R.layout.slider, this);

		value = 0;
		minValue = 0;
		maxValue = 100;

		plusButton = (Button) compoundView.findViewById(R.id.ButtonPlus);
		minusButton = (Button) compoundView.findViewById(R.id.ButtonMinus);
		seekBar = (SeekBar) compoundView.findViewById(R.id.SliderBar);
		textView = (TextView) compoundView.findViewById(R.id.TextValue);

		plusButton.setOnClickListener(ListenerPlus);
		minusButton.setOnClickListener(ListenerMinus);
		seekBar.setOnSeekBarChangeListener(ListenerSlider);

		sliderHandler = new SliderHandler();
	}

	private void updateValue() {
		value = sliderHandler.onChanged(value);

		textView.setText(sliderHandler.toString(value));

		seekBar.setProgress(value - minValue);
	}

	private View.OnClickListener ListenerMinus = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			if (value > minValue)
				value--;

			updateValue();
		}
	};

	private View.OnClickListener ListenerPlus = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			if (value < maxValue)
				value++;

			updateValue();
		}
	};

	private SeekBar.OnSeekBarChangeListener ListenerSlider = new SeekBar.OnSeekBarChangeListener() {

		@Override
		public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
			if (fromUser) {
				value = progressToValue(progress);

				updateValue();
			}
		}

		@Override
		public void onStartTrackingTouch(SeekBar seekBar) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onStopTrackingTouch(SeekBar seekBar) {
			// TODO Auto-generated method stub

		}
	};

	private int progressToValue(int progress) {
		return progress + minValue;
	}

	public void setHandler(SliderHandler handler) {
		sliderHandler = handler;
	}

	public void setRange(int min, int max) {
		minValue = min;
		maxValue = max;
		seekBar.setMax(max - min);
	}

	public void set(int value) {
		if (value < minValue)
			value = minValue;
		if (value > maxValue)
			value = maxValue;

		this.value = value;
		updateValue();
	}

	public int get() {
		return value;
	}

	@Override
	public void setEnabled(boolean enabled) {
		seekBar.setEnabled(enabled);
		minusButton.setEnabled(enabled);
		plusButton.setEnabled(enabled);
	}
}
