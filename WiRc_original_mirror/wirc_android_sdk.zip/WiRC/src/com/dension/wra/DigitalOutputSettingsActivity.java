package com.dension.wra;

import wirc.dension.com.R;
import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.CheckBox;

import com.dension.sqliteaccess.WircDbAdapter;

public class DigitalOutputSettingsActivity extends Activity {

	private CheckBox isInverted;
	private SliderView sliderMin;
	private SliderView sliderMax;
	private int channelNum;
	private WircDbAdapter dbHelper;
	private int rowId;
	private String name;
	private int profileIdx;
	private Cursor settings;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		dbHelper = new WircDbAdapter(this);
		dbHelper.open();
		Bundle bundle = this.getIntent().getExtras();
		channelNum = bundle.getInt(ChannelSettingsActivity.KEY_BUNDLE_INDEX);
		if (channelNum < 1)
			channelNum = 1;
		if (channelNum > 4)
			channelNum = 4;
		getSettings();
		setContentView(R.layout.digital_settings);
		SliderHandler handler;

		setTitle(String.format("Digital output %d settings", channelNum));

		// check box invert
		isInverted = (CheckBox) findViewById(R.id.CheckBoxInvert);

		sliderMin = (SliderView) findViewById(R.id.SliderOnRangeLow);
		sliderMin.setRange(ChannelSettingsActivity.CHANNEL_MIN_US,
				ChannelSettingsActivity.CHANNEL_MAX_US);
		handler = new SliderHandler() {
			@Override
			public String toString(int value) {
				return ChannelSettingsActivity.convertToDispUs(value);
			}
		};
		sliderMin.setHandler(handler);

		sliderMax = (SliderView) findViewById(R.id.SliderOnRangeHigh);
		sliderMax.setRange(ChannelSettingsActivity.CHANNEL_MIN_US,
				ChannelSettingsActivity.CHANNEL_MAX_US);
		handler = new SliderHandler() {
			@Override
			public String toString(int value) {
				return ChannelSettingsActivity.convertToDispUs(value);
			}
		};
		sliderMax.setHandler(handler);

		// filling from settings
		try {
			isInverted
					.setChecked(settings.getInt(settings
							.getColumnIndexOrThrow(WircDbAdapter.DigitalChannelsTable.KEY_INVERT_OUTPUT)) == 1 ? true
							: false);
			sliderMin
					.set(settings.getInt(settings
							.getColumnIndexOrThrow(WircDbAdapter.DigitalChannelsTable.KEY_MIN_VALUE)));
			sliderMax
					.set(settings.getInt(settings
							.getColumnIndexOrThrow(WircDbAdapter.DigitalChannelsTable.KEY_MAX_VALUE)));
		} catch (Exception e) {
		
		}
	}

	@Override
	public void onStop() {
		super.onStop();
		saveSettings();
	}

	public void getSettings() {
		settings = dbHelper.getDigitalChannelsTable().fetchDigitalChannel(
				channelNum, dbHelper.getProfilesTable().getActiveProfileId());
		profileIdx = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.DigitalChannelsTable.KEY_PROFILE_ID));
		rowId = settings
				.getInt(settings
						.getColumnIndexOrThrow(WircDbAdapter.DigitalChannelsTable.KEY_ROWID));
		name = settings
				.getString(settings
						.getColumnIndexOrThrow(WircDbAdapter.DigitalChannelsTable.KEY_NAME));
	}

	public void saveSettings() {
		dbHelper.getDigitalChannelsTable().updateDigitalChannel((long) rowId,
				name, channelNum, isInverted.isChecked() ? 1 : 0,
				sliderMin.get(), sliderMax.get(), profileIdx);
	}

	public static String KEY_DIG_INVERT(int index) {
		return String.format("digitalout%d_invert", index);
	}

	public static String KEY_DIG_LOWLIM(int index) {
		return String.format("digitalout%d_lowlim", index);
	}

	public static String KEY_DIG_HIGHLIM(int index) {
		return String.format("digitalout%d_highlim", index);
	}
}
