package com.dension.wra;

import channel.ChannelInfo;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

public class ChannelListSettingsActivity extends ListActivity {
	private static final String MENU_TITLE = "Dension RC Settings";
	private String[] items;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// creating channel items
		int channelCount = ChannelInfo.CHANNELS + ChannelInfo.DIGITAL_CHANNELS;
		items = new String[channelCount];
		int i;
		for (i = 0; i < ChannelInfo.CHANNELS; i++) {
			items[i] = "Channel " + (i + 1);
		}
		items[0] = "Steering";
		items[1] = "Speed";
		for (int j = 0; j < ChannelInfo.DIGITAL_CHANNELS; j++) {
			items[i] = "Digital Channel " + (j + 1);
			i++;
		}
		setTitle(MENU_TITLE);
		setListAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, items));
		getListView().setOnItemClickListener(itemClickListener);
	}

	private AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> parent, View v, int position,
				long id) {
			if (position < ChannelInfo.CHANNELS) {
				int idx = position + 1;
				startChannelSettingsMenu(idx);
			} else {
				int idx = position - (ChannelInfo.CHANNELS - 1);
				startDigitalSettingsMenu(idx);
			}
		}
	};

	private void startChannelSettingsMenu(int index) {
		Bundle bundle = new Bundle();
		bundle.putInt(ChannelSettingsActivity.KEY_BUNDLE_INDEX, index);

		Intent newIntent = new Intent(this.getApplicationContext(),
				ChannelSettingsActivity.class);
		newIntent.putExtras(bundle);
		startActivity(newIntent);
	}

	private void startDigitalSettingsMenu(int index) {
		Bundle bundle = new Bundle();
		bundle.putInt(ChannelSettingsActivity.KEY_BUNDLE_INDEX, index);

		Intent newIntent = new Intent(this.getApplicationContext(),
				DigitalOutputSettingsActivity.class);
		newIntent.putExtras(bundle);
		startActivity(newIntent);
	}
}
