package com.dension.wra;

public class SliderHandler {
	public int onChanged(int value) {
		return value;
	}
	
	public String toString(int value) {
		return String.format("%d", value);
	}
}
