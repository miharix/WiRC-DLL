package com.dension.wra;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

public class ManeuverListSettings extends ListActivity {
	private static final String[] mSettingItems = new String[] {
		"Maneuver 1",
		"Maneuver 2",
	};
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setTitle("Dension RC Settings");
        setListAdapter(new ArrayAdapter<String>(this,
        		android.R.layout.simple_list_item_1, mSettingItems));
        getListView().setOnItemClickListener(ListenerItemClick);
    }

	private AdapterView.OnItemClickListener ListenerItemClick = new AdapterView.OnItemClickListener() {
		@Override
        public void onItemClick(AdapterView<?> parent, View v, 
        						int position, long id) {
			if(position < 8)
				startManeuverMenu(position+1);
		}
	};
	
	private void startManeuverMenu(int index) {
		Bundle bundle =new Bundle();
		bundle.putInt(ManeuverSettingsActivity.KEY_MANEUVER_BUNDLE_INDEX, index);
		
		Intent newIntent = new Intent(this.getApplicationContext(), ManeuverSettingsActivity.class);
		newIntent.putExtras(bundle);
		startActivity(newIntent);
	}
}
