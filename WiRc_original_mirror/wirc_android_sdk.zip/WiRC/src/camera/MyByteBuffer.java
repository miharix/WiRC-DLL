package camera;

import java.nio.BufferUnderflowException;

import develop.Notify;

public class MyByteBuffer {
	private byte l_buf[];
	private int l_length;
	private int l_position;
	
	MyByteBuffer() {
		l_buf = null;
		l_length = 0;
		l_position = 0;
	}
	
	public void setBuf(byte p_buf[], int p_len) {
		l_length = p_len;
		l_buf = p_buf;
		l_position = 0;
	}
	
	public int getInt() {
		int result;
		/*
		if(l_position + 4 > l_length)
			throw new BufferUnderflowException();
		*/
		
		result  = ((l_buf[l_position++] << 24) & 0xFF000000);
		result |= ((l_buf[l_position++] << 16) & 0x00FF0000);
		result |= ((l_buf[l_position++] << 8)  & 0x0000FF00);
		result |= ((l_buf[l_position++])       & 0x000000FF);
		
		return result;
	}
	
	public Boolean get(byte p_buf_dst[], int p_offset_dst, int p_len) {
		Boolean success = false;
		
		if(l_position + p_len > l_length) {
			// Notify.e(this, "" + l_position + " " + p_len + " " + l_length);
		}
		else {
			success = true;
		}
		for(int i = 0; i < p_len; ++i) {
			p_buf_dst[i+p_offset_dst] = l_buf[l_position++]; 
		}

		return success;
	}
}
