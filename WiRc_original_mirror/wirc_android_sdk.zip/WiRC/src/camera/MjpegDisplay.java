package camera;

import develop.Notify;
import over.TimerService;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.Display;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;

public class MjpegDisplay extends SurfaceView implements SurfaceHolder.Callback {
	private SurfaceHolder l_surface_holder;
	private Rect l_rect_img;
	private Paint l_paint_img;
	private int l_display_width;
	private int l_display_height;
	private int screenW;
	private int screenH;
	private int streamW = 352;
	private int streamH = 288;
	private int bitmapLeft, bitmapRight, bitmapTop, bitmapBottom;
	private float displayCamera = (float) 352 / 288;
	private float zoom = 1;
	
	public boolean useOriginalRatio = false;

	public MjpegDisplay(Context context) {
		super(context);
		init(context);
	}

	public MjpegDisplay(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
	}

	public MjpegDisplay(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init(context);
	}

	private void init(Context context) {
		/*
		if ( l_surface_holder != null ) {
			l_surface_holder = getHolder();
			l_surface_holder.addCallback(this);
			Display display = ((Activity) context).getWindowManager()
					.getDefaultDisplay();
			l_display_width = display.getWidth();
			l_display_height = display.getHeight();
			l_rect_img = null;
			l_paint_img = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
		}
		*/
		
		this.getViewTreeObserver().addOnGlobalLayoutListener(onGlobalLayoutListener);
	}
	
	private OnGlobalLayoutListener onGlobalLayoutListener = new OnGlobalLayoutListener() {
		@Override
		public void onGlobalLayout() {
			screenW = MjpegDisplay.this.getMeasuredWidth();
			screenH = MjpegDisplay.this.getMeasuredHeight();
			l_display_width = screenW;
			l_display_height = screenH;
			
			if ( (screenW > 0) && (screenH > 0) ) {
				float displayRatio = 1;
				if ( useOriginalRatio ) {
					displayRatio = displayCamera;
				}
				else {
					
				}
				
				float zoomRatio = (float) screenW / (float) streamW;
				l_display_width = screenW;
				l_display_height = (int) (streamH * zoomRatio);
				
				bitmapLeft = 0; 
				bitmapTop = 0;
				bitmapRight = l_display_width;
				bitmapBottom = l_display_height;
				
				/*
				Notify.d(this, "*** 1", displayCamera, zoomRatio, zoom, screenW, screenH);
				Notify.d(this, "*** 2", displayCamera, zoomRatio, zoom, l_display_width, l_display_height);
				*/
			}
		}
	};
	
	@Override
	public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		
		try {
			l_surface_holder = getHolder();
			
			if ( (l_surface_holder != null) && (TimerService.displayMetrics != null) ) {
				l_surface_holder.addCallback(this);
				/*
				l_display_width = this.getMeasuredWidth();
				l_display_height = this.getMeasuredHeight();
				*/
				// Notify.d(this, getMeasuredWidth(), getMeasuredHeight());
				
				l_rect_img = null;
				l_paint_img = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
				
				/*
				if ( (l_display_width > 0) && (l_display_height > 0) ) {
					bitmapLeft = (screenW - l_display_width) / 2;
					bitmapTop = (screenH - l_display_height) / 2;
					bitmapRight = bitmapLeft + l_display_width;
					bitmapBottom = bitmapTop + l_display_height;
				}
				*/
			}
		}
		catch (Throwable e) {
			Notify.e(this, "onMeasure", e.toString());
		}
			
	}

	@Override
	public void surfaceChanged(SurfaceHolder p_holder, int p_format,
			int p_width, int p_height) {
		// TODO Auto-generated method stub

	}

	@Override
	public void surfaceCreated(SurfaceHolder p_holder) {
		// TODO Auto-generated method stub

	}

	@Override
	public void surfaceDestroyed(SurfaceHolder p_holder) {
		// TODO Auto-generated method stub

	}

	public void setImg(Bitmap p_bm) {
		Canvas imgCanvas = null;
		if (null == l_rect_img) {
			/*
			bitmapLeft = 0;
			bitmpaTop = 0;
			bitmapRight = l_display_width;
			bitmapBottom = l_display_height;
			*/

			l_rect_img = new Rect(bitmapLeft, bitmapTop, bitmapRight, bitmapBottom);
		}
		try {
			imgCanvas = l_surface_holder.lockCanvas();
			synchronized (l_surface_holder) {
				l_rect_img.set(bitmapLeft, bitmapTop, bitmapRight, bitmapBottom);
				// imgCanvas.drawColor(Color.BLACK);
				imgCanvas.drawBitmap(p_bm, null, l_rect_img, l_paint_img);
			}
		} 
		catch (Exception e) {

		} 
		finally {
			if (null != imgCanvas)
				l_surface_holder.unlockCanvasAndPost(imgCanvas);
		}
	}

	@Override
	public boolean isInEditMode() {
		return false;
	}
}
