package camera;

import java.io.FileInputStream;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import develop.Notify;

public class Player {
	
	private MjpegDisplay mjpegDisplay;
	private FileInputStream fileInputStream;
	private BitmapFactory.Options l_bmf_options;
	
	private int frameSize = 100000;
	
	public Boolean onTask = false;

	public Player(MjpegDisplay mjpegDisplay, String rootPath) {
		this.mjpegDisplay = mjpegDisplay;
		
		this.mjpegDisplay.useOriginalRatio = true;
		l_bmf_options = new BitmapFactory.Options();
		l_bmf_options.inTempStorage = new byte[128 * 1024];
		l_bmf_options.inDither = true;
		l_bmf_options.inPreferredConfig = Bitmap.Config.RGB_565;
		l_bmf_options.inSampleSize = 3;
	}
	
	public Bitmap getFirstFrame(String fileName) {
		Bitmap bitmap = null;
		
		try {
			byte[] buffer = new byte[frameSize];
			int count = 0;
			FileInputStream fileInputStream = new FileInputStream(fileName);
			count = fileInputStream.read(buffer, 0, frameSize);
			if ( count > 0 ) {
				bitmap = BitmapFactory.decodeByteArray(buffer, 0, frameSize, l_bmf_options);
			}
			fileInputStream.close();
		}
		catch (Throwable e) {
			Notify.e(this, e.toString());
		}
		
		return bitmap;
	}
	
	public void showFirstFrame(String fileName) {
		try {
			Bitmap bitmap = getFirstFrame(fileName);
			mjpegDisplay.setImg(bitmap);
		}
		catch (Throwable e) {
			Notify.e(this, e.toString());
		}
		
	}
	
	public void start(String fileName) {
		if ( ! onTask ) {
			fileInputStream = null;
			try {
				fileInputStream = new FileInputStream(fileName);
			} 
			catch (Throwable e) {
				Notify.e(this, "start " + e.toString());
			}
			
			if ( fileInputStream != null ) {
				onTask = true;
				new PlayTask().execute();
			}
		}
	}
	
	public void stop() {
		onTask = false;
		if ( fileInputStream != null ) {
			try {
				fileInputStream.close();
			} 
			catch (Throwable e) {
				Notify.e(this, "stop " + e.toString());
			}
		}
	}
	
	private class PlayTask extends AsyncTask<Void, Void, Void> {
		Bitmap bitmap;

		@Override
		protected Void doInBackground(Void... arg0) {
			byte[] buffer = new byte[frameSize];
			int count = 0;
			while ( onTask ) {
				try {
					count = fileInputStream.read(buffer, 0, frameSize);
					if ( count > 0 ) {
						Notify.d(this, "" + count);
						
						bitmap = BitmapFactory.decodeByteArray(buffer, 0, frameSize, l_bmf_options);
						mjpegDisplay.setImg(bitmap);
						Thread.sleep(1000 / 25);
					}
					else {
						stop();
					}
				}
				catch (Throwable e) {
					Notify.e(this, "PlayTask " + e.toString());
				}
			}
			
			buffer = new byte[frameSize];
			bitmap = BitmapFactory.decodeByteArray(buffer, 0, frameSize, l_bmf_options);
			mjpegDisplay.setImg(bitmap);
			
			return null;
		}
		
	}

}
