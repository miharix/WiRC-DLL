package camera;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.channels.DatagramChannel;

import over.TimerService;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import develop.Notify;

public class CameraStream implements Runnable {
	private static final int SIZE = 256;
	private static final int L_U32_HEADER_SIZE = 4 * 4;
	private static final int L_U32_MAX_DATA = 512 * SIZE;
	private static final int L_U32_MAX_IMG_SIZE = 100000;

	private static final int BUFFER_SIZE = L_U32_HEADER_SIZE + L_U32_MAX_IMG_SIZE;

	private static final int L_U32_VERSION = 0x00005503;
	private static final int L_BIT_LAST = 1;
	@SuppressWarnings("unused")
	private static final int L_U32_LAST = ((L_BIT_LAST << 16) | L_U32_VERSION);

	private boolean l_b_running, is_image_ready;

	private DatagramSocket datagramSocket;
	private double l_f32_fps;
	private byte image_select_write;
	private int image_complete_len, image_expected_offset,
			image_expected_framenum;
	private byte[][] l_au8_image;
	private MjpegDisplay display;
	private BitmapFactory.Options l_bmf_options;
	private Bitmap l_bm_image;
	@SuppressWarnings("unused")
	private DatagramChannel l_fd_channel;

	private TimerService service;

	public CameraStream(TimerService timerService, MjpegDisplay p_view) {
		this.service = timerService;

		try {
			datagramSocket = new DatagramSocket();
			datagramSocket.setReceiveBufferSize(BUFFER_SIZE);
			// Notify.d(this, "" + datagramSocket.getInetAddress().toString());			
		} catch (Throwable e) {
			Notify.e(this, "run() " + e.toString());
		}

		try {

			datagramSocket.setSoTimeout(10);

		} catch (Throwable e) {
			Notify.e(this, e.toString());
		}
		l_f32_fps = 0;

		l_au8_image = new byte[2][L_U32_MAX_IMG_SIZE];

		display = p_view;
		l_bmf_options = new BitmapFactory.Options();
		l_bmf_options.inTempStorage = new byte[L_U32_MAX_IMG_SIZE];
		l_bmf_options.inDither = true;
		l_bmf_options.inPreferredConfig = Bitmap.Config.RGB_565;
		l_bmf_options.inSampleSize = timerService.cameraQuality;

		l_b_running = true;
	}

	@Override
	public void run() {

		byte au8_buffer[] = new byte[BUFFER_SIZE];
		DatagramPacket packet = new DatagramPacket(au8_buffer, au8_buffer.length);
		while (l_b_running) {
			try {
				packet.setLength(BUFFER_SIZE);
				datagramSocket.receive(packet);
				handlePacket(packet.getData(), packet.getLength());
			} catch (Exception e) {
				put_image();
				// Notify.d(this, "run " + e.toString());
			}
		}
	}

	private void put_image() {
		if (is_image_ready) {
			byte select = image_select_write;
			if (select == 1)
				select = 0;
			else
				select = 1;
			l_bm_image = BitmapFactory.decodeByteArray(l_au8_image[select], 0, image_complete_len, l_bmf_options);
			display.setImg(l_bm_image);
			TimerService.recorder.addFrame(l_au8_image[select]);
			is_image_ready = false;
		}
	}

	private void handlePacket(byte p_au8_packet[], int p_packet_len) {
		int version;
		int frame_num, offset, length, img_len, exp_len;
		Boolean success;
		MyByteBuffer packet = new MyByteBuffer();

		packet.setBuf(p_au8_packet, p_packet_len);
		if (p_packet_len < L_U32_HEADER_SIZE) {
			put_image();
			return;
		}
		version = packet.getInt();
		frame_num = packet.getInt();
		offset = packet.getInt();
		length = packet.getInt();

		if (!isVersion(version) || (length <= 0))
			return;

		exp_len = p_packet_len - L_U32_HEADER_SIZE;
		if (length != exp_len)
			return;

		if (offset != image_expected_offset) {
			image_expected_framenum = frame_num + 1;
			image_expected_offset = 0;
			return;
		}
		if ((frame_num > image_expected_framenum) && (offset != 0)) {
			image_expected_framenum = frame_num + 1;
			image_expected_offset = 0;
			return;
		}

		img_len = offset + length;
		if (img_len > L_U32_MAX_IMG_SIZE) {
			Notify.e(this, "L_U32_MAX_IMG_SIZE");
			return;
		}

		success = packet.get(l_au8_image[image_select_write], offset, length);

		if (success) {
			if (isLast(version)) {
				image_expected_offset = 0;
				image_expected_framenum = frame_num + 1;
				image_complete_len = img_len;
				is_image_ready = true;
				if (image_select_write == 1)
					image_select_write = 0;
				else
					image_select_write = 1;
			} else {
				image_expected_offset = img_len;
			}
		} else {
			Notify.e(this, "isLast");
		}
	}

	private boolean isVersion(int p_u32_version) {
		return (getVersion(p_u32_version) == L_U32_VERSION);
	}

	private int getVersion(int p_u32_version) {
		return (p_u32_version & 0x0000FFFF);
	}

	private boolean isLast(int p_u32_version) {
		return (0 != (((p_u32_version >> 16) & 0x0000FFFF) & L_BIT_LAST));
	}

	public short getPort() {
		return (short) (datagramSocket.getLocalPort());
	}

	public double getFPS() {
		return l_f32_fps;
	}

	public void exit() {
		l_b_running = false;
		is_image_ready = false;
		image_expected_offset = 0;
	}
}
