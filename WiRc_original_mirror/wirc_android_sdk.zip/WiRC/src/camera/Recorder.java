// http://stackoverflow.com/questions/3205191/android-and-mjpeg
package camera;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Date;

import over.TimerService;
import android.text.format.DateFormat;
import develop.Notify;


public class Recorder {
	
	private TimerService service;
	private FileOutputStream fileOutputStream;
	
	private String fullPath = "";
	private boolean capture = false;
	
	public Recorder(TimerService timerService, String rootPath) {
		this.service = timerService;
		if ( service.externalStorage.isReady() ) {
			fullPath = service.externalStorage.getAbsolutePath() + "/" + rootPath;
			service.externalStorage.mkdirs(fullPath);
		}
	}
	
	public Boolean start(boolean capture) {
		Boolean started = false;
		this.capture = capture;
		
		try {
			if ( service.externalStorage.isReady() ) {
				Notify.d(this, "start");

				String fileName = (String) DateFormat.format("yyyy-MM-dd hh.mm.ss", new Date());
				fileName = fullPath + fileName;
				if ( capture ) {
					fileName =  fileName + ".jpg";
				}
				else {
					fileName =  fileName + ".mjpeg";
				}
				service.externalStorage.createFile(fileName);
				File file = new File(fileName);
				fileOutputStream = new FileOutputStream(file);
				started = true;
			}
			
		}
		catch (Throwable e) {
			Notify.e(this, "start " + e.toString());
		}

		return started;
	}
	
	public void stop() {
		try {
			if ( fileOutputStream != null ) {
				Notify.d(this, "stop");
				
				fileOutputStream.flush();
				fileOutputStream.close();
				fileOutputStream = null;
			}
		}
		catch (Throwable e) {
			
		}
	}
	
	public void addFrame(byte[] image) {
		if ( TimerService.record ) {
			try {
				fileOutputStream.write(image);
			}
			catch (Throwable e) {
				Notify.e(this, "addFrame record " + e.toString());
			}
			if ( capture ) {
				TimerService.record = false;
				stop();
			}
		}
		
		/*
		if ( service._capture() ) {
			try {
				TimerService.capture = false;
				Notify.d(this, "capture");
			}
			catch (Throwable e) {
				Notify.e(this, "addFrame capture" + e.toString());
			}
		}
		*/
	}

}
