package gui;

import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import develop.Notify;

public class Gui {
	
	public static View findTouch(ViewGroup viewGroup, int l, int t) {
		View result = null;
		
		try {
			for ( int i = 0; i < viewGroup.getChildCount(); i++) {
				View view = viewGroup.getChildAt(i);
				if ( view.getVisibility() == View.VISIBLE ) {
					int location[] = new int[2];
					view.getLocationOnScreen(location);
					int x1 = location[0];
					int y1 = location[1];
					int x2 = location[0] + view.getRight() - view.getLeft();
					int y2 = location[1] + view.getBottom() - view.getTop();
					Rect rect = new Rect(x1, y1, x2, y2);
					if ( rect.contains(l, t) ) {
						result = view;
					}
					ViewGroup viewGroupChild = null;
					try {
						viewGroupChild = (ViewGroup) viewGroup.getChildAt(i);
					}
					catch (Throwable e) {
					}
					if ( viewGroupChild != null ) {
						View resultUnder = findTouch(viewGroupChild, l, t);
						if ( resultUnder != null )
							result = resultUnder;
					}
				}
			}
		}
		catch (Throwable e) {
			Notify.e(Gui.class, e.toString());
		}
			
		
		return result;
	}
	
	public static void setButtonEnable(ImageButton button, Boolean enabled) {
		if ( enabled ) 
			button.setAlpha(255);
		else
			button.setAlpha(70);
		button.setEnabled(enabled);
	}
	
	public static Boolean setButtonOnOff(ImageButton imageButton, int resource_on, int resource_off) {
		Boolean on = false;
		
		if ( imageButton.getTag() != null ) {
			if ( imageButton.getTag().equals("off") ) {
				imageButton.setImageResource(resource_on);
				imageButton.setTag("on");
				on = true;
			}
			else
				if ( imageButton.getTag().equals("on") ) {
					imageButton.setImageResource(resource_off);
					imageButton.setTag("off");
					on = false;
				}
		}
		
		return on;
	}
	
	public static void setButtonOn(ImageButton imageButton, int resource) {
		imageButton.setTag("on");
		imageButton.setImageResource(resource);
	}
	
	public static void setButtonOff(ImageButton imageButton, int resource) {
		imageButton.setTag("off");
		imageButton.setImageResource(resource);
	}
	
	public static int getMotionEventAction(int action) {
		if ( 
			(action == MotionEvent.ACTION_UP) || 
			(action == MotionEvent.ACTION_POINTER_1_UP) ||
			(action == MotionEvent.ACTION_POINTER_2_UP)
		) {
			action = MotionEvent.ACTION_UP;
		}
		
		if ( 
			(action == MotionEvent.ACTION_DOWN) || 
			(action == MotionEvent.ACTION_POINTER_1_DOWN) ||
			(action == MotionEvent.ACTION_POINTER_2_DOWN)
		) {
			action = MotionEvent.ACTION_DOWN;
		}
		
		return action;
	}

}
