package channel;

/**
 * This class holds global informations about the channels.
 * 
 * @author edem
 * 
 */
public class ChannelInfo {

	public static final int CHANNELS = 8;
	public static final int DIGITAL_CHANNELS = 4;
	public static final int DEFAULT_SENSITIVITY_VALUE = 100;
	public static final int DEFAULT_MODE = 1;
	public static final int MODE_COUNT = 4;
}
