package channel;

import java.util.Observable;

import over.TimerService;

public class ChannelSource extends Observable {
	public static final int NO_SOURCE = 0;
	public static final int JOY_RIGHT_X = 1;
	public static final int JOY_RIGHT_Y = 2;
	public static final int JOY_LEFT_X = 3;
	public static final int JOY_LEFT_Y = 4;
	public static final int JOY_GYRO_X = 5;
	public static final int JOY_GYRO_Z = 6;
	public static final int JOY_BUTTON_A = 7;
	public static final int JOY_BUTTON_B = 8;
	public static final int JOY_BUTTON_C = 9;
	public static final int JOY_BUTTON_D = 10;

	public static final int SOURCE_COUNT = 11;

	private float data;
	private float sensibility;
	private int type;
	
	public Channel channel;
	public int channelIndex = Channel.NO_CHANNEL;

	public ChannelSource() {
		this.data = 0;
		this.sensibility = 0;
		this.type = NO_SOURCE;
	}
	
	public void setChannel() {
		channelIndex = TimerService.channelCalculator.getChannelBySource(getType());
		channel = TimerService.channelCalculator.getChannelByIndex(channelIndex);
	}

	public void setData(float data) {
		this.data = data;
		setChanged();
		notifyObservers();
	}

	public void setSensibility(float sensibility) {
		this.sensibility = sensibility;
		setChanged();
		notifyObservers();
	}

	public float getData() {
		return data;
	}

	public float getSensibility() {
		return sensibility;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getType() {
		return type;
	}
}
