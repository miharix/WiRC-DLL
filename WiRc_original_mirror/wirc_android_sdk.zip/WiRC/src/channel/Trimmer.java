package channel;

public class Trimmer {
	private int minimumOutputValue;
	private int maximumOutputValue;
	private int trimValue;

	public int trimValue(float inputValue) {
		float slope = (maximumOutputValue - minimumOutputValue) / 2;

		int outputValue = (int) ((slope * inputValue) + trimValue);

		if (outputValue < minimumOutputValue)
			outputValue = minimumOutputValue;
		if (outputValue > maximumOutputValue)
			outputValue = maximumOutputValue;
		return outputValue;
	}

	public Trimmer(int minimumOutputValue, int maximumOutputValue,
			int trimValue) {
		this.setMinimumOutputValue(minimumOutputValue);
		this.setMaximumOutputValue(maximumOutputValue);
		this.setTrimValue(trimValue);
	}

	public void setMinimumOutputValue(int minimumOutputValue) {
		this.minimumOutputValue = minimumOutputValue;
	}

	public int getMinimumOutputValue() {
		return minimumOutputValue;
	}

	public void setMaximumOutputValue(int maximumOutputValue) {
		this.maximumOutputValue = maximumOutputValue;
	}

	public int getMaximumOutputValue() {
		return maximumOutputValue;
	}

	public void setTrimValue(int trimValue) {
		this.trimValue = trimValue;
	}

	public int getTrimValue() {
		return trimValue;
	}

}