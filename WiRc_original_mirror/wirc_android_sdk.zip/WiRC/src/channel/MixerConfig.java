package channel;

public class MixerConfig {
	private boolean isActive;
	private int channelIndex;
	private int stageIndex;
	private boolean isAbsolute;
	private float factor;

	public MixerConfig(int channelIndex, int stageIndex, boolean isAbsolute, boolean isActive, float factor) {
		this.setChannelIndex(channelIndex);
		this.setStageIndex(stageIndex);
		this.setAbsolute(isAbsolute);
		this.setActive(isActive);
		this.setFactor(factor);
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setChannelIndex(int channelIndex) {
		this.channelIndex = channelIndex;
	}

	public int getChannelIndex() {
		return channelIndex;
	}

	public void setStageIndex(int stageIndex) {
		this.stageIndex = stageIndex;
	}

	public int getStageIndex() {
		return stageIndex;
	}

	public void setAbsolute(boolean isAbsolute) {
		this.isAbsolute = isAbsolute;
	}

	public boolean isAbsolute() {
		return isAbsolute;
	}

	public void setFactor(float factor) {
		this.factor = factor;
	}

	public float getFactor() {
		return factor;
	}
}
