package channel;

public class Channel {

	public static final int LINEAR_CHARACTERISTIC = 0;
	public static final int EXPONENTIAL_CHARACTERISTIC = 1;
	public static final int STAGE_1 = 1;
	public static final int STAGE_2 = 2;
	public static final int STAGE_3 = 3;
	public static final int NO_CHANNEL = -1;
	public static final int TYPE_STD = 0;
	public static final int TYPE_DIGITAL = 1;

	private int index;
	private int characteristicType;
	private float exponentialFactor;
	private boolean isReversed;
	private float sensitivityFactor;

	private ChannelState channelState;
	private MixerConfig valueMixerConfig;
	private MixerConfig sensitivityMixerConfig;
	private Trimmer trimmer;

	public Channel(int index) {
		this.setIndex(index);
		this.setChannelState(new ChannelState());
	}

	public void setValueMixer(int channelIndex, int stageIndex,
			boolean isAbsolute, boolean isActive, float factor) {
		setValueMixerConfig(new MixerConfig(channelIndex, stageIndex,
				isAbsolute, isActive, factor));
	}

	public void setSensibilityMixer(int channelIndex, int stageIndex,
			boolean isAbsolute, boolean isActive, float factor) {
		setSensitivityMixerConfig(new MixerConfig(channelIndex, stageIndex,
				isAbsolute, isActive, factor));
	}

	public void setTrimSettings(int minimumOutputValue, int maximumOutputValue,
			int trimValue) {
		this.trimmer = new Trimmer(minimumOutputValue, maximumOutputValue,
				trimValue);
	}

	public void doAge() {
		this.channelState.currentValue = this.channelState.nextValue;
	}

	public void setExponentialFactor(float exponentialFactor) {
		this.exponentialFactor = exponentialFactor;
	}

	public float getExponentialFactor() {
		return exponentialFactor;
	}

	public void setReversed(boolean isReversed) {
		this.isReversed = isReversed;
	}

	public boolean isReversed() {
		return isReversed;
	}

	public void setSensitivityFactor(float sensitivityFactor) {
		this.sensitivityFactor = sensitivityFactor;
	}

	public float getSensitivityFactor() {
		return sensitivityFactor;
	}

	public void setCharacteristicType(int characteristicType) {
		this.characteristicType = characteristicType;
	}

	public int getCharacteristicType() {
		return characteristicType;
	}

	public void setChannelState(ChannelState state) {
		this.channelState = state;
	}

	public ChannelState getState() {
		return channelState;
	}

	public void setValueMixerConfig(MixerConfig valueMixerConfig) {
		this.valueMixerConfig = valueMixerConfig;
	}

	public MixerConfig getValueMixerConfig() {
		return valueMixerConfig;
	}

	public void setSensitivityMixerConfig(MixerConfig sensitivityMixerConfig) {
		this.sensitivityMixerConfig = sensitivityMixerConfig;
	}

	public MixerConfig getSensitivityMixerConfig() {
		return sensitivityMixerConfig;
	}

	public void setTrimSettings(Trimmer trimSettings) {
		this.trimmer = trimSettings;
	}

	public Trimmer getTrimSettings() {
		return trimmer;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public int getIndex() {
		return index;
	}

}
