package channel;

public class ChannelState {
	private float inputValue = 0;
	private float stage1 = 0;
	private float stage2 = 0;
	private float stage3 = 0;
	
	public int currentValue = 0;
	public int nextValue = 0;

	public void setStage1(float stage1) {
		this.stage1 = stage1;
	}

	public float getStage1() {
		return stage1;
	}

	public void setStage2(float stage2) {
		this.stage2 = stage2;
	}

	public float getStage2() {
		return stage2;
	}

	public void setStage3(float stage3) {
		this.stage3 = stage3;
	}

	public float getStage3() {
		return stage3;
	}

	public void setCurrentValue(int currentValue) {
		this.currentValue = currentValue;
	}

	public int getCurrentValue() {
		return currentValue;
	}

	public void setNextValue(int nextValue) {
		this.nextValue = nextValue;
	}

	public int getNextValue() {
		return nextValue;
	}

	public void setInputValue(float inputValue) {
		this.inputValue = inputValue;
	}

	public float getInputValue() {
		return inputValue;
	}
}
