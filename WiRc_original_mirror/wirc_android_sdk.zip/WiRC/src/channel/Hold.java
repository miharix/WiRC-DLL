package channel;

import com.dension.sqliteaccess.WircDbAdapter;

import android.database.Cursor;
import over.TimerService;

public class Hold {
	
	public boolean rX;
	public boolean rY;
	public boolean lX;
	public boolean lY;
	
	public Hold() {
		
	}
	
	public void getHoldSettings() {
		Cursor settings = TimerService.dbHelper.getPositionsTable().fetchPositionRecord(TimerService.getActiveProfileId(), TimerService.modeNum);
		
		rX = settings.getInt(settings.getColumnIndexOrThrow(WircDbAdapter.PositionsTable.KEY_RIGHT_JOY_X)) == 1 ? true : false;
		rY = settings
		.getInt(settings
				.getColumnIndexOrThrow(WircDbAdapter.PositionsTable.KEY_RIGHT_JOY_Y)) == 1 ? true
		: false;
		lX = settings
		.getInt(settings
				.getColumnIndexOrThrow(WircDbAdapter.PositionsTable.KEY_LEFT_JOY_X)) == 1 ? true
		: false;
		lY = settings
		.getInt(settings
				.getColumnIndexOrThrow(WircDbAdapter.PositionsTable.KEY_LEFT_JOY_Y)) == 1 ? true
		: false;
		
		settings.close();
	}

}
