package channel;

import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;

import over.TimerService;
import android.content.Context;
import android.database.Cursor;

import com.dension.sqliteaccess.WircDbAdapter;

public class ChannelCalculator implements Observer {
	private static final int CALC_CYCLES = 2;

	// channels are from 1-8 (no 0 index)
	private HashMap<Integer, Channel> channels;

	public Channel getChannelByIndex(int index) {
		return channels.get(index);
	}

	// channels are from 1-8 (no 0 index)
	// key is the source index value is the channel index
	private HashMap<Integer, Integer> channelSourceIndexes;
	private static ChannelCalculator instance;
	private long profileId;

	private ChannelCalculator() {
		init();
	}

	public void clear() {
		channels = new HashMap<Integer, Channel>();
		channelSourceIndexes = new HashMap<Integer, Integer>();
	}

	public void init() {
		profileId = TimerService.dbHelper.getProfilesTable().getActiveProfileId();
		channels = new HashMap<Integer, Channel>();
		channelSourceIndexes = new HashMap<Integer, Integer>();
		// initializing channel configuration
		// getting preferences
		Cursor chSettings = TimerService.dbHelper.getChannelsTable().fetchChannelsByProfile(profileId);

		for (int i = 1; i <= chSettings.getCount(); i++) {
			boolean isReverse = chSettings.getInt(chSettings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_IS_REVERSE)) == 1 ? true : false;
			int minValue = chSettings.getInt(chSettings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_MIN_VALUE));
			int maxValue = chSettings.getInt(chSettings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_MAX_VALUE));
			int trimValue = chSettings.getInt(chSettings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_TRIM_VALUE));
			int sensType = chSettings.getInt(chSettings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_SENSITIVITY_TYPE));
			int expFactor = chSettings.getInt(chSettings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_EXPONENTIAL_FACTOR));
			int isSensMixerActive = chSettings.getInt(chSettings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_SENSITIVITY_MIXER));
			int sensMixerChannel = chSettings.getInt(chSettings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_SENSITIVITY_MIXER_CHANNEL));
			boolean isSensMixerAbsolulte = chSettings.getInt(chSettings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_SENSITIVITY_MIXER_ABSOLUTE)) == 1 ? true : false;
			int sensMixFactor = chSettings.getInt(chSettings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_SENSITIVITY_MIXER_FACTOR));
			int isValueMixerActive = chSettings.getInt(chSettings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_VALUE_MIXER));
			int valueMixerChannel = chSettings.getInt(chSettings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_VALUE_MIXER_CHANNEL));

			boolean isValueMixerAbsolute = chSettings.getInt(chSettings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_VALUE_MIXER_ABSOLUTE)) == 1 ? true : false;
			int valueMixFactor = chSettings.getInt(chSettings.getColumnIndexOrThrow(WircDbAdapter.ChannelsTable.KEY_VALUE_MIXER_FACTOR));
			channels.put(i, new Channel(i));
			channels.get(i).setSensibilityMixer(sensMixerChannel, Channel.STAGE_3, isSensMixerAbsolulte, isSensMixerActive == 0 ? false : true, sensMixFactor);
			channels.get(i).setValueMixer(valueMixerChannel, Channel.STAGE_3, isValueMixerAbsolute, isValueMixerActive == 0 ? false : true, valueMixFactor);
			channels.get(i).setCharacteristicType(sensType);
			channels.get(i).setExponentialFactor(expFactor);
			channels.get(i).setIndex(i);
			channels.get(i).setReversed(isReverse);
			channels.get(i).setSensitivityFactor(ChannelInfo.DEFAULT_SENSITIVITY_VALUE);
			channels.get(i).setTrimSettings(minValue, maxValue, trimValue);
			// Log.d(MainActivity.DEBUG_LOG_TAG, "Channel " + i
			// + " settings-> sensMixer: " + isSensMixerActive
			// + " valMixer: " + isValueMixerActive);

			chSettings.moveToNext();
		}
		setControlsByMode();

		chSettings.close();

		/*
		chSettings = TimerService.dbHelper.getDigitalChannelsTable().fetchDigitalChannelByProfile(profileId);
		chSettings.close();
		*/
	}

	public void setControlsByMode() {
		channelSourceIndexes.clear();
		int chIdx = 1;
		for (int i = 1; i <= ChannelInfo.CHANNELS; ++i) {
			int pref = TimerService.dbHelper.getControlsTable().fetchSourceByChannelIdx(i, profileId, TimerService.modeNum);
			if (pref != ChannelSource.NO_SOURCE) {
				channelSourceIndexes.put(pref, chIdx);
			}
			chIdx++;
		}

		for (int i = 1; i <= ChannelInfo.DIGITAL_CHANNELS; i++) {
			int pref = TimerService.dbHelper.getControlsTable().fetchSourceByChannelIdx(i, profileId, TimerService.modeNum, true);
			if (pref != ChannelSource.NO_SOURCE) {
				channelSourceIndexes.put(pref, chIdx);
			}
			chIdx++;
		}
	}

	public static synchronized ChannelCalculator getChannelCalc(Context context) {
		if (instance == null)
			instance = new ChannelCalculator();
		return instance;
	}

	private void ageing() {
		for (int i = 1; i <= ChannelInfo.CHANNELS; ++i) {
			channels.get(i).doAge();
		}
	}

	@Override
	public void update(Observable observable, Object data) {
		try {
			ChannelSource channelSource = (ChannelSource) observable;
			Integer type = channelSource.getType();
			if (type == ChannelSource.NO_SOURCE) {
			} else {
				int channelIndex;
				if (channelSourceIndexes.containsKey(type)) {
					channelIndex = channelSourceIndexes.get(channelSource.getType());
				} else {
					return;
				}
				channels.get(channelIndex).getState().setInputValue(channelSource.getData());
				calculateOutputValues();

				// Notify.d(this, String.format("%d | %d", channels.get(1).getState().getNextValue(), channels.get(2).getState().getNextValue()));

				for (int i = 1; i <= ChannelInfo.CHANNELS; ++i) {
					TimerService.periodicChannelData.setChannel(i, channels.get(i).getState().getNextValue());
				}
			}
		} catch (Throwable e) {
			// Notify.e(this, "update " + e.toString()); 
		}
	}

	private void calculateOutputValues() {
		for (int calculationCycle = 0; calculationCycle < CALC_CYCLES; ++calculationCycle) {
			// calculate every channel
			for (int channelIndex = 1; channelIndex <= ChannelInfo.CHANNELS; ++channelIndex) {
				// ageing internal signal values, step in time
				ageing();
				// calculate output values of a channel
				if (channelSourceIndexes.containsValue(channelIndex)) {
					// Notify.d(this, "*** " + " " + channelIndex); 
					calculateChannelValue(channelIndex);
				} else {
				}
			}
		}
		/* calculate output values from the states for every channel */
		for (int i = 1; i <= ChannelInfo.CHANNELS; ++i) {
			float stage3Value = channels.get(i).getState().getStage3();
			int trimmedValue = channels.get(i).getTrimSettings().trimValue(stage3Value);
			channels.get(i).getState().setNextValue(trimmedValue);
		}
	}

	/**
	 * This method calculates the 3 steps for each channel
	 * 
	 * @param channelIndex
	 */
	private void calculateChannelValue(int channelIndex) {

		// long prevTime = System.nanoTime() / 1000;
		// long currTime;
		Channel currChannel = channels.get(channelIndex);
		/* STAGE 1: input characteristic and sensitivity */
		// currTime = System.nanoTime() / 1000;
		// Log.d(MainActivity.DEBUG_LOG_TAG, (currTime - prevTime) + "us | "
		// + "Setting stage1 value for channel " + channelIndex + " ("
		// + calculateStage1(channelIndex) + ")");
		currChannel.getState().setStage1(calculateStage1(channelIndex));
		// prevTime = currTime;

		/* STAGE 2: sensitivity mixer */
		// currTime = System.nanoTime() / 1000;
		// Log.d(MainActivity.DEBUG_LOG_TAG, (currTime - prevTime) + "us | "
		// + "Setting stage2 value for channel " + channelIndex + " ("
		// + calculateStage1(channelIndex) + ")");
		currChannel.getState().setStage2(calculateStage2(channelIndex));
		// prevTime = currTime;

		/* STAGE 3: value mixer */
		// currTime = System.nanoTime() / 1000;
		// Log.d(MainActivity.DEBUG_LOG_TAG, (currTime - prevTime) + "us | "
		// + "Setting stage3 value for channel " + channelIndex + " ("
		// + calculateStage1(channelIndex) + ")");
		currChannel.getState().setStage3(calculateStage3(channelIndex));
		// prevTime = currTime;
	}

	/**
	 * Internal function to calculate characterized input value
	 * 
	 * The function calculation has three parts: 1. Optional exponential
	 * function 2. Optional reverse 3. Sensitivity
	 * 
	 * @param channelIndex
	 * @return
	 */
	private float calculateStage1(int channelIndex) {
		Channel currChannel = channels.get(channelIndex);
		float out = currChannel.getState().getInputValue();

		// optional exponential calculation
		if (currChannel.getCharacteristicType() == Channel.EXPONENTIAL_CHARACTERISTIC) {
			out = exponentialFunction(out, currChannel.getExponentialFactor());
		} else if (channels.get(channelIndex).getCharacteristicType() == Channel.LINEAR_CHARACTERISTIC) {
			;
		} else {
			// TODO if not linear nor exponential
		}

		// reversing
		if (currChannel.isReversed()) {
			out *= -1.0;
		}

		// using sensitivity
		out *= currChannel.getSensitivityFactor() / 100;

		return saturate(out);
	}

	/**
	 * Internal function to implement sensitivity mixer
	 * 
	 * @param channelIndex
	 * @return output of the sensitivity mixer
	 * 
	 *         The function calculates a factor based on the value of the mixed
	 *         channel. This factor is used as a sensitivity for the input. The
	 *         result is saturated between -1 and +1.
	 * 
	 *         result = MIN(MAX((1 + mixedChannelFactor * mixedChannel) * in),
	 *         -1), 1);
	 */
	private float calculateStage2(int channelIndex) {
		Channel currChannel = channels.get(channelIndex);
		float out = currChannel.getState().getStage1();

		if (currChannel.getSensitivityMixerConfig().isActive()) {
			Channel mixedChannel = channels.get(currChannel.getSensitivityMixerConfig().getChannelIndex());
			int stageIndex = mixedChannel.getSensitivityMixerConfig().getStageIndex();
			float mixedChannelVal = 0;
			switch (stageIndex) {
			case Channel.STAGE_1:
				mixedChannelVal = mixedChannel.getState().getStage1();
				break;
			case Channel.STAGE_2:
				mixedChannelVal = mixedChannel.getState().getStage2();
				break;
			case Channel.STAGE_3:
				mixedChannelVal = mixedChannel.getState().getStage3();
				break;
			default:
				// invalid stage specifier
				break;
			}
			// calculate mixing factor
			float factor = 1 + (currChannel.getSensitivityMixerConfig().getFactor() / 100 * mixedChannelVal);
			// mix
			out *= factor;
		}
		return saturate(out);
	}

	/**
	 * Internal function to implement value mixer
	 * 
	 * @param channelIndex
	 * @return output of the value mixer
	 * 
	 *         The function calculates an additional value from the value of the
	 *         mixed channel and add it to the input. The result is saturated
	 *         between -1 and +1.
	 * 
	 *         result = MIN(MAX((1 + mixedChannelFactor * mixedChannel) * in),
	 *         -1), 1);
	 */
	private float calculateStage3(int channelIndex) {
		Channel currChannel = channels.get(channelIndex);
		// Log.d(MainActivity.DEBUG_LOG_TAG, "Current channel: " +
		// channelIndex);
		float out = currChannel.getState().getStage2();

		if (currChannel.getValueMixerConfig().isActive()) {
			// Log.d(MainActivity.DEBUG_LOG_TAG, "Value mixer is active...");
			Channel mixedChannel = channels.get(currChannel.getValueMixerConfig().getChannelIndex());
			// Log.d(MainActivity.DEBUG_LOG_TAG, "Value mixed channel is: "
			// + currChannel.getValueMixerConfig().getChannelIndex());
			int stageIndex = mixedChannel.getValueMixerConfig().getStageIndex();
			// Log.d(MainActivity.DEBUG_LOG_TAG, "Stage index is: " +
			// stageIndex);
			float mixedChannelVal = 0;
			switch (stageIndex) {
			case Channel.STAGE_1:
				mixedChannelVal = mixedChannel.getState().getStage1();
				break;
			case Channel.STAGE_2:
				mixedChannelVal = mixedChannel.getState().getStage2();
				break;
			case Channel.STAGE_3:
				// Log.d(MainActivity.DEBUG_LOG_TAG, "Stage3 value is: "
				// + mixedChannel.getState().getStage3());
				mixedChannelVal = mixedChannel.getState().getStage3();
				break;
			default:
				// invalid stage specifier
				break;
			}

			// calculate additional value
			float add = currChannel.getValueMixerConfig().getFactor() / 100 * mixedChannelVal;
			// mix
			out += add;
		}
		return saturate(out);
	}

	/**
	 * Internal function to implement an exponential function
	 * 
	 * @param value
	 *            input value
	 * @param exponent
	 *            exponent used in the function
	 * @return result of the function
	 * 
	 *         The function calculates an exponential like function and
	 *         saturates the output between -1 and +1.
	 */
	private float exponentialFunction(float value, float exponent) {
		// exponential function: (1-exp)*in + exp*in^3
		// Log.i("exp", "value: " + value + " exponent: " + exponent);
		float out = (1 - exponent / 100) * value;
		// Log.i("exp", "out step1: " + out);
		out += exponent * value * value * value;
		// Log.i("exp", "out step2: " + out);
		out = saturate(out);
		// Log.i("exp", "out step3: " + out);
		return out;
	}

	private float saturate(float value) {
		if (value < -1)
			value = -1;
		if (value > 1)
			value = 1;
		return value;
	}

	public int getChannelBySource(int source) {
		if (channelSourceIndexes != null && channelSourceIndexes.containsKey(source)) {
			return channelSourceIndexes.get(source);
		} else {
			return Channel.NO_CHANNEL;
		}
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}

	// source checkers
	public boolean isUsingButtonA() {
		return channelSourceIndexes.containsKey(ChannelSource.JOY_BUTTON_A);
	}

	public boolean isUsingButtonB() {
		return channelSourceIndexes.containsKey(ChannelSource.JOY_BUTTON_B);
	}

	public boolean isUsingButtonC() {
		return channelSourceIndexes.containsKey(ChannelSource.JOY_BUTTON_C);
	}

	public boolean isUsingButtonD() {
		return channelSourceIndexes.containsKey(ChannelSource.JOY_BUTTON_D);
	}

	public boolean isUsingJoyX() {
		return isUsingLeftJoyX() || isUsingRightJoyX();
	}

	public boolean isUsingJoyY() {
		return isUsingLeftJoyY() | isUsingRightJoyY();
	}

	public boolean isUsingLeftJoyX() {
		return channelSourceIndexes.containsKey(ChannelSource.JOY_LEFT_X);
	}

	public boolean isUsingLeftJoyY() {
		return channelSourceIndexes.containsKey(ChannelSource.JOY_LEFT_Y);
	}

	public boolean isUsingRightJoyX() {
		return channelSourceIndexes.containsKey(ChannelSource.JOY_RIGHT_X);
	}

	public boolean isUsingRightJoyY() {
		return channelSourceIndexes.containsKey(ChannelSource.JOY_RIGHT_Y);
	}

	public boolean isUsingGyro() {
		return isUsingGyroX() | isUsingGyroZ();
	}

	public boolean isUsingGyroX() {
		return channelSourceIndexes.containsKey(ChannelSource.JOY_GYRO_X);
	}

	public boolean isUsingGyroZ() {
		return channelSourceIndexes.containsKey(ChannelSource.JOY_GYRO_Z);
	}

	public void setProfileId(long profileId) {
		this.profileId = profileId;
	}

	public long getProfileId() {
		return profileId;
	}
}
