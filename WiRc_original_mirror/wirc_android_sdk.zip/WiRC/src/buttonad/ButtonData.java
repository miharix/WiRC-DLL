package buttonad;

import android.graphics.Bitmap;
import android.widget.ImageButton;
import channel.ChannelSource;

public class ButtonData {

	public Boolean isTrigger = false;
	public int onLevel = -1;
	public int offLevel = -1;
	public int chIdx = -1;
	public int channelSource = ChannelSource.NO_SOURCE;

	public ImageButton button = null;
	public Bitmap bitmap = null;
	public Bitmap bitmapOn = null;
	public Boolean used = false;
	public Boolean pressed = false;

	public ButtonData() {
	}

}
