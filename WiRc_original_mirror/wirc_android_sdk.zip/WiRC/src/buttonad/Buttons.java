package buttonad;

import java.util.HashMap;

import over.TimerService;
import wirc.dension.com.R;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.MotionEvent;
import channel.ChannelSource;

import com.dension.sqliteaccess.WircDbAdapter;

import develop.Notify;

public class Buttons {

	private String buttons[];
	private HashMap<String, Integer> hashMap_button_tags = new HashMap<String, Integer>();

	public HashMap<String, ButtonData> hashMap_button_datas = new HashMap<String, ButtonData>();

	public Buttons(Context context) {
		try {
			buttons = context.getResources().getStringArray(R.array.a_Buttons);
			for (int i = 0; i < buttons.length; i++) {
				hashMap_button_tags.put(buttons[i], i + 1);
			}
		} catch (Throwable e) {
			Notify.e(this, e.toString());
		}
	}

	public void init() {
		try {
			reset();
			hashMap_button_datas.clear();
			for (int i = 0; i < buttons.length; i++) {
				ButtonData buttonData = getSettings(buttons[i]);
				hashMap_button_datas.put(buttons[i], buttonData);
			}
		} catch (Throwable e) {
			Notify.e(this, e.toString());
		}
	}

	public void reset() {
		try {
			for (int i = 0; i < buttons.length; i++) {
				ButtonData buttonData = hashMap_button_datas.get(buttons[i]);
				if (buttonData != null)
					buttonData.button.setImageBitmap(buttonData.bitmap);
			}
		} catch (Throwable e) {
			Notify.e(this, e.toString());
		}
	}

	public ButtonData getSettings(String buttonTag) {
		ButtonData buttonData = new ButtonData();

		try {
			int buttonID = hashMap_button_tags.get(buttonTag);
			buttonData.channelSource = buttonID + ChannelSource.JOY_BUTTON_A - 1;
			long profileId = TimerService.getActiveProfileId();
			Cursor btnSettings = TimerService.dbHelper.getButtonsTable().fetchButton(buttonID, profileId, TimerService.modeNum);

			int isTrigger = 0;
			try {
				isTrigger = btnSettings.getInt(btnSettings.getColumnIndexOrThrow(WircDbAdapter.ButtonsTable.KEY_TYPE));
				// Notify.d(this, "getSettings()", isTrigger);
			} catch (Throwable e) {
				Notify.e(this, "getSettings() " + e.toString());
			}
			buttonData.isTrigger = isTrigger == WircDbAdapter.ButtonsTable.TYPE_TOGGLE ? false : true;

			buttonData.onLevel = btnSettings.getInt(btnSettings.getColumnIndexOrThrow(WircDbAdapter.ButtonsTable.KEY_ON_LEVEL));
			buttonData.offLevel = btnSettings.getInt(btnSettings.getColumnIndexOrThrow(WircDbAdapter.ButtonsTable.KEY_OFF_LEVEL));
			buttonData.chIdx = TimerService.channelCalculator.getChannelBySource(buttonData.channelSource);
			buttonData.used = buttonData.chIdx != -1;
			btnSettings.close();
		} catch (Throwable e) {
			Notify.e(this, "getSettings() " + e.toString());
		}

		return buttonData;
	}

	public ButtonData press(String buttonTag, int action, boolean falsePress) {
		ButtonData buttonData = null;

		try {
			buttonData = hashMap_button_datas.get(buttonTag);
			if (buttonData != null) {
				if (buttonData.used) {
					if (falsePress) {
					} else {
						if (buttonData.isTrigger) {
							if (action == MotionEvent.ACTION_DOWN) {
								buttonData.pressed = true;
							}
							if (action == MotionEvent.ACTION_UP) {
								buttonData.pressed = false;
							}
						} else {
							if (action == MotionEvent.ACTION_UP) {
								buttonData.pressed = !buttonData.pressed;
							}
						}
						if (buttonData.pressed) {
							buttonData.button.setImageBitmap(drawBitmap(buttonData.bitmap, buttonData.bitmapOn));
						} else {
							buttonData.button.setImageBitmap(buttonData.bitmap);
						}
					}

					if (TimerService.status.connected || TimerService.developMode) {
						if (TimerService.periodicChannelData.hasDeviceControl || TimerService.developMode) {
							TimerService.periodicChannelData.setChannel(buttonData.chIdx, buttonData.pressed ? buttonData.onLevel : buttonData.offLevel);
						}
					}
				}
			}
		} catch (Throwable e) {
			Notify.e(this, "press() " + e.toString());
		}

		return buttonData;
	}

	private Bitmap drawBitmap(Bitmap bitmap, Bitmap bitmapOn) {
		Bitmap bitmapDraw = null;

		try {
			bitmapDraw = Bitmap.createBitmap(bitmap);
			Canvas canvas = new Canvas(bitmapDraw);
			canvas.drawBitmap(bitmapOn, 0f, 0f, null);
		} catch (Throwable e) {
			Notify.e(this, e.toString());
		}

		return bitmapDraw;

	}

}
