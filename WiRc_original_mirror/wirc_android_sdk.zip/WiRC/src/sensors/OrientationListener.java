package sensors;

import over.TimerService;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import channel.Channel;
import channel.ChannelSource;

import com.dension.wra.ChannelSettingsActivity;

import develop.Notify;

public class OrientationListener implements SensorEventListener {

	private static final int Z_MIN = 0;
	private static final int Z_MEAN = 45;
	private static final int Z_MAX = 90;
	private int[] zOffsets = new int[Z_MAX];

	private static final int X_MEAN = 180;
	private static final int X_MAX = 360;
	private int[] xOffsets = new int[X_MAX];

	private static final int X_VALUE_INDEX = 0;
	private static final int Z_VALUE_INDEX = 2;

	private int xScale = 45;
	private int zScale = 45;
	
	private Integer startX = null;
	private Integer startZ = null;
	private Integer startZComp = 0;
	
	public ChannelSource xChannelSource;
	public ChannelSource zChannelSource;
	public int channelXIndex = Channel.NO_CHANNEL;
	public int channelZIndex = Channel.NO_CHANNEL;
	public Channel channelX;
	public Channel channelZ;
	
	public int min = 0;
	public int max = 100;
	public int trimX = 50;
	public int trimY = 50;
	
	private static float GYRO_X_MIN = -45;
	private static float GYRO_X_MAX = 45;
	private static float GYRO_X_INTERVAL = 90;
	private static float GYRO_Z_MIN = 0;
	private static float GYRO_Z_MAX = 90;
	private static float GYRO_Z_INTERVAL = 90;
	
	private float slopeX = 0;
	private float slopeZ00 = 0;
	private float slopeZ90 = 0;
	private float zeroZ = 0;
	
	
	public void initControls() {
		min = ChannelSettingsActivity.CHANNEL_MIN_US;
		max = ChannelSettingsActivity.CHANNEL_MAX_US;
		xChannelSource = new ChannelSource();
		zChannelSource = new ChannelSource();
		xChannelSource.setType(ChannelSource.NO_SOURCE);
		zChannelSource.setType(ChannelSource.NO_SOURCE);
		channelXIndex = Channel.NO_CHANNEL;
		channelZIndex = Channel.NO_CHANNEL;
		
		if ( TimerService.channelCalculator.isUsingGyroX() ) {
			xChannelSource.setType(ChannelSource.JOY_GYRO_X);
		}
		if ( TimerService.channelCalculator.isUsingGyroZ() ) {
			zChannelSource.setType(ChannelSource.JOY_GYRO_Z);
		}
		
		slopeX = 100f / GYRO_X_INTERVAL;
		slopeZ00 = 100f / GYRO_Z_INTERVAL;
	}
	
	public void startControls() {
		startX = null;
		startZ = null;
		firstTime = true;
		
		if ( TimerService.channelCalculator.isUsingGyroX() ) {
			xChannelSource.addObserver(TimerService.channelCalculator);
		}
		if ( TimerService.channelCalculator.isUsingGyroZ() ) {
			zChannelSource.addObserver(TimerService.channelCalculator);
		}
		
		if ( TimerService.channelCalculator.isUsingGyro() ) {
			TimerService.sensorManager.registerListener(
				this,
				TimerService.sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION),
				SensorManager.SENSOR_DELAY_GAME);
		}
	}
	
	public void stopControls() {
		if ( TimerService.channelCalculator.isUsingGyroX() ) {
			xChannelSource.deleteObserver(TimerService.channelCalculator);
		}
		if ( TimerService.channelCalculator.isUsingGyroZ() ) {
			zChannelSource.deleteObserver(TimerService.channelCalculator);
		}
		
		if ( TimerService.channelCalculator.isUsingGyro() ) {
			TimerService.sensorManager.unregisterListener(this);
		}
	}

	private float calculateRelativeX(int currX) {
		int relX = xOffsets[currX];
		if (relX >= xScale && relX <= X_MEAN) {
			relX = xScale;
		} else if (relX < xScale) {
			;
		} else if (relX > xScale && relX > X_MAX - xScale) {
			relX = (X_MAX - relX) * -1;
		} else {
			relX = xScale * -1;
		}
		return relX;
	}

	private int calculateRelativeZ(int currZ) {
		int relZ = 0;
		if (currZ < Z_MEAN && currZ <= Z_MEAN - zScale) {
			relZ = zScale;
		} else if (currZ <= Z_MEAN && currZ > Z_MEAN - zScale) {
			relZ = Z_MEAN - currZ;
		} else if (currZ > Z_MEAN && currZ < Z_MEAN + zScale) {
			relZ = (currZ - zScale) * -1;
		} else {
			relZ = zScale * -1;
		}
		return relZ;
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		Notify.d(this, sensor + " " + accuracy);
		
		
	}

	private Boolean firstTime = true;
	
	@Override
	public void onSensorChanged(SensorEvent event) {
		float eventZ = event.values[2];
		float x = 0;
		float z = 0;
		
		if ( firstTime ) {
			firstTime = false;
			zeroZ = eventZ;
			slopeZ00 = 100f / zeroZ;
			slopeZ90 = 100f / (GYRO_Z_INTERVAL - zeroZ);
		}
		
		
		x = (slopeX * event.values[1]) / 100f;
		xChannelSource.setData(x);
		
		if ( eventZ > 0 ) { 
			if ( eventZ < zeroZ ) {
				z = - (GYRO_Z_MAX - (slopeZ00 * eventZ)) / 100f;
			}
			else {
				z = - (GYRO_Z_MAX - (slopeZ90 * eventZ)) / 100f;
			}
			zChannelSource.setData(z);
		}
		
		
		
		
		// Notify.d(this, String.format("%+f | %f *** %f | %f", event.values[1], x, event.values[2], z));
		// Notify.d(this, String.format("%+f | %+f | %+f", zeroZ, eventZ, z));
		
		/*
		if ( startX == null ) {
			noFirstChange = false;
			startX = (int) event.values[X_VALUE_INDEX];
			for (int i = 0; i < X_MAX; ++i) {
				xOffsets[startX] = i;
				startX++;
				if (startX >= X_MAX) {
					startX = 1;
				}
			}
		}
		
		if ( startZ == null ) {
			noFirstChange = false;
			startZ = (int) event.values[Z_VALUE_INDEX];
			startZComp = Z_MEAN - startZ;
		}

		if ( noFirstChange ) {
			float relativeX = calculateRelativeX((int) event.values[X_VALUE_INDEX]);
			float relativeZ = calculateRelativeZ((int) event.values[Z_VALUE_INDEX]) + startZComp;
			float newZ = relativeZ / zScale;
			float newX = relativeX / xScale;
	
			xChannelSource.setData(newX);
			zChannelSource.setData(newZ);
			
			// Notify.d(this, String.format("%f|%f %f|%f", event.values[0], event.values[2], newX, newZ));
		}
		*/
	}

}
