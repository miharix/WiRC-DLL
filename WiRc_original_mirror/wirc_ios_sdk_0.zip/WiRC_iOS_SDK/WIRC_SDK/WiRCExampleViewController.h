//
//  WiRCExampleViewController.h
//  WiRCExample
//
//  Created by Jagicza József on 11/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WiRC.h"

@interface WiRCExampleViewController : UIViewController<UITextFieldDelegate, WiRCDelegate> {
    
    WiRC *wirc;
    
    UILabel *valueLabel1;
    UILabel *valueLabel2;
    
    UILabel *valueVoltLabel1;
    UILabel *valueVoltLabel2;
    
    UILabel *valueDigInput1Label;
    UILabel *valueDigInput2Label;
    UILabel *valueDigInput3Label;
    UILabel *valueDigInput4Label;

    NSInteger chValue1;
    NSInteger chValue2;
    
    NSInteger battery1;
    NSInteger battery2;
    
    NSInteger digitInput1;
    NSInteger digitInput2;
    NSInteger digitInput3;
    NSInteger digitInput4;
    
    UIImageView *cameraImg;
    
    UIImageView *light;

}

@property(nonatomic, retain)WiRC *wirc;

@property(nonatomic, retain)UILabel *valueVoltLabel1;
@property(nonatomic, retain)UILabel *valueVoltLabel2;

@property(nonatomic, retain)UILabel *valueDigInput1Label;
@property(nonatomic, retain)UILabel *valueDigInput2Label;
@property(nonatomic, retain)UILabel *valueDigInput3Label;
@property(nonatomic, retain)UILabel *valueDigInput4Label;

@property(nonatomic, retain)UILabel *valueLabel1;
@property(nonatomic, retain)UILabel *valueLabel2;


@property(nonatomic, assign)NSInteger chValue1;
@property(nonatomic, assign)NSInteger chValue2;

@property(nonatomic, assign)NSInteger battery1;
@property(nonatomic, assign)NSInteger battery2;

@property(nonatomic, assign)NSInteger digitInput1;
@property(nonatomic, assign)NSInteger digitInput2;
@property(nonatomic, assign)NSInteger digitInput3;
@property(nonatomic, assign)NSInteger digitInput4;

@property(nonatomic, retain)UIImageView *cameraImg;

@property(nonatomic, retain)UIImageView *light;


-(uint16_t)stringToHex:(NSString *)str;
//-(void)setWifiConfig;
-(void)addStaticLabels;
-(void)addValueLabels;
-(void)displayImage:(UIImage *)image;
-(void)writeToFile:(UIImage *)image toFilePath:(NSString *)filePath;

@end
