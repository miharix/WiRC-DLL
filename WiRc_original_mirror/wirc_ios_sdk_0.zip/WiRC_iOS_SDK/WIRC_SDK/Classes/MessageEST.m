//
//  MessageEST.m
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MessageEST.h"


@implementation MessageEST

@synthesize p_cameraId;

-(id)initESTWithId:(uint8_t)cId {    
    
    if((self = [super init])) {
        
        p_cameraId = cId;
    }
    
    return self;
    
}

@end
