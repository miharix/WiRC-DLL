//
//  WiRC.m
//  WRC
//
//  Created by Jagicza József on 11/24/11.
//  Copyright (C) 2011 Dension Audio Systems Kft.
//

#import "WiRC.h"
#import "WiRCExampleViewController.h"
#import <Foundation/NSStream.h>
#include <CFNetwork/CFSocketStream.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <pthread.h>
#include <arpa/inet.h>
#import "MessageTL.h"
#import "Messages.h"
#import "MessageTCP.h"
#import "MessagePSD.h"

#import <mach/mach.h>
#import <mach/mach_host.h>


/** timeout for BCSA message receiving in seconds */
#define L_F32_BCSA_TIMEOUT_SEC  1.0

/** remote TCP port for the control channel */
#define L_U16_TCP_PORT          1984

/** stores the last received control message */
static msg_s_message_t l_s_ctrl_msg;

/** stores the last received control message */
static msg_s_message_t l_s_psd_msg;

/** major number of client version */
#define L_U8_VERSION_MAJOR      0

/** minor number of client version */
#define L_U8_VERSION_MINOR      1

/** system type of the client software */
#define L_U8_SYS_PC             0x00

/** name of the transmitter (client) */
#define L_ST_TR_NAME            "wrc_client (PC)"
/** name of the WRC device to set */
#define L_ST_WRC_NAME           "wrc device"

/** Default Camera off voltage limit */
#define L_U16_CAM_OFF           5500
/** Default WRC device off voltage limit */
#define L_U16_WRC_OFF           4500

/** Default Channel failsafe values */
#define L_U16_CH_FAILSAFE       1500u

/** default period time for PCD message sending */
#define L_U32_PCD_PERIOD_US     100000u

/** sleep time between WST message checks in [us]*/
#define L_U32_WST_SLEEP_US      100000u

/** timeout for waiting WST message */
#define L_U32_WST_TIMEOUT_US    10000000u

/** maximal number of handled cameras */
#define L_U8_MAX_CAMERA_NUM     255u

/** macro to determine the size of the header of a packet */
#define L_U32_HEADER_SIZE   ((uint32_t) (sizeof(l_s_packet_v3_t) - 1u))

/** maximal frame data can be received */
#define L_U32_MAX_DATA      ((uint32_t)(60*1024u))

/** maximal image size */
#define L_U32_MAX_IMG_SIZE  ((uint32_t)(256*1024u))

/** number of frames used in FPS measurement */
#define L_U32_FPS_FRAMES    10u

static uint8_t l_au8_image[L_U32_MAX_IMG_SIZE];

/** version number of the communication */
#define L_U32_VERSION       0x5503

/** macro to return the verison number and supress the flags */
#define L_GET_VERSION(x)    (((uint32_t)((x))) & 0x0000FFFF)

/** expression to check version number */
#define L_IS_VERSION(x)     ((L_GET_VERSION(x)) == L_U32_VERSION)

/** Bit pattern of the LAST flag */
#define L_BIT_LAST          1

/** expression to check if the value contains LAST flag */
#define L_IS_LAST(x)        ((((uint32_t)((x))) >> 16) & L_BIT_LAST)

@interface WiRC() 

@property(assign)unsigned int pcd_period;
@property(nonatomic, assign)int tcpSocket;
@property(nonatomic, assign)int udpSocket;
@property(nonatomic, assign)int pcdSocket;
@property(assign)BOOL ctrlRight;
@property(assign)uint16_t psdPort;
@property(nonatomic, assign)uint16_t pcdPort;
@property(readwrite, copy)NSString *ipAddress;
@property(readwrite)uint8_t hwVerMajor;
@property(readwrite)uint8_t hwVerMinor;
@property(readwrite)uint8_t swVerMajor;
@property(readwrite)uint8_t swVerMinor;
@property(readwrite)uint8_t camNum;
@property(readwrite)uint8_t transmitterId;
@property(readwrite, copy)NSString *stName;
@property(readwrite, copy)NSString *stSerial;
@property(nonatomic, assign)BOOL connected;
@property(nonatomic, retain)id delegate;
@property(assign)uint16_t *au16_ch_v;
@property(readwrite, copy)NSMutableArray *cameraSockets;

// Function to initialize PSD receiving - not recommended to use directly
-(int)startPSDThread:(uint16_t)pU16Port;

// Function to initialize PCD transmission - not recommended to use directly
-(int)startPCD:(NSString *)pStIp withPCDPort:(uint16_t)pU16Port;

// Function to start PCD sender thread
-(int)startPCDSender:(int)fdSocket;

// Function to start PSD receiver thread
-(int)startPSDReceiver:(int)fdSocket;

-(int)startTcpReceiver;

// Function to start or stop camera 
-(int)upperCamera:(uint8_t)cameraId withStartOrStop:(int)camStart;

-(int)startCameraStream:(int)cameraId;

-(int)stopCameraStream:(int)cameraId;

@end

@implementation WiRC

@synthesize pcd_period;
@synthesize udpSocket, tcpSocket, pcdSocket;
@synthesize psdPort, pcdPort;
@synthesize ctrlRight;
@synthesize hwVerMajor, hwVerMinor, swVerMajor, swVerMinor, ipAddress, stName, stSerial;
@synthesize camNum, transmitterId;
@synthesize connected;
@synthesize delegate;
@synthesize au16_ch_v;
@synthesize cameraSockets;


/** structure to store a camera streaming handler */
typedef struct {
    uint32_t u32_error_cnt;     /**< error counter */
    uint32_t u32_packet_cnt;    /**< packet counter */
    uint32_t u32_exp_framenum;  /**< expected number of the next frame */
    uint32_t u32_exp_offset;    /**< expected offset of the next data */
    struct timeval s_prev_time; /**< previous FPS measurement time */
    double f32_fps;             /**< current FPS value of the stream */
    void* p_vp_arg;
    int cameraId;
} cam_s_handler_t;

#pragma pack(1)
typedef struct {
    uint32_t u32_version;       /**< version and synchronization flags */
    uint32_t u32_frame_num;     /**< index of the jpeg frame */
    uint32_t u32_offset;        /**< offset of the current data in the jpeg frame */
    uint32_t u32_length;        /**< length of the data field */
    uint8_t  au8_data[1];       /**< data contains a jpeg frame chunk */
} l_s_packet_v3_t;

static int cameraNum;


static void* l_tcp_recv_thread_f(void* p_vp_arg);
static void* l_psd_recv_thread_f(void* p_vp_arg);
static int l_start_pcd_sender_f(int p_fd_socket);
static void* l_pcd_send_thread_f(void* p_vp_arg);
static void* l_camera_recv_thread_f(void* p_vp_arg);

static int l_start_camera_streaming_f(void* p_vp_arg); 
static int l_stop_camera_streaming_f(int p_fd_socket);

static int l_cam_stream_init_f(cam_s_handler_t* p_sp_handler);
static int l_cam_stream_recv_f(int p_fd_socket, cam_s_handler_t* p_sp_handler);
static int l_handle_packet_f(const l_s_packet_v3_t* p_sp_packet, uint32_t p_u32_size, cam_s_handler_t* p_sp_handler);
static int l_store_f(const l_s_packet_v3_t* p_sp_packet, /*@unused@*/ cam_s_handler_t* p_sp_handler);
static void l_ntoh_packet_f(l_s_packet_v3_t* p_sp_packet, uint32_t p_u32_size);
static double l_fps_meas_f(uint32_t p_u32_frames, cam_s_handler_t* p_sp_handler);
static void l_print_status_f(const cam_s_handler_t* p_sp_handler);

-(void)setDelegate:(id)delegateObj {
    
    delegate = delegateObj;
}

-(id)initWithIp:(NSString *)Ip {
    
    if((self = [super init])) {
        
        ipAddress = [Ip retain];
        
    }
    
    return self;
}


-(id)initWithHwVersionMajor:(uint8_t)hwVersionMajor withHwVersioMinor:(uint8_t)hwVersionMinor withSwVersionMajor:(uint8_t)swVersionMajor withSwVersionMinor:(uint8_t)swVersionMinor withWrcName:(NSString *)wrcName withSerial:(NSString *)serial withIp:(NSString *)Ip {
    
    if((self = [super init])) {
        
        //delegate = nil;
        
        hwVerMajor = hwVersionMajor;
        hwVerMinor = hwVersionMinor;
        swVerMajor = swVersionMajor;
        swVerMinor = swVersionMinor;
        
        stName = [wrcName retain];
        stSerial = [serial retain];
        
        ipAddress = [Ip retain];
        
        pcd_period = 20000;
        
        self.au16_ch_v =(uint16_t *)malloc(sizeof(uint16_t)*12);
        for(int i = 0; i < 12; i++) {
            self.au16_ch_v[i] = L_U16_CH_FAILSAFE;
        }
        
    }
    
    return self;
}

#pragma mark - Discover

+(NSArray *)WiRCDiscover:(int)sysType withVersionNumberMajor:(int)versionNumberMajor withVersionNumberMinor:(int)versionNumberMinor withTimeout:(float)timeout {
    
    int res;
    int res_recv;
    msg_s_bcsd_t s_bcsd;
    msg_s_bcsa_t s_bcsa;
    msg_s_bcsa_peer_t s_peer;
    int fd_socket;
    struct timeval s_start_time;
    struct timeval s_act_time;
    double f32_diff_time;
    int b_broadcast;
    
    NSMutableArray *wircArray = [NSMutableArray array];
    
    /* create UDP socket for discovery */
    fd_socket = socket(AF_INET, SOCK_DGRAM, 0);
    
    if(fd_socket < 0) {
        
        NSLog(@"Can not create UDP socket for BCSD messages: %s", strerror(errno));
        
    }
    
    /* set broadcast flag */
    b_broadcast = 1;
    res = setsockopt(fd_socket, SOL_SOCKET, SO_BROADCAST, 
                     (char*)&b_broadcast, sizeof(b_broadcast));
    if(res) {
        NSLog(@"Can not set broadcast flag: %d - %s", res, strerror(errno));
        (void)close(fd_socket);
        
    }
    
    /* create BCSD message */
    s_bcsd.u8_sys = sysType;
    s_bcsd.au8_version[0] = versionNumberMajor ;
    s_bcsd.au8_version[1] = versionNumberMinor ;
    
    /* send BCSD */
    res = msg_broadcast_bcsd_f(fd_socket, &s_bcsd);
    if(res) {
        NSLog(@"Can not send broadcast BCSD message %d", res);
        (void)close(fd_socket);
        
    }
    
    NSLog(@"BCSD send");
    
    if(gettimeofday(&s_start_time, NULL)) {
        NSLog(@"Can not get time");
        (void)close(fd_socket);
    }
    
    do {
        
        res_recv = msg_recv_bcsa_f(fd_socket, &s_bcsa, &s_peer);
        //NSLog(@"%@");
        
        if(0 == res_recv) {
            /* BCSA has been received */
            NSLog(@"WRC: %s - %s", s_bcsa.au8_wrc_name, s_peer.st_ip);
            
            char serial_cstr[MSG_MAX_SERIAL_LEN+1];
            strncpy(serial_cstr, (char *)s_bcsa.au8_serial, MSG_MAX_SERIAL_LEN);
            serial_cstr[MSG_MAX_SERIAL_LEN] = '\0';
            
            NSString *serial = [[NSString alloc]initWithCString:serial_cstr encoding:NSUTF8StringEncoding];
            
            char wrcName_cstr[MSG_MAX_NAME_LEN + 1];
            strncpy(wrcName_cstr, (char *)s_bcsa.au8_wrc_name, MSG_MAX_NAME_LEN);
            wrcName_cstr[MSG_MAX_NAME_LEN] = '\0';
            
            NSString *wircName = [[NSString alloc]initWithCString:wrcName_cstr encoding:NSUTF8StringEncoding];
            
            NSString *ip_address = [[NSString alloc]initWithCString:s_peer.st_ip encoding:NSUTF8StringEncoding];
            
            WiRC *wirc = [[WiRC alloc]initWithHwVersionMajor:s_bcsa.au8_hw_ver[0] withHwVersioMinor:s_bcsa.au8_hw_ver[1] withSwVersionMajor:s_bcsa.au8_sw_ver[0] withSwVersionMinor:s_bcsa.au8_sw_ver[1] withWrcName:wircName withSerial:serial withIp:ip_address];
            
            
            //WiRC *wirc = [[WiRC alloc]initWithIp:@"192.168.99.100"];
            [serial release];
            serial = nil;
            
            [wircName release];
            wircName = nil;
            
            [ip_address release];
            ip_address = nil;
            
            [wircArray addObject:wirc];
            [wirc release];
            wirc = nil;
            
        } else {
            /* check timeout */
            if(gettimeofday(&s_act_time, NULL)) {
                NSLog(@"Can not get time");
                break;
            }
            
            f32_diff_time = s_act_time.tv_sec + (s_act_time.tv_usec * 1e-6);
            f32_diff_time -= (s_start_time.tv_sec + (s_start_time.tv_usec * 1e-6));
            if(f32_diff_time > timeout)
                break;
        }
        
    } while(res_recv >= 0);
    if(res_recv < 0) {
        NSLog(@"Can not receive BCSA message %d", res_recv);
    }
    
    //init PCD structure
    
    
    /* close UDP socket */
    res = close(fd_socket);
    if(res) {
        NSLog(@"Can not close BCSD socket: %d - %s", res, strerror(errno));
    }
    
    return wircArray;
    
}

#pragma mark - Send functions

-(int)sendTL:(MessageTL *)msgTL {
    
    Messages *msg = [[Messages alloc]initWithTLMessage:msgTL];
    
    int res;
    msg_s_tl_t s_tl;
    
    //create TL message
    s_tl.u8_sys = msg.m_systemType;
    s_tl.au8_version[0] = msg.m_versionMajor;
    s_tl.au8_version[1] = msg.m_versionMinor;
    s_tl.u8_prio = msg.m_priority;
    
    memset(s_tl.au8_tr_name, 0, MSG_MAX_NAME_LEN);
    strncpy((char*)s_tl.au8_tr_name, L_ST_TR_NAME, MSG_MAX_NAME_LEN);
    
    s_tl.u16_psd_port = msg.m_statusPort;
    
    [msg release];
    msg = nil;
    
    res = msg_send_tl_f(tcpSocket, &s_tl);
    if(res) {
        NSLog(@"Can not send TL message %d", res);
        return res;
    }    
    
    return res;
}

-(int)sendDCFG:(MessageDCFG *)msgDCFG {
    
    Messages *msg = [[Messages alloc]initWithDCFGMessage:msgDCFG];
    
    int res;
    msg_s_dcfg_t s_dcfg;
    
    char *cp_name = msg.m_wrcName;
    memset(s_dcfg.au8_wrc_name, 0, MSG_MAX_NAME_LEN);
    strncpy((char*)s_dcfg.au8_wrc_name, cp_name, MSG_MAX_NAME_LEN);
    
    s_dcfg.u16_cam_off = msg.m_cameraOffV;
    s_dcfg.u16_wrc_off = msg.m_wrcOffV;
    
    [msg release];
    msg = nil;
    
    res = msg_send_dcfg_f(tcpSocket, &s_dcfg);
    if(res) {
        NSLog(@"Can not send DCFG message %d", res);
        return res;
    }
    return res;
}

-(int)sendCCFG:(MessageCCFG *)msgCCFG {
    
    Messages *msg = [[Messages alloc]initWithCCFGMessage:msgCCFG];
    
    int res;
    msg_s_ccfg_t s_ccfg;
    uint32_t u32_index;
    
    for(u32_index = 0u; u32_index < MSG_NUM_CH; ++u32_index) {
        
        s_ccfg.au16_ch_t[u32_index] = [[msg.m_channelsArray objectAtIndex:u32_index]intValue];
        
    }
    
    res = msg_send_ccfg_f(tcpSocket, &s_ccfg);
    if(res) {
        NSLog(@"Can not send CCFG message %d", res);
        return res;
    }    
    
    [msg release];
    msg = nil;
    
    return res;
}

-(int)sendFCFG:(MessageFCFG *)msgFCFG {
    
    Messages *msg = [[Messages alloc]initWithFCFGMessage:msgFCFG];
    
    int res;
    msg_s_fcfg_t s_fcfg;
    uint32_t u32_index;
    
    for(u32_index = 0u; u32_index < MSG_NUM_CH; ++u32_index) {
        
        s_fcfg.au16_ch_v[u32_index] = [[msg.m_failsafeChannelsArray objectAtIndex:u32_index]intValue];
        
    }
    
    res = msg_send_fcfg_f(tcpSocket, &s_fcfg);
    if(res) {
        NSLog(@"Can not send FCFG message %d", res);
        return res;
    }    
    
    [msg release];
    msg = nil;
    
    return res;
}

-(int)sendPCD:(MessagePCD *)msgPCD {
    
    Messages *msg = [[Messages alloc]initWithPCDMessage:msgPCD];
    
    int res;
    msg_s_pcd_t s_pcd;
    uint32_t u32_index;
    
    for(u32_index = 0u; u32_index < MSG_NUM_CH; ++u32_index) {
        
        s_pcd.au16_ch_v[u32_index] = [[msg.m_periodicChannels objectAtIndex:u32_index]intValue];
        
    }
    
    [msg release];
    msg = nil;
    
    res = msg_send_pcd_f(tcpSocket, &s_pcd);
    if(res) {
        NSLog(@"Can not send PCD message %d", res);
        return res;
    }    
    
    return res;
}

-(int)sendWCFG:(MessageWCFG *)msgWCFG {
    
    int res;
    msg_s_wcfg_t s_wcfg;
    
    //Messages *msg = [[Messages alloc]initWithWCFGMessage:msgWCFG];
    
    const char * cStr;
    
    cStr = [msgWCFG.p_ssid cStringUsingEncoding:NSUTF8StringEncoding];
    memset(s_wcfg.au8_ssid, 0, MSG_MAX_SSID_LEN);
    strncpy((char *)s_wcfg.au8_ssid, cStr, MSG_MAX_SSID_LEN);
    
    cStr = [msgWCFG.p_pass cStringUsingEncoding:NSUTF8StringEncoding];
    memset(s_wcfg.au8_pass, 0, MSG_MAX_PASS_LEN);
    strncpy((char *)s_wcfg.au8_pass, cStr, MSG_MAX_PASS_LEN);
    
    if(msgWCFG.p_apMode) {
        
        s_wcfg.u8_ap_mode = 1;
    } else {
        s_wcfg.u8_ap_mode = 0;
    }
    
    if(msgWCFG.p_security) {
        
        s_wcfg.u8_security = 1;
        
    } else {
        s_wcfg.u8_security = 0;
    }
    
    s_wcfg.u8_channel = msgWCFG.p_channel;
    
    cStr = [msgWCFG.p_country cStringUsingEncoding:NSUTF8StringEncoding];
    memset(s_wcfg.au8_country, 0, MSG_MAX_CCODE_LEN);
    strncpy((char *)s_wcfg.au8_country, cStr, MSG_MAX_CCODE_LEN);
    
    if(msgWCFG.p_security && [msgWCFG.p_pass length] < 8) {
        
        NSLog(@"Passwords length is too short: %@", msgWCFG.p_pass);
        return -1;
    }
    res = msg_send_wcfg_f(self.tcpSocket, &s_wcfg);
    if(res) {
        NSLog(@"Can not send WCFG message %d", res);
        return -1;
    }
    
    return res;
}


-(int)sendTLR:(MessageTLR *)msgTLR {
    
    int res;
    
    res = msg_send_tlr_f(self.tcpSocket, nil);
    
    if(res) {
        NSLog(@"Can not send TLR message %d", res);
        return -1;
    }
    
    return res;
}

-(int)sendFWUP:(MessageFWUP *)msgFWUP {
    
    int res;
    
    return res;
}

-(int)sendEST:(MessageEST *)msgEST {
    
    int res;
    
    msg_s_est_t s_est;
    
    s_est.u8_id = msgEST.p_cameraId;
    
    res = msg_send_est_f(tcpSocket, &s_est);
    
    if(res) {
        NSLog(@"Can not send STST message %d", res);
        return res;
    }
    
    return res;
}


-(int)sendExtOut:(int)destination withMsgBody:(const void *)array withLen:(int)length {
    
    msg_s_extout_t s_extout;
    memcpy(s_extout.au8_data, array, length);
    
    s_extout.u8_dst = (uint8_t)destination;
    
    msg_send_extout_f(tcpSocket, &s_extout, length);
    
    return 0;
    
}

-(int)sendSTST:(MessageSTST *)msgSTST {
    
    int res;
    msg_s_stst_t s_stst;
    
    //Messages *msg = [[Messages alloc]initWithSTSTMessage:msgSTST];
    
    s_stst.u8_id = msgSTST.p_cameraId;
    s_stst.u16_port = msgSTST.p_cameraPort;
    
    NSLog(@"id:%d, port:%d", s_stst.u8_id, s_stst.u16_port);
    
    res = msg_send_stst_f(tcpSocket, &s_stst);
    
    if(res) {
        NSLog(@"Can not send STST message %d", res);
        return res;
    }
    
    return res;
}

-(int)sendAREQ:(MessageAREQ *)msgId {
    
    Messages *msg = [[Messages alloc]initWithAREQMessage:msgId];
    
    int res;
    msg_s_areq_t s_areq;
    
    s_areq.u8_id = msg.m_id;
    
    [msg release];
    msg = nil;
    
    res = msg_send_areq_f(tcpSocket, &s_areq);
    if(res) {
        NSLog(@"Can not send AREQ message %d", res);
        return res;
    }    
    
    return res;
}

#pragma mark - Connect

-(int)connect {
    
    int fd_socket;
    int res;
    struct sockaddr_in s_peer;
    
    if([self isConnected]) {
        
        NSLog(@"Already connected");
        return -1;
    }
    
    fd_socket = socket(PF_INET, SOCK_STREAM, 0);
    
    if(fd_socket < 0) {
        
        NSLog(@"Can not create socket %d : %s", fd_socket, strerror(errno));
        
        return -1;
    }
    
    /* initialize sockadd struct */
    memset(&s_peer, '\0', sizeof(s_peer));
    NSLog(@"ipAddressInConnect:%@", ipAddress);
    const char *Ip = [ipAddress UTF8String];
    NSLog(@"ipAddressInConnect:%@", ipAddress);
    
    s_peer.sin_family = AF_INET;
    s_peer.sin_port = htons(L_U16_TCP_PORT);
    s_peer.sin_addr.s_addr = inet_addr(Ip);
    
    /* connect to remote server */
    res = connect(fd_socket, (struct sockaddr*) &s_peer, sizeof(s_peer));
    if(res) {
        NSLog(@"Can not connect to remote server: %@:%d (%d : %s)", 
              ipAddress, L_U16_TCP_PORT, res, (res < 0) ? strerror(errno) : "");
        (void)close(fd_socket);
        //onconnecterror
        return res;
    }
    
    //store fd_socket
    tcpSocket = fd_socket;
    
    if([self startTcpReceiver]) {
        NSLog(@"Can not start TCP receiver");
        return -1;
    }
    
    connected = TRUE;
    [self.delegate onConnect:YES didConnectToHost:ipAddress port:L_U16_TCP_PORT];
    
    //[self sendAreqWithId:78];
    return 0;
}

-(void)disconnect {
    int fd_tcp;
    int fd_psd;
    int fd_pcd;
    
    if (!self.connected) {
        return;
    }
    
    self.connected=FALSE;
    
    fd_tcp=self.tcpSocket;
    fd_pcd=self.pcdSocket;
    fd_psd=self.udpSocket;
    
    self.tcpSocket = -1;
    self.pcdSocket = -1;
    self.udpSocket = -1;
    
    shutdown(fd_tcp, SHUT_RDWR);
    close(fd_tcp);
    
    close(fd_psd);
    close(fd_pcd);

}


-(BOOL)isConnected {
    
    return connected;
}


#pragma mark - Connect and Login

-(int)connectAndLogin {
    
    int res;
    uint16_t u16_psd_port;
    uint16_t u16_pcd_port;
    uint32_t u32_index;
    int fd_ctrl_socket;
    int fd_psd_socket;
    uint32_t u32_timeout_us;
    
    /* start psd thread */    
    res = [self startPSDThread:0];
    if(res) {
        NSLog(@"Can not start PSD %d", res);
        return  res;
    }
    
    /* connect */
    res = [self connect];
    if(res) {
        NSLog(@"Can not connect to WRC control %d", res);
        return res;
    }
    
    /* get WRC connection info */
    @synchronized(self) {
        
        fd_ctrl_socket = self.tcpSocket;
        fd_psd_socket = self.udpSocket;
        u16_psd_port = self.psdPort;
        
    }
    
    /* send TL use port number from PSD thread */    
    MessageTL *msgTL = [[MessageTL alloc]init];
    msgTL.p_systemType = L_U8_SYS_PC;
    msgTL.p_versionMajor = L_U8_VERSION_MAJOR;
    msgTL.p_versionMinor = L_U8_VERSION_MINOR;
    msgTL.p_priority = 0;
    
    msgTL.p_name = L_ST_TR_NAME;
    msgTL.p_statusPort = u16_psd_port;
    
    res = [self sendTL:msgTL];
    
    [msgTL release];
    msgTL = nil;
    
    if(res) {
        NSLog(@"Can not send TL message %d", res);
        return res;
    }
    
    
    /* send DCFG */
    MessageDCFG *msgDCFG = [[MessageDCFG alloc]init];
    msgDCFG.p_wrcName = L_ST_WRC_NAME;
    msgDCFG.p_cameraOffV = L_U16_CAM_OFF;
    msgDCFG.p_wrcOffV = L_U16_WRC_OFF;
    
    /* DCFG message is disabled during initialize process */
#if 0
    res = [self sendDCFG:msgDCFG];
    if(res) {
        NSLog(@"Can not send DCFG %d", res);
        return res;
    }
#endif
    
    /* send CCFG */
    MessageCCFG *msgCCFG = [[MessageCCFG alloc]init];
    msgCCFG.p_channelsArray = [[NSMutableArray alloc]init];
    NSNumber *periodObj = [[NSNumber alloc]initWithInt:MSG_U16_CH_PERIOD];
    for(u32_index = 0u; u32_index < MSG_NUM_CH; ++u32_index) {
        [msgCCFG.p_channelsArray addObject:periodObj];
    }
    [periodObj release];
    
    res = [self sendCCFG:msgCCFG];
    
    if(res) {
        NSLog(@"Can not send CCFG message");
        return res;
    }
    
    [msgCCFG.p_channelsArray release];
    msgCCFG = nil;
    
    [msgDCFG release];
    msgDCFG = nil;
    
    [msgCCFG release];
    msgCCFG = nil;
    
    @synchronized(self) {
        
        self.psdPort = 0;
        
    }
    
    /* send FCFG */
    MessageFCFG *msgFCFG = [[MessageFCFG alloc]init];
    msgFCFG.p_failsafeChannelsArray = [[NSMutableArray alloc]init];
    NSNumber *failsafeObj = [[NSNumber alloc]initWithInt:MSG_U16_CH_FAILSAFE];
    for(u32_index = 0u; u32_index < MSG_NUM_CH; ++u32_index) {
        [msgFCFG.p_failsafeChannelsArray addObject:failsafeObj];
    }
    [failsafeObj release];
    res = [self sendFCFG:msgFCFG];
    
    if(res) {
        NSLog(@"Can not send FCFG message %d", res);
        return res;
    }
    
    [msgFCFG.p_failsafeChannelsArray release];
    msgFCFG.p_failsafeChannelsArray = nil;
    
    [msgFCFG release];
    msgFCFG = nil;
    
    /* wait for WST */    
    u32_timeout_us = 0u;
    do {
        u16_pcd_port = self.pcdPort;
        
        (void)usleep(L_U32_WST_SLEEP_US);
        u32_timeout_us += L_U32_WST_SLEEP_US;
    } while((0 == u16_pcd_port) && (u32_timeout_us < L_U32_WST_TIMEOUT_US));
    if(0 == u16_pcd_port) {
        NSLog(@"WST wait timeout has been expired (%d sec)", (L_U32_WST_TIMEOUT_US / 1000000));
        return -1;
    }
    
    /* start pcd thread using port from WST */
    res = [self startPCD:nil withPCDPort:u16_pcd_port];
    if(res) {
        NSLog(@"Can not start PCD thread");
        return -1;
    }
    
    MessageTLR *msgTLR = [[MessageTLR alloc]init];
    
    [self sendTLR:msgTLR];
    
    [msgTLR release];
    msgTL = nil;
    
    return 0;
}

#pragma mark - PSD thread

-(int)startPSDThread:(uint16_t)pU16Port {
    
    struct sockaddr_in s_psd_peer;
    int fd_psd_socket;
    int res;
    struct sockaddr_in s_udp_sock;
    socklen_t len_sock;
    uint16_t u16_psd_port;
    
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc]init];
    
    /* create UDP socket */
    memset(&s_psd_peer, 0, sizeof(s_psd_peer));
    s_psd_peer.sin_family = AF_INET;
    s_psd_peer.sin_port = htons(pU16Port);
    s_psd_peer.sin_addr.s_addr = htonl(INADDR_ANY);
    fd_psd_socket = socket(PF_INET, SOCK_DGRAM, 0);
    if(fd_psd_socket < 0) {
        NSLog(@"Can not create socket %d : %s", fd_psd_socket, strerror(errno));
        return -1;
    }
    res = bind(fd_psd_socket, (struct sockaddr*)&s_psd_peer, sizeof(s_psd_peer));
    if(res < 0) {
        NSLog(@"Can not bind to port [%d] - %d : %s", pU16Port, res, strerror(errno));
        (void)close(fd_psd_socket);
        return -1;
    }
    res = [self startPSDReceiver:fd_psd_socket];
    if(res) {
        NSLog(@"Can not start PSD receiver (%d)", res);
        (void)close(fd_psd_socket);
        return -1;
    }
    memset(&s_udp_sock, 0, sizeof(s_udp_sock));
    s_udp_sock.sin_family = AF_INET;
    len_sock = sizeof(s_udp_sock);
    res = getsockname(fd_psd_socket, (struct sockaddr*)&s_udp_sock, &len_sock);
    if(res) {
        NSLog(@"Can not get PSD socket options %d - %s", res, strerror(errno));
        return -1;
    }
    if(len_sock != sizeof(s_udp_sock)) {
        NSLog(@"Invalid socket length returned %d instead of %lu", len_sock, sizeof(s_udp_sock));
        return -1;
    }
    u16_psd_port = ntohs(s_udp_sock.sin_port);
    
    @synchronized(self) {
        
        self.psdPort = u16_psd_port;
        
    }
    
    [pool release];
    
    return 0;
}

-(int)startPSDReceiver:(int)fdSocket {
    
    pthread_t thread;
    pthread_attr_t attr;
    
    self.udpSocket = fdSocket;
    
    if(pthread_attr_init(&attr)) {
        NSLog(@"pthread attr init error");
        return -1;
    }
    if(pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED)) {
        NSLog(@"pthread attr set detached error");
        return -1;
    }
    if(pthread_create(&thread, &attr, l_psd_recv_thread_f, (void *)self)) {
        NSLog(@"pthread create error");
        return -1;
    }
    return 0;
}

/** Internal thread to receive periodic status data (PSD) messages
 *
 *  @param  p_vp_arg    reference to the socket shall be read
 *  @return always NULL
 *
 *  The thread receives receives and parses PSD messages from an UDP socket.
 */
static void* l_psd_recv_thread_f(void* p_vp_arg) {
    
    int fd_socket = -1;
    int res;
    msg_s_message_t s_msg;
    msg_s_psd_t *sp_psd;
    WiRC *wirc;
    
    NSLog(@"start of PSD receiver thread");
    
    if(p_vp_arg) {
        
        wirc = (WiRC *)p_vp_arg;
        fd_socket=wirc->udpSocket;
    }
    NSLog(@"fdSocket:%d", fd_socket);
    
    while(0 <= (res = msg_recv_message_f(fd_socket, &s_msg))) {
        sp_psd = (msg_s_psd_t *)s_msg.au8_body;
        @synchronized(wirc) {
            
            MessagePSD *msgPsd = [[MessagePSD alloc]init];
            //msgPsd.psdArray = [[NSMutableArray alloc]init];
            
            //NSLog(@"Batt1: %d mV", sp_psd->au16_batt[0]);
            //NSLog(@"Batt2: %d mV", sp_psd->au16_batt[1]);
            
            msgPsd.batt1 = sp_psd->au16_batt[0];
            msgPsd.batt2 = sp_psd->au16_batt[1];
            msgPsd.in1 = sp_psd->au8_input[0];
            msgPsd.in2 = sp_psd->au8_input[1];
            msgPsd.in3 = sp_psd->au8_input[2];
            msgPsd.in4 = sp_psd->au8_input[3];
            
            [wirc.delegate didReceivedPSD:msgPsd];
            
            //msgPsd.psdArray = nil;
            [msgPsd release];
            msgPsd = nil;
            
            /* store received message */
            memcpy(&l_s_psd_msg, &s_msg, sizeof(l_s_psd_msg));            
            
        }
    }
    
    NSLog(@"end of PSD receiver thread");
    
    pthread_exit(NULL);
    return NULL;
}


#pragma mark - PCD thread

-(int)startPCD:(NSString *)pStIp withPCDPort:(uint16_t)pU16Port {
    
    struct sockaddr_in s_pcd_peer;
    int fd_pcd_socket;
    int res;
    
    @synchronized(self) {
        /* create UDP socket */
        s_pcd_peer.sin_family = AF_INET;
        s_pcd_peer.sin_port = htons(pU16Port);
        if(nil == pStIp) {
            const char *cStr = [ipAddress cStringUsingEncoding:NSUTF8StringEncoding];
            
            s_pcd_peer.sin_addr.s_addr = inet_addr(cStr);
            
        }
        else {
            const char *chStr = [pStIp cStringUsingEncoding:NSUTF8StringEncoding];
            
            s_pcd_peer.sin_addr.s_addr = inet_addr(chStr);
        }
        
        fd_pcd_socket = socket(PF_INET, SOCK_DGRAM, 0);
        self.pcdSocket = fd_pcd_socket;
        
    }
    if(fd_pcd_socket < 0) {
        NSLog(@"Can not create socket %d : %s", fd_pcd_socket, strerror(errno));
        return -1;
    }
    res = connect(fd_pcd_socket, (struct sockaddr*)&s_pcd_peer, sizeof(s_pcd_peer));
    if(res < 0) {
        NSLog(@"Can not connect to peer %d : %s", res, strerror(errno));
        return -1;
    }
    
    res = [self startPCDSender:fd_pcd_socket];
    if(res) {
        NSLog(@"Can not start PCD sender (%d)", res);
        return -1;
    }
    return 0;
}


-(int)startPCDSender:(int)fdSocket {
    
    pthread_t thread;
    pthread_attr_t attr;
    static int l_fd_socket;
    
    l_fd_socket = fdSocket;
    if(pthread_attr_init(&attr)) {
        NSLog(@"pthread attr init error");
        return -1;
    }
    if(pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED)) {
        NSLog(@"pthread attr set detached error");
        return -1;
    }
    if(pthread_create(&thread, &attr, l_pcd_send_thread_f, self)) {
        NSLog(@"pthread create error");
        return -1;
    }
    
    return 0;
    
}

-(int)startTcpReceiver {
    
    pthread_t thread;
    pthread_attr_t attr;
    
    if(pthread_attr_init(&attr)) {
        NSLog(@"pthread attr init error");
        return -1;
    }
    
    if(pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED)) {
        NSLog(@"pthread attr set detached error");
        return -1;
    }
    
    if(pthread_create(&thread, &attr, l_tcp_recv_thread_f, (void *)self)) {
        NSLog(@"pthread create error");
        return -1;
    }
    
    return 0;
}

static void* l_tcp_recv_thread_f(void* p_vp_arg) {
    
    WiRC *wirc = nil;
    int fd_socket = -1;
    int res;
    msg_s_message_t s_msg;
    
    NSLog(@"start of tcp receiver thread");
    
    if(p_vp_arg) {
        
        wirc = (WiRC *)p_vp_arg;
        fd_socket = wirc->tcpSocket;
    }
    while(0 <= (res = msg_recv_message_f(fd_socket, &s_msg))) {
        
        MessageTCP *msgTcp = [[MessageTCP alloc]init];
        msgTcp.tcpArray = [[NSMutableArray alloc]init];
        
        for (int i = 0; i < 256; i++) {
            NSNumber *tempNum = [[NSNumber alloc]initWithInt:s_msg.au8_body[i]];
            [msgTcp.tcpArray addObject:tempNum];
            [tempNum release];
            tempNum = nil;
        }
        
        [wirc.delegate didReceivedTCP:msgTcp];
        
        [msgTcp.tcpArray release];
        msgTcp.tcpArray = nil;
        [msgTcp release];
        msgTcp = nil;
        
        @synchronized(wirc) {
            
            /* store received message */
            memcpy(&l_s_ctrl_msg, &s_msg, sizeof(l_s_ctrl_msg));
            
        }
        /* filter for messages */
        NSLog(@"CMD:%d", s_msg.u8_cmd);
        if((MSG_CMD_WST == s_msg.u8_cmd) ||
           (MSG_CMD_AGR == s_msg.u8_cmd)) {
            /* WST and AGR messages influences the connection struct */
            @synchronized(wirc) {
                
                if(MSG_CMD_WST == s_msg.u8_cmd) {
                    msg_s_wst_t* sp_wst;
                    sp_wst = (msg_s_wst_t*)s_msg.au8_body;
                    /* store transmitter ID number of cameras and PCD port */
                    wirc.transmitterId = sp_wst->u8_id;
                    wirc.pcdPort = sp_wst->u16_pcd_port;
                    wirc.camNum = sp_wst->u8_cn;
                } else if(MSG_CMD_AGR == s_msg.u8_cmd) {
                    msg_s_agr_t* sp_agr;
                    sp_agr = (msg_s_agr_t*)s_msg.au8_body;
                    /* check AGR notif byte */
                    char trname_cstr[MSG_MAX_NAME_LEN + 1];
                    strncpy(trname_cstr, (char *)sp_agr->au8_tr_name, MSG_MAX_NAME_LEN);
                    trname_cstr[MSG_MAX_NAME_LEN] = '\0';
                    
                    NSString *trName = [[NSString alloc]initWithCString:trname_cstr encoding:NSUTF8StringEncoding];
                    
                    uint8_t trId = sp_agr->u8_id;
                    uint8_t trPrio = sp_agr->u8_prio;
                    uint8_t notif = sp_agr->u8_notif;
                    
                    switch(sp_agr->u8_notif) {
                        case MSG_U8_NOTIF_GRANTED:
                            /* access granted - enable PCD sending */
                            wirc.ctrlRight = true;
                            break;
                        case MSG_U8_NOTIF_LOST:
                            /* access lost - disable PCD sending */
                            wirc.ctrlRight = false;
                            break;
                    }
                    
                    [wirc.delegate didReceivedAGR:trName withTransmitterId:trId withTransmitterPriority:trPrio withNotif:notif];
                    [trName release];
                    trName = nil;
                } 
            }
            
        } else if(MSG_CMD_ERR == s_msg.u8_cmd) {
            msg_s_err_t* sp_err_msg = (msg_s_err_t*)s_msg.au8_body;
            uint16_t errorCode = sp_err_msg->u16_err_code;
            uint8_t cmdCode = sp_err_msg->u8_cmd;
            [wirc.delegate didReceivedErrorMsg:errorCode withCmdCode:cmdCode];
            
        }
    }
    
    NSLog(@"end of tcp receiver thread");
    
    [wirc.delegate onConnect:NO didConnectToHost:wirc.ipAddress port:L_U16_TCP_PORT];
    
    pthread_exit(NULL);
    return NULL;
}

/** Internal thread to send Periodic Channel Data (PCD) messages 
 *
 *  @param  p_vp_arg    reference to the socket shall be written
 *  @return always NULL
 *
 *  The function sends PCD messages with a defined period time.
 */
static void* l_pcd_send_thread_f(void* p_vp_arg)  {
    
    int fd_socket = -1;
    int res;
    msg_s_pcd_t s_pcd;
    uint32_t u32_delay;
    int b_ctrl_right;
    WiRC *wirc;
    
    
    NSLog(@"start of PCD transmitter thread");
    
    if(p_vp_arg) {
        
        wirc = (WiRC *)p_vp_arg;
        fd_socket = wirc->pcdSocket;
        
    }
    
    while(1) {
        
        @synchronized(wirc) {
            
            /* get control right */
            b_ctrl_right = wirc.ctrlRight;
            
            /* get PCD values */
            u32_delay = wirc.pcd_period;
            
            for(int index = 0; index < MSG_NUM_CH; ++index) {
                s_pcd.au16_ch_v[index] = wirc->au16_ch_v[index];
            }
        }
        /* check access control right */
        if(b_ctrl_right) {
            res = msg_send_pcd_f(fd_socket, &s_pcd);
            if(res < 0) {
                NSLog(@"fdSocket:%d", fd_socket);
                NSLog(@"Can not send PCD");
                break;
            }
            
        }
        
        (void)usleep(u32_delay);
    }
    
    NSLog(@"end of PCD transmitter thread");
    [wirc disconnect];
    
    pthread_exit(NULL);
    
    return NULL;
    
}

#pragma mark - set channel

-(int)setChannel:(uint8_t)channel withValue:(uint16_t)chValue {
    
    uint32_t u32_index;
    
    if((0u == channel) || (channel > MSG_NUM_CH)) {
        NSLog(@"channel identifier (%d) is out of range (1..%d)", channel, MSG_NUM_CH);
        return -1;
    }
    u32_index = channel - 1u;
    
    @synchronized(self) {
        
        au16_ch_v[u32_index] = chValue;
    }
    
    return 0;
}

#pragma mark - camera handling

-(int)upperCamera:(uint8_t)cameraId withStartOrStop:(int)camStart {
    
    int res;
    int ctrlSocket = -1;
    int camSocket = -1;
    struct sockaddr_in s_cam_sock;
    socklen_t len_sock;
    uint16_t u16_cam_port;
    
    /* get control socket */
    @synchronized(self) {
        
        ctrlSocket = self.tcpSocket;
        
    }
    
    /* execute start or stop */
    if(camStart) {
        /* start camera stream receiver */
        res = [self startCameraStream:cameraId];
        if(res) {
            NSLog(@"Can not start camera streaming for %d (%d)", cameraId, res);
            return -1;
        }
        
        /* get camera socket */
        @synchronized(self) {
            
            if(cameraId < L_U8_MAX_CAMERA_NUM) {
                camSocket = [[cameraSockets objectAtIndex:0]intValue];
            }
        }
        
        /* get streaming port */
        memset(&s_cam_sock, 0, sizeof(s_cam_sock));
        s_cam_sock.sin_family = AF_INET;
        len_sock = sizeof(s_cam_sock);
        res = getsockname(camSocket, (struct sockaddr*)&s_cam_sock, &len_sock);
        if(res) {
            NSLog(@"Can not get socket info for socket %d: %d - %s", camSocket, res, strerror(errno));
            return -1;
        }
        if(len_sock != sizeof(s_cam_sock)) {
            NSLog(@"Invalid socket length returned %d instead of %lu", len_sock, sizeof(s_cam_sock));
            return -1;
        }
        u16_cam_port = ntohs(s_cam_sock.sin_port);
        
        /* send STST message */
        MessageSTST *msgSTST = [[MessageSTST alloc]initSTSTWithCameraId:cameraId withPort:u16_cam_port];
        
        res = [self sendSTST:msgSTST];
        
        [msgSTST release];
        msgSTST = nil;
        
        if(res) {
            NSLog(@"Can not send STST %d", res);
            return -1;
        }
        
    } else { 
        /* stop */
        res = [self stopCameraStream:cameraId];
        
        if(res) {
            NSLog(@"Can not stop camera streaming");
            return -1;
        }
        
        /* send EST */
        MessageEST *msgEST = [[MessageEST alloc]initESTWithId:cameraId];
        
        res = [self sendEST:msgEST];
        
        [msgEST release];
        msgEST = nil;
        
        if(res) {
            NSLog(@"Can not send EST message (%d)", res);
            return -1;
        }
    }
    
    return 0;
}

-(int)startCameraWithId:(int)cameraId {
    return [self upperCamera:cameraId withStartOrStop:1];
}

-(int)startCameraStream:(int)cameraId {
    
    int res;
    struct sockaddr_in s_cam_sock;
    int fd_cam_socket;
    
    if(cameraId >= L_U8_MAX_CAMERA_NUM) {
        NSLog(@"Camera ID %d is out of maximal camera number range %d", cameraId, L_U8_MAX_CAMERA_NUM);
        return -1;
    }
    /* initialize camera socket */
    memset(&s_cam_sock, 0, sizeof(s_cam_sock));
    s_cam_sock.sin_family = AF_INET;
    s_cam_sock.sin_port = 0;    /* automatic port allocation */
    s_cam_sock.sin_addr.s_addr = htonl(INADDR_ANY);
    fd_cam_socket = socket(PF_INET, SOCK_DGRAM, 0);
    if(fd_cam_socket < 0) {
        NSLog(@"Can not create camera socket %d - %s", fd_cam_socket, strerror(errno));
        return -1;
    }
    /* bind to the socket */
    res = bind(fd_cam_socket, (struct sockaddr*)&s_cam_sock, sizeof(s_cam_sock));
    if(res) {
        NSLog(@"Can not bind to camera port %d - %s", res, strerror(errno));
        (void)close(fd_cam_socket);
        return -1;
    }
    
    if(cameraId < L_U8_MAX_CAMERA_NUM) {
        
        NSNumber *socketNum = [NSNumber numberWithInt:fd_cam_socket];

        self.cameraSockets = [NSMutableArray arrayWithObjects:socketNum, nil];
    }
    /* start camera streaming thread */
    res = l_start_camera_streaming_f(self);
    if(res) {
        NSLog(@"Can not start camera stream receiver thread %d", res);
        (void)close(fd_cam_socket);
        return -1;
    }
    /* add socket to the camera socket list */
    NSLog(@"Camera socket: %d camera ID: %d", fd_cam_socket, cameraId);
    
    return 0;
}


static int l_start_camera_streaming_f(void* p_vp_arg) 
{
    pthread_t thread;
    pthread_attr_t attr;
    
    WiRC *wirc;
    wirc = (WiRC *)p_vp_arg;
    
    //l_fd_socket = p_fd_socket;
    
    if(pthread_attr_init(&attr)) {
        NSLog(@"pthread attr init error");
        return -1;
    }
    if(pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED)) {
        NSLog(@"pthread attr set detached error");
        return -1;
    }
    if(pthread_create(&thread, &attr, l_camera_recv_thread_f, wirc)) {
        NSLog(@"pthread create error");
        return -1;
    }
    return 0;
}


/** Internal function to stop Camera stream receiver thread 
 *
 *  @param  p_fd_socket     socket used for camera stream receiving
 *  return zero in case of success
 *
 *  The function closes the socket that triggers receiver thread to stop.
 */
static int l_stop_camera_streaming_f(int p_fd_socket) 
{
    
    uint32_t u32_num;
    int return_value;
    
    return_value = close(p_fd_socket);
    
    if(cameraNum > 0u)
        u32_num = cameraNum--;
    
     return return_value;
}


-(int)stopCameraWithId:(int)cameraId {
    return [self upperCamera:cameraId withStartOrStop:0];
}

-(int)stopCameraStream:(int)cameraId {
   
    int res;
    int fdCamSocket = -1;
    
    if(cameraId >= L_U8_MAX_CAMERA_NUM) {
        NSLog(@"Camera ID %d is out of maximal camera number range %d", cameraId, L_U8_MAX_CAMERA_NUM);
        return -1;
    }
    /* add socket to the camera socket list */
    @synchronized(self) {
        NSLog(@"Can not lock Camera mutex");
        (void)close(fdCamSocket);
        return -1;
    }
    
    if(cameraId < L_U8_MAX_CAMERA_NUM) {
        
        fdCamSocket = [[self.cameraSockets objectAtIndex:cameraId]intValue];
        NSNumber *socketNum = [NSNumber numberWithInt:-1];
        [self.cameraSockets insertObject:socketNum atIndex:cameraId];
        
    }
    @synchronized(self) {
        NSLog(@"Can not unlock Camera mutex");
        (void)close(fdCamSocket);
        return -1;
    }
    res = l_stop_camera_streaming_f(fdCamSocket);
    
    if(res) {
        NSLog(@"Can not stop %d. camera streaming %d", cameraId, res);
        return -1;
    }
    return 0;
}

/** Internal thread to receive Camera stream
 *
 *  @param  p_vp_arg    reference to the socket shall be read
 *  @return always NULL
 *
 *  The thread receives and processes Camera stream
 */
static void* l_camera_recv_thread_f(void* p_vp_arg)
{
    WiRC *wirc;
    int fd_socket = -1;
    int res;
    cam_s_handler_t s_cam_handler;
    
    NSLog(@"start of Camera receiver thread");
    
    res = l_cam_stream_init_f(&s_cam_handler);
    
    if(p_vp_arg) {
        
        wirc = (WiRC *)p_vp_arg;
        fd_socket = [[wirc->cameraSockets objectAtIndex:0]intValue];
        s_cam_handler.p_vp_arg = wirc;
        NSLog(@"fdSocket:%@", wirc->cameraSockets);
    }
    
    if(res) {
        NSLog(@"Can not initialize camera streaming %d", res);
        pthread_exit(NULL);
        return NULL;
    }
    
    cameraNum++;
    
    while(0 <= (res = l_cam_stream_recv_f(fd_socket, &s_cam_handler))) {
        
    }
    
    NSLog(@"end of Camera receiver thread");
    
    pthread_exit(NULL);
    
    return NULL;
}

/* Function to initialize a camera connection */
static int l_cam_stream_init_f(cam_s_handler_t* p_sp_handler)
{
    /* check argument */
    if(NULL == p_sp_handler) {
        NSLog(@"Camera init argument is NULL");
        return -1;
    }
    
    return 0;
}

/* Function to receive handle MJPEG-stream */
static int l_cam_stream_recv_f(int p_fd_socket, cam_s_handler_t* p_sp_handler)
{
    
    int return_value = 0;
    uint8_t au8_buffer[L_U32_HEADER_SIZE + L_U32_MAX_DATA];
    l_s_packet_v3_t* sp_packet = (l_s_packet_v3_t*) au8_buffer;
    uint32_t u32_max_size = sizeof(au8_buffer);
    uint32_t u32_size;
    int res;
    
    /* check arguments */
    if(NULL == p_sp_handler) {
        NSLog(@"Camera recv argument is NULL");
        return -1;
    }
    /* receive from UDP socket */
    res = recv(p_fd_socket, sp_packet, u32_max_size, 0);
    if(res < 0) {
        NSLog(@"recv error %d - %s", res, strerror(errno));
        return -1;
    }
    u32_size = res;
    
    /* byte order convert of the packet */
    l_ntoh_packet_f(sp_packet, u32_size);
    
    /* handle received packet */
    res = l_handle_packet_f(sp_packet, u32_size, p_sp_handler);
    if(res < 0) {
        NSLog(@"packet handling error (%d)", res);
    } else if(res > 0) {
        p_sp_handler->u32_error_cnt++;
        return_value = 1;
    }
    p_sp_handler->u32_packet_cnt++;
    l_print_status_f(p_sp_handler);
    
    return return_value;
}


/** Internal function to handle received packet 
 *
 *  @param  p_sp_packet     reference to the received packet 
 *  @param  p_u32_size      the size of the received packet 
 *  @param  p_sp_handler    handler of the camera streaming
 *  @param  0 in case of success, -1 in case of unexpected error, 1 in case of wrong packet.
 */
static int l_handle_packet_f(const l_s_packet_v3_t* p_sp_packet, uint32_t p_u32_size, cam_s_handler_t* p_sp_handler)
{
    int res;
    uint32_t u32_exp_length;
    
    /* check argument */
    if(NULL == p_sp_packet) {
        NSLog(@"NULL argument for packet handler!");
        return -1;
    }
    
    /* check packet size */
    if(p_u32_size < sizeof(p_sp_packet->u32_version)) {
        NSLog(@"received packet is too small");
        return 1;
    }
    
    /* check version */
    if(!L_IS_VERSION(p_sp_packet->u32_version)) {
        NSLog(@"Version mismatch!");
        return 1;
    }
    
    /* check if packet is only a header */
    if(sizeof(p_sp_packet->u32_version) == p_u32_size)
        return 0;
    
    /* check packet size */
    u32_exp_length = p_u32_size - L_U32_HEADER_SIZE;
    if(p_sp_packet->u32_length != u32_exp_length) {
        NSLog(@"recv size error: length: %d, expected: %d",
              p_sp_packet->u32_length, u32_exp_length);
        return 1;
    }
    
#ifdef CHECK_CAMERA_FRAME
    /* check frame number */
    if(p_sp_handler->u32_exp_framenum < p_sp_packet->u32_frame_num) {
        NSLog(@"frame number error: %d expected: %d",
              p_sp_packet->u32_frame_num, p_sp_handler->u32_exp_framenum);
        p_sp_handler->u32_exp_framenum = p_sp_packet->u32_frame_num + 1;
        p_sp_handler->u32_exp_offset = 0u;
        return 1;
    }
#endif
    
#ifdef CHECK_CAMERA_OFFSET
    /* check offset */
    if(p_sp_handler->u32_exp_offset != p_sp_packet->u32_offset) {
        NSLog(@"offset error: %d expected: %d in frame %d",
              p_sp_packet->u32_offset, p_sp_handler->u32_exp_offset, 
              p_sp_packet ->u32_frame_num);
        p_sp_handler->u32_exp_framenum = p_sp_packet->u32_frame_num + 1;
        p_sp_handler->u32_exp_offset = 0u;
        return 1;
    }
#endif
    
    /* calculate next expected */
    if(L_IS_LAST(p_sp_packet->u32_version)) {
        p_sp_handler->u32_exp_framenum++;
        p_sp_handler->u32_exp_offset = 0;
        if(0 == (p_sp_handler->u32_exp_framenum % L_U32_FPS_FRAMES)) {
            p_sp_handler->f32_fps = l_fps_meas_f(L_U32_FPS_FRAMES, p_sp_handler);
        }
    } else {
        p_sp_handler->u32_exp_offset += p_sp_packet->u32_length;
    }
    /* store data */
    res = l_store_f(p_sp_packet, p_sp_handler);
    if(res) 
        return res;
    
    return 0;
}

/** Internal function to store packet data 
 *
 *  @param  p_sp_packet     packet descriptor 
 *  @param  p_sp_handler    handler of the camera streaming
 *  @return 0 in case of success
 *
 */
static int l_store_f(const l_s_packet_v3_t* p_sp_packet, /*@unused@*/ cam_s_handler_t* p_sp_handler)
{
    
    WiRC *wirc;
    
	uint8_t* u8p_pos;
    uint32_t u32_length;
	
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc]init];

    u32_length = p_sp_packet->u32_offset + p_sp_packet->u32_length;
    if(u32_length > L_U32_MAX_IMG_SIZE) {
        NSLog(@"Packet reference is invalid (offs: %d) (len: %d) sum: %d",
              p_sp_packet->u32_offset, p_sp_packet->u32_length, u32_length);
        return -1;
    }
    if(p_sp_packet->u32_length > 0u) {
        u8p_pos = l_au8_image + p_sp_packet->u32_offset;
        memcpy(u8p_pos, p_sp_packet->au8_data, p_sp_packet->u32_length);
    }
	
    if(L_IS_LAST(p_sp_packet->u32_version)) {
        
        UIImage * img = [[UIImage alloc] initWithData:[NSData dataWithBytes:l_au8_image length: u32_length]];
        
        wirc = (WiRC *)p_sp_handler->p_vp_arg;
        
        [wirc.delegate didReceivedCameraFrameNum: p_sp_packet->u32_frame_num withImage:img];
        
        [img release];
        img = nil;
        
	}

    [pool release];
    
    return 0;
    
}

/** Internal function to print status line */
static void l_print_status_f(const cam_s_handler_t* p_sp_handler)
{
#if 0
    double error_rate;
    
    error_rate = (double) p_sp_handler->u32_error_cnt / p_sp_handler->u32_packet_cnt;
    printf("FPS: %lf, errno: %ld, err.rate: %lf %%        ", 
           p_sp_handler->f32_fps, (long)p_sp_handler->u32_error_cnt, error_rate*100.0);
#endif
}

/** Internal function to measure FPS
 *
 *  @param  p_u32_frames    number of frames have been received since the last call
 *  @param  p_sp_handler    handler of the camera streaming
 *  @return calculated FPS value
 *
 *  FPS = (p_u32_frames) / (curr_time - prev_time).
 */
static double l_fps_meas_f(uint32_t p_u32_frames, cam_s_handler_t* p_sp_handler)
{
    struct timeval curr_time;
    double diff_time;
    double fps;
    
    /* get current time */
    if(gettimeofday(&curr_time, NULL)) {
        return 0.0;
    }
    
    /* calculate difference */
    diff_time = curr_time.tv_sec - p_sp_handler->s_prev_time.tv_sec;
    diff_time += (curr_time.tv_usec - p_sp_handler->s_prev_time.tv_usec) / 1e6;
    
    /* calculate fps */
    if(diff_time > 0)
        fps = (double)p_u32_frames / diff_time;
    else
        fps = 0.0;
    
    /* store as current time */
    p_sp_handler->s_prev_time = curr_time;
    
    /* return FPS */
    return fps;
}

/** Internal function to convert the packet fields to host byte order
 *
 *  @param  p_sp_packet     packet shall be converted
 *  @param  p_u32_size      size of the packet shall be converted
 *  
 *  The function converts the fields of a packet.
 *  If the p_u32_size is less than a packet header size 
 *  then only version field is converted.
 */
static void l_ntoh_packet_f(l_s_packet_v3_t* p_sp_packet, uint32_t p_u32_size)
{
    /* check argument */
    if(NULL == p_sp_packet)
        return;
    
    /* check size */
    if(p_u32_size >= sizeof(p_sp_packet->u32_version)) {
        /* convert version field */
        p_sp_packet->u32_version = ntohl(p_sp_packet->u32_version);
    }
    if(p_u32_size >= L_U32_HEADER_SIZE) {
        /* convert full packet header */
        p_sp_packet->u32_frame_num = ntohl(p_sp_packet->u32_frame_num);
        p_sp_packet->u32_offset = ntohl(p_sp_packet->u32_offset);
        p_sp_packet->u32_length = ntohl(p_sp_packet->u32_length);
    }
}



-(void)dealloc {
    
    [stName release];
    stName = nil;
    
    [stSerial release];
    stSerial = nil;
    
    [ipAddress release];
    ipAddress = nil;
    
    free(au16_ch_v);
    
    [super dealloc];
}

@end
