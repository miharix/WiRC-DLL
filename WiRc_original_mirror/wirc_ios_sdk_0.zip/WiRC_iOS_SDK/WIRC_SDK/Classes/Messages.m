//
//  Messages.m
//  WiRCExample
//
//  Created by Jagicza József on 11/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Messages.h"
#import "MessageTL.h"
#import "MessageDCFG.h"
#import "MessageCCFG.h"
#import "MessageFCFG.h"
#import "MessagePCD.h"
#import "MessageWCFG.h"
#import "MessageAREQ.h"
#import "MessageFWUP.h"
#import "MessageSTST.h"
#import "MessageEST.h"
#import "MessageEXTOUT.h"
#import "MessageTCP.h"

@implementation Messages

@synthesize destination, commandCode;
@synthesize m_name, m_priority, m_statusPort, m_systemType, m_versionMajor, m_versionMinor;
@synthesize m_wrcName, m_wrcOffV, m_cameraOffV;
@synthesize m_channelsArray;
@synthesize m_failsafeChannelsArray;
@synthesize m_periodicChannels;
@synthesize m_msgArray;
@synthesize m_id;
@synthesize m_destination, m_array, m_length;
@synthesize m_tcp_Array;
@synthesize m_ssid, m_pass, m_apMode, m_security, m_channel, m_country;
@synthesize m_cameraId, m_cameraPort;

-(id)initWithTLMessage:(MessageTL *)msgTL {
    
    if((self = [super init])) {
        
        self.destination = @"WRCD";
        commandCode = 0x11;
        
        m_name = msgTL.p_name;
        m_priority = msgTL.p_priority;
        m_statusPort = msgTL.p_statusPort;
        m_systemType = msgTL.p_systemType;
        m_versionMajor = msgTL.p_versionMajor;
        m_versionMinor = msgTL.p_versionMinor;
        
    }
    
    return self;
}

-(id)initWithDCFGMessage:(MessageDCFG *)msgDCFG {
    
    if((self = [super init])) {
        
        self.destination = @"WRCD";
        commandCode = 0x12;
        
        self.m_wrcName = msgDCFG.p_wrcName;
        m_wrcOffV = msgDCFG.p_wrcOffV;
        m_cameraOffV = msgDCFG.p_cameraOffV;
        
    }
    return  self;
}

-(id)initWithCCFGMessage:(MessageCCFG *)msgCCFG {
    
    if((self = [super init])) {
        
        self.destination = @"WRCD";
        commandCode = 0x13;
                
        self.m_channelsArray = msgCCFG.p_channelsArray;
        
    }
    return  self;
}

-(id)initWithFCFGMessage:(MessageFCFG *)msgFCFG {
    
    if((self = [super init])) {
        
        self.destination = @"WRCD";
        commandCode = 0x14;
        
        self.m_failsafeChannelsArray = msgFCFG.p_failsafeChannelsArray;
        
    }
    return  self;
}

-(id)initWithPCDMessage:(MessagePCD *)msgPCD {
    
    if((self = [super init])) {
        
        self.destination = @"WRCD";
        commandCode = 0x21;
        
        self.m_periodicChannels = msgPCD.p_periodicChannels;
        
    }
    return  self;
}

-(id)initWithWCFGMessage:(MessageWCFG *)msgWCFG {
    
    if((self = [super init])) {
        
        self.destination = @"WRCD";
        commandCode = 0x31;
        
        m_ssid = msgWCFG.p_ssid;
        m_pass = msgWCFG.p_pass;
        m_apMode = msgWCFG.p_apMode;
        m_security = msgWCFG.p_security;
        m_channel = msgWCFG.p_channel;
        m_country = msgWCFG.p_country;
        
        
    }
    return  self;
}

-(id)initWithAREQMessage:(MessageAREQ *)msgAREQ {
    
    if((self = [super init])) {
        
        self.destination = @"WRCD";
        commandCode = 0x35;
        
        m_id = msgAREQ.p_Id;
        
    }
    return  self;
}

-(id)initWithFWUPMessage:(MessageFWUP *)msgFWUP {
    
    if((self = [super init])) {
        
        self.destination = @"WRCD";
        commandCode = 0x37;
        
        m_msgArray = msgFWUP.p_msgArray;
        
    }
    return  self;
}

-(id)initWithSTSTMessage:(MessageSTST *)msgSTST {
    
    if((self = [super init])) {
        
        self.destination = @"WRCD";
        commandCode = 0x41;
        
        m_cameraId = msgSTST.p_cameraId;
        m_cameraPort = msgSTST.p_cameraPort;
        
    }
    return  self;
}

-(id)initWithESTMessage:(MessageEST *)msgEST {
    
    if((self = [super init])) {
        
        self.destination = @"WRCD";
        commandCode = 0x42;
        
        m_cameraId = msgEST.p_cameraId;
        
    }
    return  self;
}

-(id)initWithEXTOUTMessage:(MessageEXTOUT *)msgExtOut {
    
    if((self = [super init])) {
        
        self.destination = @"WRCD";
        commandCode = 0x50;
        
        m_destination = msgExtOut.p_destination;
        m_array = msgExtOut.p_array;
        m_length = msgExtOut.p_length;
        
    }
    return  self;
}

-(id)initWithTCPMessage:(MessageTCP *)msgTCP {
    
    if((self = [super init])) {
                
        m_msgArray = msgTCP.tcpArray;
        
    }
    return  self;
}

@end
