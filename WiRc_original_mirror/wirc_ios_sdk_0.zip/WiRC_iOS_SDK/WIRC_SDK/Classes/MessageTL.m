//
//  MessageTL.m
//  WiRCExample
//
//  Created by Jagicza József on 12/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MessageTL.h"


@implementation MessageTL

@synthesize p_systemType, p_versionMajor, p_versionMinor, p_priority, p_name, p_statusPort;

-(id)initMsgTLWithSystemType:(uint8_t)systemType withVersionMajor:(uint8_t)versionMajor withVersionMinor:(uint8_t)versionMinor withPriority:(uint8_t)priority withTransmitterName:(char *)name withStatusPort:(uint16_t)statusPort {    
    
    if((self = [super init])) {
        
        p_systemType = systemType;
        p_versionMajor = versionMajor;
        p_versionMinor = versionMinor;
        p_priority = priority;
        p_name = name;
        p_statusPort = statusPort;
    }
    
    return self;
    
}

@end
