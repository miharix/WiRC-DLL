//
//  MessageDCFG.m
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MessageDCFG.h"


@implementation MessageDCFG

@synthesize p_wrcName, p_cameraOffV, p_wrcOffV;

-(id)initDCFGWithWrcName:(char *)wrcName withCameraOffValue:(uint16_t)cameraOffV withWrcOffValue:(uint16_t)wrcOffV {    
    
    if((self = [super init])) {
        
        p_wrcName = wrcName;
        p_cameraOffV = cameraOffV;
        p_wrcOffV = wrcOffV;
        
    }
    
    return self;
    
}


@end
