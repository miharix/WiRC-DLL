//
//  MessagePCD.h
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MessagePCD : NSObject {
    
    NSMutableArray * p_periodicChannels;
    uint32_t p_period;
}

@property(nonatomic, retain)NSMutableArray *p_periodicChannels;
@property(nonatomic, assign)uint32_t p_period;

@end
