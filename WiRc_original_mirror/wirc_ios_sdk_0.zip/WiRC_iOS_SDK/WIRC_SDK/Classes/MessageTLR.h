//
//  MessageTLR.h
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MessageTLR : NSObject {
    
    NSString *destination;
    uint8_t commandCode;
}

@property(nonatomic, retain)NSString *destination;
@property(nonatomic, assign)uint8_t commandCode;

@end
