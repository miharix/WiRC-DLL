//
//  MessageAREQ.m
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MessageAREQ.h"


@implementation MessageAREQ

@synthesize p_Id;

-(id)initAREQWithId:(uint8_t)Id {    
    
    if((self = [super init])) {
        
        p_Id = Id;        
    }
    
    return self;
    
}

@end
