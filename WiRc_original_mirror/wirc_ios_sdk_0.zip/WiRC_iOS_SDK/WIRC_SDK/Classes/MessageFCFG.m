//
//  MessageFCFG.m
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MessageFCFG.h"


@implementation MessageFCFG

@synthesize p_failsafeChannelsArray;

-(id)initFCFGWithChArray:(NSMutableArray *)failsafeChannelsArray {    
    
    if((self = [super init])) {
        
        p_failsafeChannelsArray = failsafeChannelsArray;        
    }
    
    return self;
    
}

@end
