//
//  MessageFCFG.h
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MessageFCFG : NSObject {
    
    NSMutableArray *p_failsafeChannelsArray;
}

@property(nonatomic, retain)NSMutableArray *p_failsafeChannelsArray;

@end
