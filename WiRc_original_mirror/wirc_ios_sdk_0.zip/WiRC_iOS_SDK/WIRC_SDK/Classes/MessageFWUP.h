//
//  MessageFWUP.h
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MessageFWUP : NSObject {
    
    const void * p_msgArray;
}

@property(nonatomic, assign)const void * p_msgArray;

@end
