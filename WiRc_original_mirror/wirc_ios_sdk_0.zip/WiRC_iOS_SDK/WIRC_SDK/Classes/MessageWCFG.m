//
//  MessageWCFG.m
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MessageWCFG.h"


@implementation MessageWCFG

@synthesize p_ssid, p_pass, p_apMode, p_security, p_channel, p_country;

-(id)initWCFGWithWifiSSID:(NSString *)ssid withWifiPassword:(NSString *)password withAP:(BOOL)AP withSecurity:(BOOL)sec withChannel:(NSInteger)channel withCountry:(NSString *)country {
    
    if((self = [super init])) {
        
        p_ssid = ssid;
        p_pass = password;
        p_apMode = AP;
        p_security = sec;
        p_channel = channel;
        p_country = country;
    }
    
    return self;
    
}

@end
