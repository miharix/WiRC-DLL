//
//  MessageFWUP.m
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MessageFWUP.h"


@implementation MessageFWUP

@synthesize p_msgArray;

-(id)initFWUPWithMsgBodyArray:(const void*)msgArray {    
    
    if((self = [super init])) {
        
        p_msgArray = msgArray;        
    }
    
    return self;
    
}

@end
