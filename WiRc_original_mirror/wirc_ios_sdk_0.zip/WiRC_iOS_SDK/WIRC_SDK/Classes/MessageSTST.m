//
//  MessageSTST.m
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MessageSTST.h"


@implementation MessageSTST

@synthesize p_cameraId, p_cameraPort;

-(id)initSTSTWithCameraId:(uint8_t)cameraId withPort:(uint16_t)cameraPort {    
    
    if((self = [super init])) {
        
        p_cameraId = cameraId;
        p_cameraPort = cameraPort;
        
        NSLog(@"camIDInSTST:%d", p_cameraId);
        
    }
    
    return self;
    
}

@end
