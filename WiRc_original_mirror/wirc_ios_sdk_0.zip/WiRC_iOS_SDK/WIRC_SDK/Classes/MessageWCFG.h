//
//  MessageWCFG.h
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MessageWCFG : NSObject {
    
    NSString *p_ssid;
    NSString *p_pass;
    BOOL p_apMode;
    BOOL p_security;
    NSInteger p_channel;
    NSString *p_country;
    
}

@property(nonatomic, retain)NSString *p_ssid;
@property(nonatomic, retain)NSString *p_pass;
@property(nonatomic, assign)BOOL p_apMode;
@property(nonatomic, assign)BOOL p_security;
@property(nonatomic, assign)NSInteger p_channel;
@property(nonatomic, retain)NSString *p_country;

-(id)initWCFGWithWifiSSID:(NSString *)ssid withWifiPassword:(NSString *)password withAP:(BOOL)AP withSecurity:(BOOL)sec withChannel:(NSInteger)channel withCountry:(NSString *)country;

@end
