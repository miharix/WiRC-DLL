//
//  MessageTCP.m
//  WiRCExample
//
//  Created by Jagicza József on 12/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MessageTCP.h"


@implementation MessageTCP

@synthesize tcpArray;

-(id)initTCPWithMSgBodyArray:(NSMutableArray *)msgArray {
    
    if((self = [super init])) {
        
        tcpArray = msgArray;        
    }
    
    return self;
    
}

@end
