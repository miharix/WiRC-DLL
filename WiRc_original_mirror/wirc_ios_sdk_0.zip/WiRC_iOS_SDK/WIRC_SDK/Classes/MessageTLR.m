//
//  MessageTLR.m
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MessageTLR.h"


@implementation MessageTLR

@synthesize destination;
@synthesize commandCode;

-(id)init {
    
    if((self = [super init])) {
        
        self.destination = @"WRCD";
        commandCode = 32;
       
    }
    
    return self;
    
}

@end
