//
//  MessageDCFG.h
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MessageDCFG : NSObject {
    
    char *p_wrcName;
    uint16_t p_cameraOffV;
    uint16_t p_wrcOffV;
}

@property(nonatomic, assign)char *p_wrcName;
@property(nonatomic, assign)uint16_t p_cameraOffV;
@property(nonatomic, assign)uint16_t p_wrcOffV;

@end
