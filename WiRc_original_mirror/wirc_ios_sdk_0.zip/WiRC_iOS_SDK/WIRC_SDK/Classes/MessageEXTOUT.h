//
//  MessageEXTOUT.h
//  WiRCExample
//
//  Created by Jagicza József on 12/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MessageEXTOUT : NSObject {
    
    int p_destination;
    const void * p_array;
    int p_length;
}

@property(nonatomic, assign)int p_destination;
@property(nonatomic, assign)const void *p_array;
@property(nonatomic, assign)int p_length;

@end
