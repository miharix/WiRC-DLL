//
//  MessageEST.h
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MessageEST : NSObject {
    
    uint8_t p_cameraId;
    
}

@property(nonatomic, assign)uint8_t p_cameraId;


-(id)initESTWithId:(uint8_t)cId;


@end
