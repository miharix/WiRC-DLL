//
//  MessagePSD.m
//  WiRCExample
//
//  Created by Jagicza József on 12/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MessagePSD.h"


@implementation MessagePSD

@synthesize psdArray;
@synthesize batt1, batt2;
@synthesize in1, in2, in3, in4;


-(id)initPSDMessage:(uint16_t)battery1 withBat2:(uint16_t)battery2 withInput1:(uint8_t)input1 withInput2:(uint8_t)input2 withInput3:(uint8_t)input3 withInput4:(uint8_t)input4 {    
    
    if((self = [super init])) {
        
        batt1 = battery1;
        batt2 = battery2;
        
        in1 = input1;
        in2 = input2;
        in3 = input3;
        in4 = input4;
        
    }
    
    return self;
    
}

@end
