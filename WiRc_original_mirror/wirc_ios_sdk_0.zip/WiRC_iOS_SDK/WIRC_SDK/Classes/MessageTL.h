//
//  MessageTL.h
//  WiRCExample
//
//  Created by Jagicza József on 12/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Messages.h"

@interface MessageTL : NSObject {
    
    uint8_t p_systemType;
    uint8_t p_versionMajor;
    uint8_t p_versionMinor;
    uint8_t p_priority;
    char *p_name;
    uint16_t p_statusPort;
    
}

@property(nonatomic, assign)uint8_t p_systemType;
@property(nonatomic, assign)uint8_t p_versionMajor;
@property(nonatomic, assign)uint8_t p_versionMinor;
@property(nonatomic, assign)uint8_t p_priority;
@property(nonatomic, assign)char *p_name;
@property(nonatomic, assign)uint16_t p_statusPort;

@end
