//
//  Messages.h
//  WiRCExample
//
//  Created by Jagicza József on 11/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@class MessageTL, MessageDCFG, MessageCCFG, MessageFCFG, MessagePCD, MessageWCFG, MessageAREQ, MessageFWUP, MessageSTST, MessageEST, MessageEXTOUT, MessageTCP;

@interface Messages : NSObject {
    
    NSString *destination;
    uint8_t commandCode;
    
/** Params of the TL message
*/
    uint8_t m_systemType;
    uint8_t m_versionMajor;
    uint8_t m_versionMinor;
    uint8_t m_priority;
    char *m_name;
    uint16_t m_statusPort;
    
/** Params of the DCFG message
*/
    char *m_wrcName;
    uint16_t m_cameraOffV;
    uint16_t m_wrcOffV;
   
/** Param of the CCFG message
*/
    NSArray *m_channelsArray;
    
/** Param of the FCFG message
*/
    NSArray *m_failsafeChannelsArray;

/** Param of the PCD message
*/
    NSArray * m_periodicChannels;
    
/** Param of the WCFG, FWUP, STST & EST messages
*/
    const void *m_msgArray;

/** Param of the AREQ message
*/
    uint8_t m_id;
    
/** Param of the EXTOUT message
*/
    int m_destination;
    const void * m_array;
    int m_length;
    
/** Param of the TCP message
*/
    
    NSArray *m_tcp_Array;
    
    
/** Param of the WCFG message
*/
    
    NSString *m_ssid;
    NSString *m_pass;
    BOOL m_apMode;
    BOOL m_security;
    NSInteger m_channel;
    NSString *m_country;
    

/** Param of the STST message
 */

uint8_t m_cameraId;
uint16_t m_cameraPort;


}

@property(nonatomic, retain)NSString *destination;
@property(nonatomic, assign)uint8_t commandCode;

@property(nonatomic, assign)uint8_t m_systemType;
@property(nonatomic, assign)uint8_t m_versionMajor;
@property(nonatomic, assign)uint8_t m_versionMinor;
@property(nonatomic, assign)uint8_t m_priority;
@property(nonatomic, assign)char *m_name;
@property(nonatomic, assign)uint16_t m_statusPort;

@property(nonatomic, assign)char *m_wrcName;
@property(nonatomic, assign)uint16_t m_cameraOffV;
@property(nonatomic, assign)uint16_t m_wrcOffV;

@property(nonatomic, retain)NSArray *m_channelsArray;

@property(nonatomic, retain)NSArray *m_failsafeChannelsArray;

@property(nonatomic, retain)NSArray *m_periodicChannels;

@property(nonatomic, assign)const void *m_msgArray;

@property(nonatomic, assign)uint8_t m_id;

@property(nonatomic, assign)int m_destination;
@property(nonatomic, assign)const void *m_array;
@property(nonatomic, assign)int m_length;

@property(nonatomic, retain)NSArray *m_tcp_Array;

@property(nonatomic, assign)NSString *m_ssid;
@property(nonatomic, assign)NSString *m_pass;
@property(nonatomic, assign)BOOL m_apMode;
@property(nonatomic, assign)BOOL m_security;
@property(nonatomic, assign)NSInteger m_channel;
@property(nonatomic, assign)NSString *m_country;

@property(nonatomic, assign)uint8_t m_cameraId;
@property(nonatomic, assign)uint16_t m_cameraPort;

-(id)initWithTLMessage:(MessageTL *)msgTL;
-(id)initWithDCFGMessage:(MessageDCFG *)msgDCFG;
-(id)initWithCCFGMessage:(MessageCCFG *)msgCCFG;
-(id)initWithFCFGMessage:(MessageFCFG *)msgFCFG;
-(id)initWithPCDMessage:(MessagePCD *)msgPCD;
-(id)initWithWCFGMessage:(MessageWCFG *)msgWCFG;
-(id)initWithAREQMessage:(MessageAREQ *)msgAREQ;
-(id)initWithFWUPMessage:(MessageFWUP *)msgFWUP;
-(id)initWithSTSTMessage:(MessageSTST *)msgSTST;
-(id)initWithESTMessage:(MessageEST *)msgEST;
-(id)initWithEXTOUTMessage:(MessageEXTOUT *)msgExtOut;
-(id)initWithTCPMessage:(MessageTCP *)msgTCP;

@end
