//
//  MessageAREQ.h
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MessageAREQ : NSObject {
    
    uint8_t p_Id;
}

@property(nonatomic, assign)uint8_t p_Id;

@end
