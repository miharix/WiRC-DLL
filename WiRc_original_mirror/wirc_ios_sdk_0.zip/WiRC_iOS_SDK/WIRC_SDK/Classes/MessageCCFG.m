//
//  MessageCCFG.m
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MessageCCFG.h"


@implementation MessageCCFG

@synthesize p_channelsArray;

-(id)initCCFGWithChArray:(NSMutableArray *)channelsArray {    
    
    if((self = [super init])) {
        
        p_channelsArray = channelsArray;        
    }
    
    return self;
    
}

@end
