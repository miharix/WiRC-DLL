//
//  WiRC.h
//  WRC
//
//  Created by Jagicza József on 11/24/11.
//  Copyright (C) 2011 Dension Audio Systems Kft.
//

#import <Foundation/Foundation.h>
#include "msg_messages.h"
#import "Messages.h"
#import "MessageTL.h"
#import "MessageDCFG.h"
#import "MessageCCFG.h"
#import "MessageFCFG.h"
#import "MessagePCD.h"
#import "MessageWCFG.h"
#import "MessageTLR.h"
#import "MessageAREQ.h"
#import "MessageFWUP.h"
#import "MessageSTST.h"
#import "MessageEST.h"
#import "MessageExtOut.h"
#import "MessageTCP.h"
#import "MessagePSD.h"

@protocol WiRCDelegate
@optional

// Called when the client receives a message via TCP from the WiRC
-(void)didReceivedTCP:(MessageTCP *)array;

// Called when the client receives a Periodic Status Data (PSD) message via TCP from the WiRC
-(void)didReceivedPSD:(MessagePSD *)array;

// Called when the client receives an Access Granted (AGR) message from the WiRC
-(void)didReceivedAGR:(NSString *)transmitterName withTransmitterId:(uint8_t)trId withTransmitterPriority:(uint8_t)Prio withNotif:(uint8_t)notif;

// Called when the client receives an Error (ERR) message from the WiRC
-(void)didReceivedErrorMsg:(uint16_t)err withCmdCode:(uint8_t)cmd;

//Called when a client connects to or disconnects from the WiRC via TCP
-(void)onConnect:(BOOL)isConnect didConnectToHost:(NSString *)host port:(uint16_t)port;

// Called when a frame is received of the incoming MJPEG stream
-(void)didReceivedCameraFrameNum:(uint32_t)frameNum withImage:(UIImage *)image;

@end

@interface WiRC : NSObject {
    
    uint8_t hwVerMajor; 
    uint8_t hwVerMinor; 
    uint8_t swVerMajor; 
    uint8_t swVerMinor; 
    uint8_t transmitterId;
    uint8_t camNum;
    NSString *stName;
    NSString *stSerial;
    NSString *ipAddress;
    
}

// Major number of the HW Version of the WiRC device 
@property(readonly)uint8_t hwVerMajor; 


// Minor number of the HW Version of the WiRC device 
@property(readonly)uint8_t hwVerMinor; 


// Major number of the SW Version of the WiRC device 
@property(readonly)uint8_t swVerMajor; 


// Minor number of the SW Version of the WiRC device 
@property(readonly)uint8_t swVerMinor; 

// ConnectionID of the client (transmitter) determined by the WiRC
@property(readonly)uint8_t transmitterId;

// Number of connected the cameras
@property(readonly)uint8_t camNum;

// name of the WiRC device
@property(readonly, copy)NSString *stName;

// serial number of the WiRC device
@property(readonly, copy)NSString *stSerial;

// IpAddress of the connected WiRC device
@property(readonly, copy)NSString *ipAddress;

// Discover available WiRC devices on the network, returns array of WiRC objects
+(NSArray *)WiRCDiscover:(int)sysType withVersionNumberMajor:(int)versionNumberMajor withVersionNumberMinor:(int)versionNumberMinor withTimeout:(float)timeout;

// Set Delegate
-(void)setDelegate:(id)delegateObj;

// Function to initialize connection with a WRC 
-(int)connectAndLogin;

// Function to set PCD value of a channel 
-(int)setChannel:(uint8_t)channel withValue:(uint16_t)chValue;

// alternative function if WiRCDiscover is not used
-(id)initWithIp:(NSString *)Ip;

// Function to connect to the remote WiRC device via TCP, connectAndLogin is recommended instead of this function
-(int)connect;

// Function to disconnect client from the connected WiRC
-(void)disconnect;

// Init WiRC object, WiRCDiscover is recommended instead of this function
-(id)initWithHwVersionMajor:(uint8_t)hwVersionMajor withHwVersioMinor:(uint8_t)hwVersionMinor withSwVersionMajor:(uint8_t)swVersionMajor withSwVersionMinor:(uint8_t)swVersionMinor withWrcName:(NSString *)wrcName withSerial:(NSString *)serial withIp:(NSString *)Ip;

// Function to send a TL (Transmitter Login) message 
-(int)sendTL:(MessageTL *)msgTL;

// Function to send a DCFG (Device Configuration) message 
-(int)sendDCFG:(MessageDCFG *)msgDCFG;

// Function to send a CCFG (Channel Configuration) message 
-(int)sendCCFG:(MessageCCFG *)msgCCFG;

// Function to send a FCFG (Failsafe Configuration) message 
-(int)sendFCFG:(MessageFCFG *)msgFCFG;

// Function to send a PCD (Periodic Channel Data) message 
-(int)sendPCD:(MessagePCD *)msgPCD;

// Function to send a WCFG (WiFi Configuration) message 
-(int)sendWCFG:(MessageWCFG *)msgWCFG;

// Function to send a TLR (Transmitter List Request) message 
-(int)sendTLR:(MessageTLR *)msgTLR;

// Function to send a AREQ (Access Request) message 
-(int)sendAREQ:(MessageAREQ *)msgId;

// Function to send a FWUP (Firmware Update) message 
-(int)sendFWUP:(MessageFWUP *)msgFWUP;

// Function to send a STST (Start Stream) message 
-(int)sendSTST:(MessageSTST *)msgSTST;

// Function to send a EST (End Stream) message 
-(int)sendEST:(MessageEST *)msgEST;

// Function to send an EXTOUT (External Out) message
-(int)sendExtOut:(int)destination withMsgBody:(const void *)array withLen:(int)length;

// Returns YES if the socket and streams are open, connected, and ready for reading and writing.
-(BOOL)isConnected;

// Function to handle camera start command 
-(int)startCameraWithId:(int)cameraId;

// Function to start Camera stream receiver thread
-(int)stopCameraWithId:(int)cameraId;


@end
