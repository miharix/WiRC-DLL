//
//  MessageSTST.h
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MessageSTST : NSObject {
    
    uint8_t p_cameraId;
    uint16_t p_cameraPort;
    
}

@property(nonatomic, assign)uint8_t p_cameraId;
@property(nonatomic, assign)uint16_t p_cameraPort;

-(id)initSTSTWithCameraId:(uint8_t)cameraId withPort:(uint16_t)cameraPort;

@end
