//
//  MessagePCD.m
//  WiRCExample
//
//  Created by Jagicza József on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MessagePCD.h"


@implementation MessagePCD

@synthesize p_periodicChannels;
@synthesize p_period;

-(id)initPCDWithArray:(NSMutableArray *)periodicChannels {    
    
    if((self = [super init])) {
        
        p_periodicChannels = periodicChannels;        
    }
    
    return self;
    
}

@end
