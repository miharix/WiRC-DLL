//
//  MessagePSD.h
//  WiRCExample
//
//  Created by Jagicza József on 12/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MessagePSD : NSObject {
    
    uint16_t batt1;
    uint16_t batt2;
    
    uint8_t in1;
    uint8_t in2;
    uint8_t in3;
    uint8_t in4;
    
    NSMutableArray *psdArray;

}

@property(nonatomic, assign)uint16_t batt1;
@property(nonatomic, assign)uint16_t batt2;

@property(nonatomic, assign)uint8_t in1;
@property(nonatomic, assign)uint8_t in2;
@property(nonatomic, assign)uint8_t in3;
@property(nonatomic, assign)uint8_t in4;

@property(nonatomic, retain)NSMutableArray *psdArray;


@end
