//
//  MessageEXTOUT.m
//  WiRCExample
//
//  Created by Jagicza József on 12/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MessageEXTOUT.h"


@implementation MessageEXTOUT

@synthesize p_destination, p_array, p_length;


-(id)initExtOut:(int)destination withMsgBody:(const void *)array withLen:(int)length {    
    
    if((self = [super init])) {
        
        p_destination = destination;
        p_array = array;
        p_length = length;
    }
    
    return self; 
}

@end
