//
//  MessageTCP.h
//  WiRCExample
//
//  Created by Jagicza József on 12/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MessageTCP : NSObject {
    
    NSMutableArray *tcpArray;
}

@property(nonatomic, retain)NSMutableArray *tcpArray;

-(id)initTCPWithMSgBodyArray:(NSMutableArray *)msgArray;

@end
