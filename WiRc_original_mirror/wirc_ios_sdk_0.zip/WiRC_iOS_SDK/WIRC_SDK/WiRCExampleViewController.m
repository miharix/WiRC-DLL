//
//  WiRCExampleViewController.m
//  WiRCExample
//
//  Created by Jagicza József on 11/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "WiRCExampleViewController.h"
#import "WiRC.h"
#import "msg_messages.h"
#import "MessageExtOut.h"
#import "MessageWCFG.h"

#define BTN_EVENT_SORT 1
#define BTN_EVENT_LONG 2

@implementation WiRCExampleViewController

@synthesize wirc;
@synthesize valueLabel1, valueLabel2;
@synthesize valueVoltLabel1, valueVoltLabel2;
@synthesize valueDigInput1Label, valueDigInput2Label, valueDigInput3Label, valueDigInput4Label;
@synthesize chValue1, chValue2;
@synthesize battery1, battery2, digitInput1, digitInput2, digitInput3, digitInput4;
@synthesize cameraImg, light;

-(void)dealloc {
    
    [wirc release];
    
    [valueLabel1 release];
    [valueLabel2 release];
    
    [valueVoltLabel1 release];
    [valueVoltLabel2 release];
    
    [valueDigInput1Label release];
    [valueDigInput2Label release];
    [valueDigInput3Label release];
    [valueDigInput4Label release];
    
    [cameraImg release];
    
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)loadView {
    
    [super loadView];

    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc]init];

    self.cameraImg = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"background.png"]];
    [cameraImg setFrame:CGRectMake(0, 0, 320, 480)];
    [self.view addSubview:cameraImg];
   
    UITextField *textField1 = [[UITextField alloc]initWithFrame:CGRectMake(10, 100, 60, 30)];
    textField1.delegate = self;
    textField1.tag = 1;
    textField1.placeholder = @"1";
    textField1.keyboardType = UIKeyboardTypeDefault;
    textField1.returnKeyType = UIReturnKeyDone;
    textField1.borderStyle = UITextBorderStyleBezel;
    textField1.backgroundColor = [UIColor whiteColor];
    
    UITextField *textField2 = [[UITextField alloc]initWithFrame:CGRectMake(10, 150, 60, 30)];
    textField2.delegate = self;
    textField2.tag = 2;
    textField2.placeholder = @"2";
    textField2.keyboardType = UIKeyboardTypeDefault;
    textField2.returnKeyType = UIReturnKeyDone;
    textField2.borderStyle = UITextBorderStyleBezel;
    textField2.backgroundColor = [UIColor whiteColor];

    UISlider *slider1 = [[UISlider alloc]initWithFrame:CGRectMake(80, 100, 170, 30)];
    slider1.userInteractionEnabled = YES;
    slider1.minimumValue = 800.0;
    slider1.maximumValue = 2200.0;
    slider1.value = 1500.0;
    slider1.continuous = YES;
    slider1.tag = 1;
    [slider1 addTarget:self action:@selector(setValueChanged:) forControlEvents:UIControlEventValueChanged];
    [slider1 setMaximumTrackImage:[UIImage imageNamed:@"sliderMax.png"] forState:UIControlStateNormal];
    [slider1 setMinimumTrackImage:[UIImage imageNamed:@"sliderMin.png"] forState:UIControlStateNormal];
    [slider1 setThumbImage:[UIImage imageNamed:@"sliderThumb.png"] forState:UIControlStateNormal];
    [self.view addSubview:slider1];
    [slider1 release];
    
    UISlider *slider2 = [[UISlider alloc]initWithFrame:CGRectMake(80, 150, 170, 30)];
    slider2.userInteractionEnabled = YES;
    slider2.minimumValue = 800.0;
    slider2.maximumValue = 2200.0;
    slider2.value = 1500.0;
    slider2.continuous = YES;
    slider2.tag = 2;
    [slider2 addTarget:self action:@selector(setValueChanged:) forControlEvents:UIControlEventValueChanged];
    [slider2 setMaximumTrackImage:[UIImage imageNamed:@"sliderMax.png"] forState:UIControlStateNormal];
    [slider2 setMinimumTrackImage:[UIImage imageNamed:@"sliderMin.png"] forState:UIControlStateNormal];
    [slider2 setThumbImage:[UIImage imageNamed:@"sliderThumb.png"] forState:UIControlStateNormal];
    [self.view addSubview:slider2];
    [slider2 release];
    
    [self.view addSubview:textField1];
    [self.view addSubview:textField2];
    
    [textField1 release];
    [textField2 release];

    [self addStaticLabels];
    
    [self addValueLabels];
    
    [pool release];

}

-(void)viewDidLoad {
    
    [super viewDidLoad];
    
    chValue1 = 1;
    chValue2 = 2;
    
    [NSThread detachNewThreadSelector:@selector(startConnectInNewThread) toTarget:self withObject:nil];
        
}

-(void)displayImage:(UIImage *)image {
    
    [self.cameraImg setFrame:CGRectMake(0, 0, 352, 288)];
    [self.cameraImg setImage:image];
     
}

-(void)didReceivedErrorMsg:(uint16_t)err withCmdCode:(uint8_t)cmd {
    
    NSLog(@"receiveErr cmdcode: 0x%.2x, errorcode: 0x%.4x", cmd, err);
}

-(void)didReceivedTCP:(MessageTCP *)array {
    
    //NSLog(@"Received TCP: %@", array.tcpArray);
    
}

-(void)didReceivedAGR:(NSString *)transmitterName withTransmitterId:(uint8_t)trId withTransmitterPriority:(uint8_t)Prio withNotif:(uint8_t)notif {
    
    NSLog(@"received AGR");
    NSLog(@"trName:%@", transmitterName);
    NSLog(@"id:%d", trId);
    NSLog(@"prio:%d", Prio);
    NSLog(@"notif:%d", notif);
    
}

-(void)didReceivedPSD:(MessagePSD *)msgPSD {    
    
    battery1 = msgPSD.batt1;
    battery2 = msgPSD.batt2;
    
    digitInput1 = msgPSD.in1;
    digitInput2 = msgPSD.in2;
    digitInput3 = msgPSD.in3;
    digitInput4 = msgPSD.in4;
}

-(void)didReceivedCameraFrameNum:(uint32_t)frameNum withImage:(UIImage *)image {
    [self performSelectorOnMainThread:@selector(displayImage:) withObject:image waitUntilDone:NO];
    //[self writeToFile:image toFilePath:[NSString stringWithFormat:@"kepek%d.jpg", tempIndex]];
}

-(void)writeToFile:(UIImage *)image toFilePath:(NSString *)filePath {

    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,  NSUserDomainMask, YES);
    NSString *documentsDirectoryPath = [paths objectAtIndex:0];
    NSString *dataPath = [documentsDirectoryPath  stringByAppendingPathComponent:filePath];
    
    NSData* settingsData = UIImageJPEGRepresentation(image, 1.0);
    
    [settingsData writeToFile:dataPath atomically:YES];
    
}

-(void)onConnect:(BOOL)isConnect didConnectToHost:(NSString *)host port:(uint16_t)port {
    
    NSLog(@"%@ %@:%d", isConnect ? @"connected to" : @"disconnected from", host, port);

    if(isConnect) {
        if (nil != self.light) {
            [self.light release];
        }
        self.light = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"light.png"]];
        self.light.frame = CGRectMake(240, 420, 50, 30);
        [self.view addSubview:self.light];
        
    } else {
        [self.light removeFromSuperview];
        [self.light release];
        self.light = nil;
    }
    
}


-(void)startConnectInNewThread {
    
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc]init];
    
    NSArray *array = [NSArray array];
    
    do {
        
        array = [WiRC WiRCDiscover:1 withVersionNumberMajor:1 withVersionNumberMinor:1 withTimeout:1.0];
        
    } while (array.count == 0);
    
    if(array.count > 0) {
        
        NSLog(@"array:%@", array);
        self.wirc = [array objectAtIndex:0];
            
        [self.wirc setDelegate:self];
        //[wirc connect];
        [self.wirc connectAndLogin];

        //[self setWifiConfig];
        
        if (wirc.camNum > 0) {
            [self.wirc startCameraWithId:0];
        }
    }

    [pool release];

}

/*
-(void)setWifiConfig {
    
    MessageWCFG *msg = [[MessageWCFG alloc]initWCFGWithWifiSSID:@"tesztWifi" withWifiPassword:@"1234543hkjh" withAP:TRUE withSecurity:TRUE withChannel:6 withCountry:@"HU"];
    
    [self.wirc sendWCFG:msg];
}
*/

-(void)setValueChanged:(id)sender {
    
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc]init];
    
    UISlider *sl = (UISlider *)sender;
    
    NSLog(@"value: %f", sl.value);
    
    if(sl.tag == 1) {
        
        if(valueLabel1) {
            
            [valueLabel1 removeFromSuperview];
            [valueLabel1 release];
            
        }

        self.valueLabel1 = [[UILabel alloc]init];
        valueLabel1.frame = CGRectMake(250, 100, 65, 25);
        valueLabel1.text = [NSString stringWithFormat:@"%.0f μs", sl.value];
        valueLabel1.font = [UIFont fontWithName:@"Georgia-Bold" size:11];
        valueLabel1.backgroundColor = [UIColor clearColor];
        valueLabel1.textColor = [UIColor blackColor];
        [self.view addSubview:valueLabel1];
        
        [self.wirc setChannel:chValue1 withValue:sl.value];

    }
    
    if(sl.tag == 2) {
        
        if(valueLabel2) {
            
            [valueLabel2 removeFromSuperview];
            [valueLabel2 release];
            
        }
        
        self.valueLabel2 = [[UILabel alloc]init];
        valueLabel2.frame = CGRectMake(250, 150, 65, 25);
        valueLabel2.text = [NSString stringWithFormat:@"%.0f μs", sl.value];
        valueLabel2.font = [UIFont fontWithName:@"Georgia-Bold" size:11];
        valueLabel2.backgroundColor = [UIColor clearColor];
        valueLabel2.textColor = [UIColor blackColor];
        [self.view addSubview:valueLabel2];
        
        [self.wirc setChannel:chValue2 withValue:sl.value];

    }

    [pool release];
}

#pragma mark - TextField delegate

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    if([textField.text isEqualToString:@""]) {
        
        [textField resignFirstResponder];
        
        return NO;
        
    }

    else if(textField.tag == 1) {
        
        if([textField.text intValue] > 0 && [textField.text intValue] < 13) {
            
            chValue1 = [textField.text intValue];
            
        } else {
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"HIBA! " message:@"A channel értéke 1 - 12 között lehet" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
            [alert show];
            [alert release];
            
        }
    }
    
    else if(textField.tag == 2) {
                
        if([textField.text intValue] > 0 && [textField.text intValue] < 13) {
            
            chValue2 = [textField.text intValue];
           
        } else {
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"HIBA! " message:@"A channel értéke 1 - 12 között lehet" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
            [alert show];
            [alert release];
        }
    }
    
    [textField resignFirstResponder];
    
    return NO;
}

-(void)addStaticLabels {
    
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc]init];
    
    UILabel *valueStaticLabel1 = [[UILabel alloc]init];
    valueStaticLabel1.frame = CGRectMake(20, 200, 150, 30);
    valueStaticLabel1.text = @"Value1";
    valueStaticLabel1.font = [UIFont fontWithName:@"Georgia-Bold" size:16];
    valueStaticLabel1.backgroundColor = [UIColor clearColor];
    valueStaticLabel1.textColor = [UIColor blackColor];
    [self.view addSubview:valueStaticLabel1];
    
    UILabel *valueStaticLabel2 = [[UILabel alloc]init];
    valueStaticLabel2.frame = CGRectMake(20, 240, 150, 30);
    valueStaticLabel2.text = @"Value2";
    valueStaticLabel2.font = [UIFont fontWithName:@"Georgia-Bold" size:16];
    valueStaticLabel2.backgroundColor = [UIColor clearColor];
    valueStaticLabel2.textColor = [UIColor blackColor];
    [self.view addSubview:valueStaticLabel2];
    
    UILabel *digInputLabel1 = [[UILabel alloc]init];
    digInputLabel1.frame = CGRectMake(20, 280, 150, 30);
    digInputLabel1.text = @"Digital Input1";
    digInputLabel1.font = [UIFont fontWithName:@"Georgia-Bold" size:16];
    digInputLabel1.backgroundColor = [UIColor clearColor];
    digInputLabel1.textColor = [UIColor blackColor];
    [self.view addSubview:digInputLabel1];
    
    UILabel *digInputLabel2 = [[UILabel alloc]init];
    digInputLabel2.frame = CGRectMake(20, 320, 150, 30);
    digInputLabel2.text = @"Digital Input2";
    digInputLabel2.font = [UIFont fontWithName:@"Georgia-Bold" size:16];
    digInputLabel2.backgroundColor = [UIColor clearColor];
    digInputLabel2.textColor = [UIColor blackColor];
    [self.view addSubview:digInputLabel2];
    
    UILabel *digInputLabel3 = [[UILabel alloc]init];
    digInputLabel3.frame = CGRectMake(20, 360, 150, 30);
    digInputLabel3.text = @"Digital Input3";
    digInputLabel3.font = [UIFont fontWithName:@"Georgia-Bold" size:16];
    digInputLabel3.backgroundColor = [UIColor clearColor];
    digInputLabel3.textColor = [UIColor blackColor];
    [self.view addSubview:digInputLabel3];
    
    UILabel *digInputLabel4 = [[UILabel alloc]init];
    digInputLabel4.frame = CGRectMake(20, 400, 150, 30);
    digInputLabel4.text = @"Digital Input4";
    digInputLabel4.font = [UIFont fontWithName:@"Georgia-Bold" size:16];
    digInputLabel4.backgroundColor = [UIColor clearColor];
    digInputLabel4.textColor = [UIColor blackColor];
    [self.view addSubview:digInputLabel4];
    
    [valueStaticLabel1 release];
    [valueStaticLabel2 release];
    
    [digInputLabel1 release];
    [digInputLabel2 release];
    [digInputLabel3 release];
    [digInputLabel4 release];

    [pool release];
    
}

-(void)addValueLabels {
    
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc]init];

    if(valueVoltLabel1) {
        [valueVoltLabel1 removeFromSuperview];
        [valueVoltLabel1 release];
    }
    
    if(valueVoltLabel2) {
        [valueVoltLabel2 removeFromSuperview];
        [valueVoltLabel2 release];
    }
    
    if(valueDigInput1Label) {
        [valueDigInput1Label removeFromSuperview];
        [valueDigInput1Label release];
    }
    
    if(valueDigInput2Label) {
        [valueDigInput2Label removeFromSuperview];
        [valueDigInput2Label release];
    }
    
    if(valueDigInput3Label) {
        [valueDigInput3Label removeFromSuperview];
        [valueDigInput3Label release];
    }
    
    if(valueDigInput4Label) {
        [valueDigInput4Label removeFromSuperview];
        [valueDigInput4Label release];
    }
    
    self.valueVoltLabel1 = [[UILabel alloc]init];
    valueVoltLabel1.frame = CGRectMake(200, 200, 100, 30);
    valueVoltLabel1.font = [UIFont fontWithName:@"Georgia-Bold" size:16];
    valueVoltLabel1.backgroundColor = [UIColor clearColor];
    valueVoltLabel1.textColor = [UIColor blackColor];

    [self.view addSubview:valueVoltLabel1];
    
    self.valueVoltLabel2 = [[UILabel alloc]init];
    valueVoltLabel2.frame = CGRectMake(200, 240, 100, 30);
    valueVoltLabel2.font = [UIFont fontWithName:@"Georgia-Bold" size:16];
    valueVoltLabel2.backgroundColor = [UIColor clearColor];
    valueVoltLabel2.textColor = [UIColor blackColor];
    
    [self.view addSubview:valueVoltLabel2];
    
    self.valueDigInput1Label = [[UILabel alloc]init];
    valueDigInput1Label.frame = CGRectMake(200, 280, 100, 30);
    valueDigInput1Label.font = [UIFont fontWithName:@"Georgia-Bold" size:16];
    valueDigInput1Label.backgroundColor = [UIColor clearColor];
    valueDigInput1Label.textColor = [UIColor blackColor];
    
    [self.view addSubview:valueDigInput1Label];
    
    self.valueDigInput2Label = [[UILabel alloc]init];
    valueDigInput2Label.frame = CGRectMake(200, 320, 100, 30);
    valueDigInput2Label.font = [UIFont fontWithName:@"Georgia-Bold" size:16];
    valueDigInput2Label.backgroundColor = [UIColor clearColor];
    valueDigInput2Label.textColor = [UIColor blackColor];
    
    [self.view addSubview:valueDigInput2Label];
    
    self.valueDigInput3Label = [[UILabel alloc]init];
    valueDigInput3Label.frame = CGRectMake(200, 360, 100, 30);
    valueDigInput3Label.font = [UIFont fontWithName:@"Georgia-Bold" size:16];
    valueDigInput3Label.backgroundColor = [UIColor clearColor];
    valueDigInput3Label.textColor = [UIColor blackColor];
    
    [self.view addSubview:valueDigInput3Label];
    
    self.valueDigInput4Label = [[UILabel alloc]init];
    valueDigInput4Label.frame = CGRectMake(200, 400, 100, 30);
    valueDigInput4Label.font = [UIFont fontWithName:@"Georgia-Bold" size:16];
    valueDigInput4Label.backgroundColor = [UIColor clearColor];
    valueDigInput4Label.textColor = [UIColor blackColor];
    
    [self.view addSubview:valueDigInput4Label];
    
    [NSTimer scheduledTimerWithTimeInterval:1/25 target:self selector:@selector(addValues) userInfo:nil repeats:YES];
    
    [pool release];
}

-(void)addValues {
        
    NSString *batt1 = [NSString stringWithFormat:@"%d mV", battery1];
    NSString *batt2 = [NSString stringWithFormat:@"%d mV", battery2];
    NSString *diginp1 = [NSString stringWithFormat:@"%d", digitInput1];
    NSString *diginp2 = [NSString stringWithFormat:@"%d", digitInput2];
    NSString *diginp3 = [NSString stringWithFormat:@"%d", digitInput3];
    NSString *diginp4 = [NSString stringWithFormat:@"%d", digitInput4];

    valueVoltLabel1.text = batt1;
    valueVoltLabel2.text = batt2;
    
    valueDigInput1Label.text = [NSString stringWithFormat:@"0x%x", [self stringToHex:diginp1]];
    valueDigInput2Label.text = [NSString stringWithFormat:@"0x%x", [self stringToHex:diginp2]];;
    valueDigInput3Label.text = [NSString stringWithFormat:@"0x%x", [self stringToHex:diginp3]];;
    valueDigInput4Label.text = [NSString stringWithFormat:@"0x%x", [self stringToHex:diginp4]];;

}

-(uint16_t)stringToHex:(NSString *)str {
    
    char cStr[16];
    [str getCString:cStr maxLength:sizeof(cStr) encoding:NSUTF8StringEncoding];
    
    unsigned long res = strtoul(cStr, NULL, 16);
    
    return (uint16_t)res;
}

-(void)viewDidUnload {
    
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
