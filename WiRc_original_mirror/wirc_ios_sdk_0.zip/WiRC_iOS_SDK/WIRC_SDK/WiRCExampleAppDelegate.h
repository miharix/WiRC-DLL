//
//  WiRCExampleAppDelegate.h
//  WiRCExample
//
//  Created by Jagicza József on 11/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class WiRCExampleViewController;

@interface WiRCExampleAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet WiRCExampleViewController *viewController;

@end
